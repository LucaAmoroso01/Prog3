package visibilityDelView;

import application.*;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 * Interfaccia che contiene al suo interno un metodo che permette di settare la visibilità di diversi oggetti,
 * per quanto riguarda le operazioni di eliminazione di una tupla e di visualizzazione delle tabelle.
 */
public interface VisibilityDelView {
    void setVisibilityDelView(ComboBox<String> myComboBox, TableView<Categoria> tableViewCat,
    TableView<Fornitore> tableViewForn, TableView<Ricambio> tableViewRic,
    TableView<RicambioCategoria> tableViewRicCat, TableView<RicambioFornitore> tableViewRicForn,
    TableColumn<Categoria,String> codiceCategoria, TableColumn<Categoria,String> nomeCategoria,
    TableColumn<Categoria,String> descrizioneCategoria,
    TableColumn<Fornitore,String> codiceFornitore, TableColumn<Fornitore,String> nomeFornitore,
    TableColumn<Fornitore,String> partitaIva, TableColumn<Fornitore,String> indirizzo, TableColumn<Fornitore,String> cap,
    TableColumn<Fornitore,String> localita, TableColumn<Fornitore,String> nazione,
    TableColumn<Ricambio,String> codiceRicambio, TableColumn<Ricambio,String> nomeRicambio,
    TableColumn<Ricambio,String> descrizioneRicambio, TableColumn<Ricambio,Integer> quantita,
    TableColumn<Ricambio,Double> costo, TableColumn<Ricambio,Integer> sconto,
    TableColumn<RicambioCategoria,String> codiceRicambioCatFK, TableColumn<RicambioCategoria,String> codiceCategoriaFK,
    TableColumn<RicambioFornitore,String> codiceRicambioFornFK, TableColumn<RicambioFornitore,String> codiceFornitoreFK,
    TableView<TipologiaAuto> tableViewTipo, TableView<RicambioTipologia> tableViewRicTipo);
}
