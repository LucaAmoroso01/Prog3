package visibilityDelView;

import application.*;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 * Classe che implementa il metodo dell'interfaccia VisibilityDelView che permette di settare la visibilità degli oggetti
 * nell'interfaccia utente delle scene relative all'eliminazione di una tupla e alla visualizzazione della tabella
 * RicambioFornitore.
 */
public class VisibilityDelViewRicForn implements VisibilityDelView {
    public void setVisibilityDelView(ComboBox<String> myComboBox, TableView<Categoria> tableViewCat,
    TableView<Fornitore> tableViewForn, TableView<Ricambio> tableViewRic,
    TableView<RicambioCategoria> tableViewRicCat, TableView<RicambioFornitore> tableViewRicForn,
    TableColumn<Categoria,String> codiceCategoria, TableColumn<Categoria,String> nomeCategoria,
    TableColumn<Categoria,String> descrizioneCategoria,
    TableColumn<Fornitore,String> codiceFornitore, TableColumn<Fornitore,String> nomeFornitore,
    TableColumn<Fornitore,String> partitaIva, TableColumn<Fornitore,String> indirizzo, TableColumn<Fornitore,String> cap,
    TableColumn<Fornitore,String> localita, TableColumn<Fornitore,String> nazione,
    TableColumn<Ricambio,String> codiceRicambio, TableColumn<Ricambio,String> nomeRicambio,
    TableColumn<Ricambio,String> descrizioneRicambio, TableColumn<Ricambio,Integer> quantita,
    TableColumn<Ricambio,Double> costo, TableColumn<Ricambio,Integer> sconto,
    TableColumn<RicambioCategoria,String> codiceRicambioCatFK, TableColumn<RicambioCategoria,String> codiceCategoriaFK,
    TableColumn<RicambioFornitore,String> codiceRicambioFornFK, TableColumn<RicambioFornitore,String> codiceFornitoreFK,
    TableView<TipologiaAuto> tableViewTipo, TableView<RicambioTipologia> tableViewRicTipo) {
        tableViewCat.setVisible(false);
        tableViewForn.setVisible(false);
        tableViewRic.setVisible(false);
        tableViewRicCat.setVisible(false);
        tableViewRicForn.setVisible(true);
        codiceCategoria.setVisible(false);
        nomeCategoria.setVisible(false);
        descrizioneCategoria.setVisible(false);
        codiceRicambioCatFK.setVisible(false);
        codiceCategoriaFK.setVisible(false);
        codiceRicambioFornFK.setVisible(true);
        codiceFornitoreFK.setVisible(true);
        codiceFornitore.setVisible(false);
        nomeFornitore.setVisible(false);
        partitaIva.setVisible(false);
        indirizzo.setVisible(false);
        cap.setVisible(false);
        localita.setVisible(false);
        nazione.setVisible(false);
        codiceRicambio.setVisible(false);
        nomeRicambio.setVisible(false);
        descrizioneRicambio.setVisible(false);
        quantita.setVisible(false);
        costo.setVisible(false);
        sconto.setVisible(false);
        tableViewTipo.setVisible(false);
        tableViewRicTipo.setVisible(false);
    }
}
