package visibilityInsert;

import application.Categoria;
import application.Fornitore;
import application.Ricambio;
import application.TipologiaAuto;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Classe che implementa l'interfaccia VisibilityInsert e che contiene al suo interno un metodo che permette di settare
 * la visibilità di diversi oggetti, per quanto riguarda le operazioni di inserimento di una tupla nella tabella TipologiaAuto.
 */
public class VisibilityInsertTipo implements VisibilityInsert {
    public void setVisibilityInsert(TextField codiceCategoria, TextField nomeCategoria, TextField descrizioneCategoria,
    TextField codiceFornitore, TextField nomeFornitore, TextField partitaIva, TextField indirizzo, TextField cap,
    TextField localita, TextField nazione, TextField codiceRicambio, TextField nomeRicambio,
    TextField descrizioneRicambio, TextField quantita, TextField costo, TextField sconto,
    TableView<Ricambio> tableViewRic, TableView<Categoria> tableViewCat, TableView<Fornitore> tableViewForn,
    TableColumn<Ricambio,String> codiceRicambioCat, TableColumn<Ricambio,String> nomeRicambioCat,
    TableColumn<Categoria,String> codiceCategoriaRic, TableColumn<Categoria,String> nomeCategoriaRic,
    TableColumn<Fornitore,String> codiceFornitoreRic, TableColumn<Fornitore,String> nomeFornitoreRic,
    TextField nomeTipologia, TextField descTipologia, TableView<TipologiaAuto> tableViewTipo) {
        codiceCategoria.setVisible(false);
        nomeCategoria.setVisible(false);
        descrizioneCategoria.setVisible(false);
        codiceFornitore.setVisible(false);
        nomeFornitore.setVisible(false);
        partitaIva.setVisible(false);
        indirizzo.setVisible(false);
        cap.setVisible(false);
        localita.setVisible(false);
        nazione.setVisible(false);
        codiceRicambio.setVisible(false);
        nomeRicambio.setVisible(false);
        descrizioneRicambio.setVisible(false);
        quantita.setVisible(false);
        costo.setVisible(false);
        sconto.setVisible(false);
        tableViewRic.setVisible(false);
        tableViewCat.setVisible(false);
        tableViewForn.setVisible(false);
        codiceRicambioCat.setVisible(false);
        nomeRicambioCat.setVisible(false);
        codiceCategoriaRic.setVisible(false);
        nomeCategoriaRic.setVisible(false);
        codiceFornitoreRic.setVisible(false);
        nomeFornitoreRic.setVisible(false);
        nomeTipologia.setVisible(true);
        descTipologia.setVisible(true);
        tableViewTipo.setVisible(false);

        codiceCategoria.clear();
        nomeCategoria.clear();
        descrizioneCategoria.clear();
        codiceFornitore.clear();
        nomeFornitore.clear();
        partitaIva.clear();
        indirizzo.clear();
        cap.clear();
        localita.clear();
        nazione.clear();
        codiceRicambio.clear();
        nomeRicambio.clear();
        descrizioneRicambio.clear();
        quantita.clear();
        costo.clear();
        sconto.clear();
        nomeTipologia.clear();
        descTipologia.clear();
    }
}
