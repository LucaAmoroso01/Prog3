package visibilityInsert;

import application.Categoria;
import application.Fornitore;
import application.Ricambio;
import application.TipologiaAuto;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

/**
 * Interfaccia che contiene al suo interno un metodo che permette di settare la visibilità di diversi oggetti,
 * per quanto riguarda le operazioni di inserimento di una tupla.
 */
public interface VisibilityInsert {
    void setVisibilityInsert(TextField codiceCategoria, TextField nomeCategoria, TextField descrizioneCategoria,
    TextField codiceFornitore, TextField nomeFornitore, TextField partitaIva, TextField indirizzo, TextField cap,
    TextField localita, TextField nazione, TextField codiceRicambio, TextField nomeRicambio,
    TextField descrizioneRicambio, TextField quantita, TextField costo, TextField sconto,
    TableView<Ricambio> tableViewRic, TableView<Categoria> tableViewCat, TableView<Fornitore> tableViewForn,
    TableColumn<Ricambio,String> codiceRicambioCat, TableColumn<Ricambio,String> nomeRicambioCat,
    TableColumn<Categoria,String> codiceCategoriaRic, TableColumn<Categoria,String> nomeCategoriaRic,
    TableColumn<Fornitore,String> codiceFornitoreRic, TableColumn<Fornitore,String> nomeFornitoreRic,
    TextField nomeTipologia, TextField descTipologia, TableView<TipologiaAuto> tableViewTipo);
}
