package strategy.pattern;

import application.RicambioCategoria;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;

import java.sql.ResultSet;

/**
 * Questa classe rappresenta un ConcreteStrategy del pattern Strategy e permette di inizializzare una tabella
 * contenente tutti le associazioni ricambio-categoria contenute nel database.
 * @author Luca Amoroso
 * @see Tabella
 */
public class TabellaRicambioCategoria implements Tabella<RicambioCategoria> {
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo ObservableList che accetta solo oggetti di tipo
     * RicambioCategoria.
     */
    @FXML
    private ObservableList<RicambioCategoria> data;

    /**
     * Nel costruttore assegno alla variabile istanza privata un ObservableList, per memorizzare successivamente
     * tutti le associazioni ricambio-categoria presenti nel database.
     */
    public TabellaRicambioCategoria()
    {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo RicambioCategoria.
     * @return un ObservableList contenente tutte le associazioni ricambio-categoria presenti nel database
     */
    @Override
    public ObservableList<RicambioCategoria> crea()
    {
        try
        {
            Database db = new Database();
            String sql = "Select * from venditaricambi.ricambiocategoria";
            ResultSet rs = db.query(sql);
            /**
             * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
             */
            while(rs.next())
            {
                data.add(new RicambioCategoria(rs.getString(1), rs.getString(2)));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return data;
    }
}

