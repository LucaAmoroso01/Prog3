package strategy.pattern;

import application.VenditaDettaglio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;

import java.sql.ResultSet;

/**
 * Questa classe rappresenta un ConcreteStrategy del pattern Strategy e permette di inizializzare una tabella
 * contenente tutte le vendite in dettaglio contenute nel database.
 * @author Luca Amoroso
 * @see Tabella
 */
public class TabellaVenditaDettaglio implements Tabella<VenditaDettaglio> {
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo ObservableList che accetta solo oggetti di tipo
     * VenditaDettaglio.
     */
    @FXML
    private ObservableList<VenditaDettaglio> data;

    /**
     * Nel costruttore assegno alla variabile istanza privata un ObservableList, per memorizzare successivamente
     * tutte le vendite in dettaglio presenti nel database.
     */
    public TabellaVenditaDettaglio()
    {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo VenditaDettaglio.
     * @return un ObservableList contenente tutte le vendite in dettaglio presenti nel database
     */
    @Override
    public ObservableList<VenditaDettaglio> crea()
    {
        try
        {
            Database db = new Database();
            String sql = "Select * from venditaricambi.venditadettaglio";
            ResultSet rs = db.query(sql);
            /**
             * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
             */
            while(rs.next())
            {
                data.add(new VenditaDettaglio(rs.getInt(1), rs.getString(2),
                        rs.getDouble(3), rs.getInt(4), rs.getDouble(5)));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return data;
    }
}
