package strategy.pattern;

import application.Categoria;
import application.TipologiaAuto;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;

import java.sql.ResultSet;

/**
 * Questa classe rappresenta un ConcreteStrategy del pattern Strategy e permette di inizializzare una tabella
 * contenente tutte le tipologie auto contenute nel database.
 * @author Luca Amoroso
 * @see Tabella
 */
public class TabellaTipologiaAuto implements Tabella<TipologiaAuto> {
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo ObservableList che accetta solo oggetti di tipo
     * TipologiaAuto.
     */
    @FXML
    private ObservableList<TipologiaAuto> data;

    /**
     * Nel costruttore assegno alla variabile istanza privata un ObservableList, per memorizzare successivamente
     * tutte le tipologie auto presenti nel database.
     */
    public TabellaTipologiaAuto()
    {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo TipologiaAuto.
     * @return un ObservableList contenente tutti le categorie presenti nel database
     */
    @Override
    public ObservableList<TipologiaAuto> crea()
    {
        try
        {
            Database db = new Database();
            String sql = "Select * from venditaricambi.tipologiaauto";
            ResultSet rs = db.query(sql);
            /**
             * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
             */
            while(rs.next())
            {
                data.add(new TipologiaAuto(rs.getString(1), rs.getString(2)));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return data;
    }
}

