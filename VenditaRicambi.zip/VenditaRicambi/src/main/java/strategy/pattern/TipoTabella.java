package strategy.pattern;

import javafx.collections.ObservableList;
/**
 * Questa classe permette di decidere quale strategia adottare, in base al tipo di tabella che si sceglie di creare,
 * e funge da Context del pattern Strategy.
 * @author Luca Amoroso
 * @see Tabella
 */
public class TipoTabella<E> {
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo Tabella.
     */
    private Tabella<E> tab;

    /**
     * Nel costruttore inizializzo una tabella, che potrà essere di un qualsiasi tipo.
     * @param x tabella che specificherà quali campi visualizzare
     */
    public TipoTabella(Tabella<E> x)
    {
        tab = x;
    }

    /**
     * Metodo che ritorna la lista di elementi da inserire nella tabella
     */
    public ObservableList<E> getElements()
    {
        return tab.crea();
    }
}
