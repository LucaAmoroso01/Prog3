package strategy.pattern;

import javafx.collections.ObservableList;

/**
 * Interfaccia che permette la gestione della creazione di tabelle risultanti dalle query e funge da IStrategy del
 * pattern Strategy
 * Il paramento E rappresenta il tipo generico, ciò significa che le classi che implementeranno questa classe potranno
 * avere una propria implementazione del metodo crea e soprattutto restituiranno un ObservableList di tipo diverso.
 * @author Luca Amoroso
 */
public interface Tabella<E> {
    /**
     * Metodo che ritorna la lista di elementi da inserire nella tabella nell'interfaccia utente
     */
    public ObservableList<E> crea();
}

