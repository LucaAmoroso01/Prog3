package strategy.pattern;

import application.Categoria;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;

import java.sql.ResultSet;

/**
 * Questa classe rappresenta un ConcreteStrategy del pattern Strategy e permette di inizializzare una tabella
 * contenente tutte le categorie contenute nel database visualizzate però solo nei campi codice e nome.
 * @author Luca Amoroso
 * @see Tabella
 */
public class Tabella2Cat implements Tabella<Categoria> {
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo ObservableList che accetta solo oggetti di tipo
     * Categoria.
     */
    @FXML
    private ObservableList<Categoria> data;

    /**
     * Nel costruttore assegno alla variabile istanza privata un ObservableList, per memorizzare successivamente
     * tutti le categorie presenti nel database.
     */
    public Tabella2Cat()
    {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo Categoria.
     * @return un ObservableList contenente tutti le categorie presenti nel database
     */
    @Override
    public ObservableList<Categoria> crea()
    {
        try
        {
            Database db = new Database();
            String sql = "Select codiceCategoria,nomeCategoria from venditaricambi.categoria";
            ResultSet rs = db.query(sql);
            /**
             * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
             */
            while(rs.next())
            {
                data.add(new Categoria(rs.getString(1), rs.getString(2),
                        ""));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return data;
    }
}


