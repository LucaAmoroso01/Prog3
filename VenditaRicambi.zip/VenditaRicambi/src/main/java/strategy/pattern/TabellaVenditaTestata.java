package strategy.pattern;

import application.VenditaTestata;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;

import java.sql.ResultSet;

/**
 * Questa classe rappresenta un ConcreteStrategy del pattern Strategy e permette di inizializzare una tabella
 * contenente tutte le vendite in testata contenute nel database.
 * @author Luca Amoroso
 * @see Tabella
 */
public class TabellaVenditaTestata implements Tabella<VenditaTestata> {
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo ObservableList che accetta solo oggetti di tipo
     * VenditaTestata.
     */
    @FXML
    private ObservableList<VenditaTestata> data;

    /**
     * Nel costruttore assegno alla variabile istanza privata un ObservableList, per memorizzare successivamente
     * tutte le vendite in testata presenti nel database.
     */
    public TabellaVenditaTestata()
    {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo VenditaTestata.
     * @return un ObservableList contenente tutte le vendite in testata presenti nel database
     */
    @Override
    public ObservableList<VenditaTestata> crea()
    {
        try
        {
            Database db = new Database();
            String sql = "Select * from venditaricambi.venditatestata";
            ResultSet rs = db.query(sql);
            /**
             * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
             */
            while(rs.next())
            {
                data.add(new VenditaTestata(rs.getInt(1), rs.getString(2),
                        rs.getString(3), rs.getString(4), rs.getDate(5),
                        rs.getDouble(6), rs.getString(7)));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return data;
    }
}
