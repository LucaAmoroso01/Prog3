package strategy.pattern;

import application.RicambioTipologia;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;

import java.sql.ResultSet;

/**
 * Questa classe rappresenta un ConcreteStrategy del pattern Strategy e permette di inizializzare una tabella
 * contenente tutti le associazioni ricambio-tipologia contenute nel database.
 * @author Luca Amoroso
 * @see Tabella
 */
public class TabellaRicambioTipologia implements Tabella<RicambioTipologia> {
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo ObservableList che accetta solo oggetti di tipo
     * RicambioTipologia.
     */
    @FXML
    private ObservableList<RicambioTipologia> data;

    /**
     * Nel costruttore assegno alla variabile istanza privata un ObservableList, per memorizzare successivamente
     * tutte le associazioni ricambio-tipologia presenti nel database.
     */
    public TabellaRicambioTipologia()
    {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo RicambioTipologia.
     * @return un ObservableList contenente tutte le associazioni ricambio-tipologia presenti nel database
     */
    @Override
    public ObservableList<RicambioTipologia> crea()
    {
        try
        {
            Database db = new Database();
            String sql = "Select * from venditaricambi.ricambiotipologia";
            ResultSet rs = db.query(sql);
            /**
             * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
             */
            while(rs.next())
            {
                data.add(new RicambioTipologia(rs.getString(1), rs.getString(2)));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return data;
    }
}

