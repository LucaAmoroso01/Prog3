package strategy.pattern;

import application.Ricambio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import singleton.pattern.Database;
import java.sql.ResultSet;

/**
 * Questa classe rappresenta un ConcreteStrategy del pattern Strategy e permette di inizializzare una tabella
 * contenente tutti i ricambi contenuti nel database, ma solo nelle voci codice e nome.
 * @author Luca Amoroso
 * @see Tabella
 */
public class Tabella2Ric implements Tabella<Ricambio>{
    /**
     * Variabile istanza privata che rappresenta un oggetto di tipo ObservableList che accetta solo oggetti di tipo
     * Ricambio.
     */
    @FXML
    private ObservableList<Ricambio> data;

    /**
     * Nel costruttore assegno alla variabile istanza privata un ObservableList, per memorizzare successivamente
     * tutti i ricambi presenti nel database.
     */
    public Tabella2Ric()
    {
        data = FXCollections.observableArrayList();
    }

    /**
     * Metodo che permette di popolare l'ObservableList con oggetti di tipo Ricambio.
     * @return un ObservableList contenente tutti i ricambi presenti nel database
     */
    @Override
    public ObservableList<Ricambio> crea()
    {
        try
        {
            Database db = new Database();
            String sql = "Select codiceRicambio,nomeRicambio from venditaricambi.ricambio";
            ResultSet rs = db.query(sql);
            /**
             * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
             */
            while(rs.next())
            {
                data.add(new Ricambio(rs.getString(1), rs.getString(2),
                        "",0,0,0));
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return data;
    }
}
