module com.example.venditaricambi {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires java.sql;
    requires mysql.connector.j;
    requires java.desktop;

    opens application to javafx.base;
    exports com.example.venditaricambi;
    exports visibilityInsert;
    opens visibilityInsert to javafx.fxml;
    opens com.example.venditaricambi to javafx.base, javafx.fxml;
}