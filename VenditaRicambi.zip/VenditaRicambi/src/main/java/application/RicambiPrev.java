package application;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 * Classe che permette la gestione e la visualizzazione nell'applicativo dei ricambi facenti parte dei preventivi.
 * @author Luca Amoroso
 */
public class RicambiPrev {
    /**
     * SimpleStringProperty, SimpleIntegerProperty e SimpleDoubleProperty permettono, in collaborazione con
     * le observable lists, di rendere degli elementi ascoltabili.
     * Ciò significa che se il valore di una variabile istanza viene modificato, questi cambiamenti si rifletteranno
     * automaticamente anche nell'interfaccia grafica.
     */
    private SimpleStringProperty codiceRicambio;
    private SimpleStringProperty nome;
    private SimpleStringProperty descrizione;
    private SimpleIntegerProperty quantita;
    private SimpleDoubleProperty costo;
    private SimpleStringProperty fornitore;
    private SimpleStringProperty categoria;

    /**
     * Costruttore di default.
     */
    public RicambiPrev() {
        codiceRicambio = new SimpleStringProperty("");
        nome = new SimpleStringProperty("");
        descrizione = new SimpleStringProperty("");
        costo = new SimpleDoubleProperty(0);
        quantita = new SimpleIntegerProperty(0);
        fornitore = new SimpleStringProperty("");
        categoria = new SimpleStringProperty("");
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param cod codiceRicambio
     * @param n nome
     * @param desc descrizione
     * @param quant quantità
     * @param cost costo
     * @param forn fornitore
     * @param cat categoria
     */
    public RicambiPrev(String cod, String n, String desc, double cost, int quant, String forn, String cat) {
        codiceRicambio = new SimpleStringProperty(cod);
        nome = new SimpleStringProperty(n);
        descrizione = new SimpleStringProperty(desc);
        costo = new SimpleDoubleProperty(cost);
        quantita = new SimpleIntegerProperty(quant);
        fornitore = new SimpleStringProperty(forn);
        categoria = new SimpleStringProperty(cat);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public String getCodiceRicambio() {
        return codiceRicambio.get();
    }

    public String getNome() {
        return nome.get();
    }

    public String getDescrizione() {
        return descrizione.get();
    }

    public double getCosto() {
        return costo.get();
    }

    public int getQuantita() {
        return quantita.get();
    }

    public String getFornitore() {
        return fornitore.get();
    }

    public String getCategoria() {
        return categoria.get();
    }
}
