package application;

import javafx.beans.property.SimpleStringProperty;

/**
 * Classe per la gestione delle tipologie auto a cui sono destinati i vari ricambi.
 * @author Luca Amoroso
 */
public class TipologiaAuto {
    private SimpleStringProperty nomeTipologia;
    private SimpleStringProperty descTipologia;

    /**
     * Costruttore di default.
     */
    public TipologiaAuto() {
        nomeTipologia = new SimpleStringProperty("");
        descTipologia = new SimpleStringProperty("");
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param nome nome della tipologia
     * @param desc descrizione della tipologia
     */
    public TipologiaAuto(String nome, String desc) {
        nomeTipologia = new SimpleStringProperty(nome);
        descTipologia = new SimpleStringProperty(desc);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setNomeTipologia(String nome) {
        nomeTipologia.set(nome);
    }

    public String getNomeTipologia() {
        return nomeTipologia.get();
    }

    public void setDescTipologia(String desc) {
        descTipologia.set(desc);
    }

    public String getDescTipologia() {
        return descTipologia.get();
    }
}
