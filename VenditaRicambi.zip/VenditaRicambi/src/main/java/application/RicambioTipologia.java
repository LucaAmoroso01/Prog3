package application;

import javafx.beans.property.SimpleStringProperty;

/**
 * Classe per la gestione delle associazioni tra ricambi e tipologie auto.
 * @author Luca Amoroso
 */
public class RicambioTipologia {
    private SimpleStringProperty codiceRicambio;
    private SimpleStringProperty nomeTipologia;

    /**
     * Costruttore di default.
     */
    public RicambioTipologia() {
        codiceRicambio = new SimpleStringProperty("");
        nomeTipologia = new SimpleStringProperty("");
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param cod codice del ricambio
     * @param nome nome della tipologia
     */
    public RicambioTipologia(String cod, String nome) {
        codiceRicambio = new SimpleStringProperty(cod);
        nomeTipologia = new SimpleStringProperty(nome);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setCodiceRicambio(String desc) {
        codiceRicambio.set(desc);
    }

    public String getCodiceRicambio() {
        return codiceRicambio.get();
    }

    public void setNomeTipologia(String nome) {
        nomeTipologia.set(nome);
    }

    public String getNomeTipologia() {
        return nomeTipologia.get();
    }
}
