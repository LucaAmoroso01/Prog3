package application;

import javafx.beans.property.SimpleStringProperty;

/**
 * Classe che permette la gestione dei fornitori.
 * @author Luca Amoroso
 */

public class Fornitore {
    /**
     * SimpleStringProperty, SimpleIntegerProperty e SimpleDoubleProperty permettono, in collaborazione con
     * le observable lists, di rendere degli elementi ascoltabili.
     * Ciò significa che se il valore di una variabile istanza viene modificato, questi cambiamenti si rifletteranno
     * automaticamente anche nell'interfaccia grafica.
     */
    private SimpleStringProperty codiceFornitore;
    private SimpleStringProperty nomeFornitore;
    private SimpleStringProperty partitaIVA;
    private SimpleStringProperty indirizzo;
    private SimpleStringProperty CAP;
    private SimpleStringProperty localita;
    private SimpleStringProperty nazione;

    /**
     * Costruttore di default
     */
    public Fornitore() {
        codiceFornitore = new SimpleStringProperty("");
        nomeFornitore = new SimpleStringProperty("");
        partitaIVA = new SimpleStringProperty("");
        indirizzo = new SimpleStringProperty("");
        CAP = new SimpleStringProperty("");
        localita = new SimpleStringProperty("");
        nazione = new SimpleStringProperty("");
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param cod codiceFornitore
     * @param nf nomeFornitore
     * @param part partitaIVA
     * @param ind indirizzo
     * @param cap CAP
     * @param loc località
     * @param naz nazione
     */
    public Fornitore(String cod, String nf, String part, String ind, String cap, String loc, String naz) {
        codiceFornitore = new SimpleStringProperty(cod);
        nomeFornitore = new SimpleStringProperty(nf);
        partitaIVA = new SimpleStringProperty(part);
        indirizzo = new SimpleStringProperty(ind);
        CAP = new SimpleStringProperty(cap);
        localita = new SimpleStringProperty(loc);
        nazione = new SimpleStringProperty(naz);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setCodiceFornitore(String cod) {
        codiceFornitore.set(cod);
    }

    public String getCodiceFornitore() {
        return codiceFornitore.get();
    }

    public void setNomeFornitore(String nf) {
        nomeFornitore.set(nf);
    }

    public String getNomeFornitore() {
        return nomeFornitore.get();
    }

    public void setPartitaIVA(String part) {
        partitaIVA.set(part);
    }

    public String getPartitaIVA() {
        return partitaIVA.get();
    }

    public void setIndirizzo(String ind) {
        indirizzo.set(ind);
    }

    public String getIndirizzo() {
        return indirizzo.get();
    }

    public void setCAP(String cap) {
        CAP.set(cap);
    }

    public String getCAP() {
        return CAP.get();
    }

    public void setLocalita(String loc) {
        localita.set(loc);
    }

    public String getLocalita() {
        return localita.get();
    }

    public void setNazione(String naz) {
        nazione.set(naz);
    }

    public String getNazione() {
        return nazione.get();
    }
}
