package application;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 * Classe per la gestione delle vendite in dettaglio.
 * @author Luca Amoroso
 */
public class VenditaDettaglio {
    private SimpleIntegerProperty codiceVendita;
    private SimpleStringProperty codiceRicambio;
    private SimpleDoubleProperty prezzoUnitario;
    private SimpleIntegerProperty quantitaVendita;
    private SimpleDoubleProperty prezzoRiga;

    /**
     * Costruttore di default.
     */
    public VenditaDettaglio() {
        codiceVendita = new SimpleIntegerProperty(0);
        codiceRicambio = new SimpleStringProperty("");
        prezzoUnitario = new SimpleDoubleProperty(0);
        quantitaVendita = new SimpleIntegerProperty(0);
        prezzoRiga = new SimpleDoubleProperty(0);
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param codVend codiceVendita
     * @param codRic codiceRicambio
     * @param uni prezzoUnitario
     * @param quantita quantitaVendita
     * @param riga prezzoRiga
     */
    public VenditaDettaglio(int codVend, String codRic, double uni, int quantita, double riga) {
        codiceVendita = new SimpleIntegerProperty(codVend);
        codiceRicambio = new SimpleStringProperty(codRic);
        prezzoUnitario = new SimpleDoubleProperty(uni);
        quantitaVendita = new SimpleIntegerProperty(quantita);
        prezzoRiga = new SimpleDoubleProperty(riga);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setCodiceVendita(int codVend) {
        codiceVendita.set(codVend);
    }

    public int getCodiceVendita() {
        return codiceVendita.get();
    }

    public void setCodiceRicambio(String codRic) {
        codiceRicambio.set(codRic);
    }

    public String getCodiceRicambio() {
        return codiceRicambio.get();
    }

    public void setPrezzoUnitario(double uni) {
        prezzoUnitario.set(uni);
    }

    public double getPrezzoUnitario() {
        return prezzoUnitario.get();
    }

    public void setQuantitaVendita(int quantita) {
        quantitaVendita.set(quantita);
    }

    public int getQuantitaVendita() {
        return quantitaVendita.get();
    }

    public void setPrezzoRiga(double riga) {
        prezzoRiga.set(riga);
    }

    public double getPrezzoRiga() {
        return prezzoRiga.get();
    }
}
