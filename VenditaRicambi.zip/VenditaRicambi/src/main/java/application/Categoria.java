package application;

import javafx.beans.property.SimpleStringProperty;

/**
 * Classe per la gestione delle categorie di cui possono far parte i ricambi.
 * @author Luca Amoroso
 */
public class Categoria {
    private SimpleStringProperty codiceCategoria;
    private SimpleStringProperty nomeCategoria;
    private SimpleStringProperty descrizione;

    /**
     * Costruttore di default.
     */
    public Categoria() {
        codiceCategoria = new SimpleStringProperty("");
        nomeCategoria = new SimpleStringProperty("");
        descrizione = new SimpleStringProperty("");
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param cod codiceCategoria
     * @param nome nomeCategoria
     * @param desc descrizione della categoria
     */
    public Categoria(String cod, String nome, String desc) {
        codiceCategoria = new SimpleStringProperty(cod);
        nomeCategoria = new SimpleStringProperty(nome);
        descrizione = new SimpleStringProperty(desc);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setCodiceCategoria(String cod) {
        codiceCategoria.set(cod);
    }

    public String getCodiceCategoria() {
        return codiceCategoria.get();
    }

    public void setNomeCategoria(String nome) {
        nomeCategoria.set(nome);
    }

    public String getNomeCategoria() {
        return nomeCategoria.get();
    }

    public void setDescrizione(String desc) {
        descrizione.set(desc);
    }

    public String getDescrizione() {
        return descrizione.get();
    }
}
