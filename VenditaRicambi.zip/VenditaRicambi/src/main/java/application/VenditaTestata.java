package application;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import singleton.pattern.Database;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

/**
 * Classe per la gestione delle vendite in testata.
 * @author Luca Amoroso
 */
public class VenditaTestata {
    private SimpleIntegerProperty codiceVendita;
    private SimpleStringProperty nomeAcquirente;
    private SimpleStringProperty cognomeAcquirente;
    private SimpleStringProperty codiceFiscale;
    private Date dataVendita;
    private SimpleDoubleProperty prezzoTotale;
    private SimpleStringProperty emailCliente;

    /**
     * Costruttore di default.
     */
    public VenditaTestata() {
        codiceVendita = new SimpleIntegerProperty(0);
        nomeAcquirente = new SimpleStringProperty("");
        cognomeAcquirente = new SimpleStringProperty("");
        codiceFiscale = new SimpleStringProperty("");
        dataVendita = new Date((Date.valueOf(LocalDate.now()).getYear()),Date.valueOf(LocalDate.now()).getMonth(), Date.valueOf(LocalDate.now()).getDay());
        prezzoTotale = new SimpleDoubleProperty(0);
        emailCliente = new SimpleStringProperty("");
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param nome nomeAcquirente
     * @param cognome cognomeAcquirente
     * @param cf codiceFiscale
     * @param dv dataVendita
     * @param pt prezzoTotale
     * @param ec emailCliente
     */
    public VenditaTestata(String nome, String cognome, String cf, Date dv, double pt, String ec) throws SQLException {
        Database db = new Database();
        ResultSet rs = db.query("select MAX(codiceVendita) from venditaricambi.venditatestata");
        rs.next();
        codiceVendita = new SimpleIntegerProperty(rs.getInt(1) + 1);
        nomeAcquirente = new SimpleStringProperty(nome);
        cognomeAcquirente = new SimpleStringProperty(cognome);
        codiceFiscale = new SimpleStringProperty(cf);
        dataVendita = new Date(dv.getYear(),dv.getMonth(),dv.getDay());
        prezzoTotale = new SimpleDoubleProperty(pt);
        emailCliente = new SimpleStringProperty(ec);
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param cod codiceVendita
     * @param nome nomeAcquirente
     * @param cognome cognomeAcquirente
     * @param cf codiceFiscale
     * @param dv dataVendita
     * @param pt prezzoTotale
     * @param ec emailCliente
     */
    public VenditaTestata(int cod, String nome, String cognome, String cf, Date dv, double pt, String ec) {
        codiceVendita = new SimpleIntegerProperty(cod);
        nomeAcquirente = new SimpleStringProperty(nome);
        cognomeAcquirente = new SimpleStringProperty(cognome);
        codiceFiscale = new SimpleStringProperty(cf);
        dataVendita = new Date(dv.getYear(),dv.getMonth(),dv.getDay());
        prezzoTotale = new SimpleDoubleProperty(pt);
        emailCliente = new SimpleStringProperty(ec);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setCodiceVendita() throws SQLException {
        Database db = new Database();
        ResultSet rs = db.query("select MAX(codiceVendita) from venditaricambi.venditatestata");
        rs.next();
        codiceVendita.set(rs.getInt(1) + 1);
    }

    public int getCodiceVendita() {
        return codiceVendita.get();
    }

    public void setNomeAcquirente(String nome) {
        nomeAcquirente.set(nome);
    }

    public String getNomeAcquirente() {
        return nomeAcquirente.get();
    }

    public void setCognomeAcquirente(String cognome) {
        cognomeAcquirente.set(cognome);
    }

    public String getCognomeAcquirente() {
        return cognomeAcquirente.get();
    }

    public void setCodiceFiscale(String cf) {
        codiceFiscale.set(cf);
    }

    public String getCodiceFiscale() {
        return codiceFiscale.get();
    }

    public void setDataVendita(Date dv) {
        dataVendita = dv;
    }

    public Date getDataVendita() {
        return dataVendita;
    }

    public void setPrezzoTotale(double pt) {
        prezzoTotale.set(pt);
    }

    public double getPrezzoTotale() {
        return prezzoTotale.get();
    }

    public void setEmailCliente(String ec) {
        emailCliente.set(ec);
    }

    public String getEmailCliente() {
        return emailCliente.get();
    }
}
