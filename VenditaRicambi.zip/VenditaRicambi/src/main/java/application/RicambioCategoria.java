package application;

import javafx.beans.property.SimpleStringProperty;

/**
 * Classe per la gestione delle associazioni tra ricambi e categorie.
 * @author Luca Amoroso
 */
public class RicambioCategoria {
    private SimpleStringProperty codiceRicambio;
    private SimpleStringProperty codiceCategoria;

    /**
     * Costruttore di default.
     */
    public RicambioCategoria() {
        codiceRicambio = new SimpleStringProperty("");
        codiceCategoria = new SimpleStringProperty("");
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param codRic codiceRicambio
     * @param codCat codiceCategoria
     */
    public RicambioCategoria(String codRic, String codCat) {
        codiceRicambio = new SimpleStringProperty(codRic);
        codiceCategoria = new SimpleStringProperty(codCat);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setCodiceRicambio(String codRic) {
        codiceRicambio.set(codRic);
    }

    public String getCodiceRicambio() {
        return codiceRicambio.get();
    }

    public void setCodiceCategoria(String codCat) {
        codiceCategoria.set(codCat);
    }

    public String getCodiceCategoria() {
        return codiceCategoria.get();
    }
}
