package application;

import javafx.beans.property.SimpleStringProperty;

/**
 * Classe per la gestione delle associazioni tra ricambi e fornitori.
 * @author Luca Amoroso
 */
public class RicambioFornitore {
    private SimpleStringProperty codiceRicambio;
    private SimpleStringProperty codiceFornitore;

    /**
     * Costruttore di default.
     */
    public RicambioFornitore() {
        codiceRicambio = new SimpleStringProperty("");
        codiceFornitore = new SimpleStringProperty("");
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param codRic codiceRicambio
     * @param codForn codiceFornitore
     */
    public RicambioFornitore(String codRic, String codForn) {
        codiceRicambio = new SimpleStringProperty(codRic);
        codiceFornitore = new SimpleStringProperty(codForn);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setCodiceRicambio(String codRic) {
        codiceRicambio.set(codRic);
    }

    public String getCodiceRicambio() {
        return codiceRicambio.get();
    }

    public void setCodiceFornitore(String codForn) {
        codiceFornitore.set(codForn);
    }

    public String getCodiceFornitore() {
        return codiceFornitore.get();
    }
}
