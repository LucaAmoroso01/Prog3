package application;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 * Classe che permette la gestione dei ricambi.
 * @author Luca Amoroso
 */

public class Ricambio {
    /**
     * SimpleStringProperty, SimpleIntegerProperty e SimpleDoubleProperty permettono, in collaborazione con
     * le observable lists, di rendere degli elementi ascoltabili.
     * Ciò significa che se il valore di una variabile istanza viene modificato, questi cambiamenti si rifletteranno
     * automaticamente anche nell'interfaccia grafica.
     */
    private SimpleStringProperty codiceRicambio;
    private SimpleStringProperty nome;
    private SimpleStringProperty descrizione;
    private SimpleIntegerProperty quantita;
    private SimpleDoubleProperty costo;
    private SimpleIntegerProperty sconto;

    /**
     * Costruttore di default.
     */
    public Ricambio() {
        codiceRicambio = new SimpleStringProperty("");
        nome = new SimpleStringProperty("");
        descrizione = new SimpleStringProperty("");
        quantita = new SimpleIntegerProperty(0);
        costo = new SimpleDoubleProperty(0);
        sconto = new SimpleIntegerProperty(0);
    }

    /**
     * Costruttore con parametri, che inizializza tutte le variabili istanza ai valori passati in input.
     * @param cod codiceRicambio
     * @param n nome
     * @param desc descrizione
     * @param quant quantità
     * @param cost costo
     * @param scon sconto
     */
    public Ricambio(String cod, String n, String desc, int quant, double cost, int scon) {
        codiceRicambio = new SimpleStringProperty(cod);
        nome = new SimpleStringProperty(n);
        descrizione = new SimpleStringProperty(desc);
        quantita = new SimpleIntegerProperty(quant);
        costo = new SimpleDoubleProperty(cost);
        sconto = new SimpleIntegerProperty(scon);
    }

    /**
     * Metodi set e get per ogni variabile istanza.
     */

    public void setCodiceRicambio(String cod) {
        codiceRicambio.set(cod);
    }

    public String getCodiceRicambio() {
        return codiceRicambio.get();
    }

    public void setNome(String n) {
        nome.set(n);
    }

    public String getNome() {
        return nome.get();
    }

    public void setDescrizione(String desc) {
        descrizione.set(desc);
    }

    public String getDescrizione() {
        return descrizione.get();
    }

    public void setQuantita(int quant) {
        quantita.set(quant);
    }

    public int getQuantita() {
        return quantita.get();
    }

    public void setCosto(double cost) {
        costo.set(cost);
    }

    public double getCosto() {
        return costo.get();
    }

    public void setSconto(int scon) {
        sconto.set(scon);
    }

    public int getSconto() {
        return sconto.get();
    }
}
