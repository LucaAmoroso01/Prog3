package com.example.venditaricambi;

import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ResourceBundle;

import javafx.scene.Cursor;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import strategy.pattern.*;
import visibilityInsert.*;
import application.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import singleton.pattern.Database;

import javax.swing.*;

/**
 * Classe che permette la gestione della scena della mia JavaFX application relativa all'inserimento di dati da parte
 * dell'amministratore.
 * @author Luca Amoroso
 */
public class InsertController {
    /**
     * Variabile istanza privata che rappresenta la risorsa di bundle associata al file FXML e può essere utilizzata
     * per localizzare stringhe e altre risorse in base alla localizzazione dell'applicazione.
     */
    @FXML
    private ResourceBundle resources;

    /**
     * Variabile istanza privata che rappresenta l'URL del file FXML che è stato dato al caricatore FXML durante
     * il processo di caricamento.
     */
    @FXML
    private URL location;

    /**
     * Variabili istanza private che rappresentano i vari campi di testo che vengono resi visibili in base alla tabella
     * nella quale si vuole fare un inserimento.
     */
    @FXML // fx:id="localita"
    private TextField localita;

    @FXML // fx:id="codiceCategoria"
    private TextField codiceCategoria;

    @FXML // fx:id="nomeRicambio"
    private TextField nomeRicambio;

    @FXML // fx:id="costo"
    private TextField costo;

    @FXML // fx:id="nomeFornitore"
    private TextField nomeFornitore;

    @FXML // fx:id="indirizzo"
    private TextField indirizzo;

    @FXML // fx:id="insert"
    private Button insert;

    @FXML // fx:id="back"
    private Button back;

    @FXML // fx:id="nomeCategoria"
    private TextField nomeCategoria;

    @FXML // fx:id="sconto"
    private TextField sconto;

    @FXML // fx:id="descrizioneRicambio"
    private TextField descrizioneRicambio;

    @FXML // fx:id="codiceFornitore"
    private TextField codiceFornitore;

    @FXML // fx:id="cap"
    private TextField cap;

    @FXML // fx:id="partitaIva"
    private TextField partitaIva;

    @FXML // fx:id="codiceRicambio"
    private TextField codiceRicambio;

    @FXML // fx:id="nazione"
    private TextField nazione;

    @FXML // fx:id="quantita"
    private TextField quantita;

    @FXML // fx:id="descrizioneCategoria"
    private TextField descrizioneCategoria;

    @FXML // fx:id="nomeTipologia"
    private TextField nomeTipologia;

    @FXML // fx:id="descTipologia"
    private TextField descTipologia;

    @FXML
    private TableView<Ricambio> tableViewRic;

    @FXML
    private TableView<Categoria> tableViewCat;

    @FXML
    private TableView<Fornitore> tableViewForn;

    @FXML
    private TableView<TipologiaAuto> tableViewTipo;

    @FXML
    private TableColumn<Ricambio,String> codiceRicambioCat;

    @FXML
    private TableColumn<Ricambio,String> nomeRicambioCat;

    @FXML
    private TableColumn<Categoria,String> codiceCategoriaRic;

    @FXML
    private TableColumn<Categoria,String> nomeCategoriaRic;

    @FXML
    private TableColumn<Fornitore,String> codiceFornitoreRic;

    @FXML
    private TableColumn<Fornitore,String> nomeFornitoreRic;

    @FXML
    private TableColumn<TipologiaAuto,String> nomeTipoRic;

    @FXML
    private TableColumn<TipologiaAuto,String> descTipoRic;

    /**
     * Variabile istanza privata relativa al menù a tendina che permette di scegliere la tabella nella quale effettuare
     * un inserimento, e che permette di rendere visibili dei campi di testo piuttosto che altri.
     */
    @FXML // fx:id="myComboBox"
    private ComboBox<String> myComboBox;

    /**
     * Variabile istanza privata di classe Database, che permetterà di connettersi al database per effettuare
     * degli inserimenti.
     */
    private Database db;

    /**
     * Metodo per la gestione dell'evento relativo all'aver premuto il tasto "inserisci" nell'interfaccia utente.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    @FXML
    void handleInsert(ActionEvent event) throws Exception {
        /**
         * Memorizzo il valore scelto nel menù a tendina, ossia la ComboBox, in un oggetto di tipo String.
         */
        String selectedValue = myComboBox.getValue();

        if (selectedValue == null)
            throw new EccezionePersonalizzata("\nErrore, scegliere una tabella nella quale effettuare un inserimento" +
                    " dal menù a tendina!");

        /**
         * Controllo a quale delle tabelle equivale la scelta, in base ad un confronto tra stringhe effettuato mediante
         * metodo equals. A questo punto carico le voci da inserire in base alla tabella scelta, in modo da far
         * visualizzare all'utente solo i campi relativi a quella tabella. Controllo che vengano inseriti tutti i campi
         * richiesti, ossia tutti quelli not null nel database, e che abbiano valori corretti (ad es. maggiori di 0).
         * Dopo aver inserito i dati corretti, viene preparata una query di inserimento apposito, tramite il metodo
         * insert relativo alla variabile istanza privata di tipo Database.
         * Al termine dell'operazione viene visualizzata una finestra che notifica che l'operazione è avvenuta
         * correttamente. Per questioni di leggibilità, utilizzo metodi privati, creati ad hoc per effettuare i vari
         * inserimenti.
         */

        if (selectedValue.equals("Categoria")) {
            insertCat();
        }

        if (selectedValue.equals("Fornitore")) {
            insertForn();
        }

        if (selectedValue.equals("Ricambio")) {
            insertRic();
        }

        if (selectedValue.equals("RicambioCategoria")) {
            insertRicCat();
        }

        if (selectedValue.equals("RicambioFornitore")) {
            insertRicForn();
        }

        if (selectedValue.equals("TipologiaAuto")) {
            insertTipo();
        }

        if (selectedValue.equals("RicambioTipologia")) {
            insertRicTipo();
        }
    }

    /**
     * Metodo che permette di tornare alla scena precedente rispetto a quella in cui ci troviamo,
     * ossia il layout dell'interfaccia utente relativo a "adminHome.fxml".
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleBack (ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("adminHome.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che viene chiamato dal FXMLLoader una volta che l'inizializzazione è avvenuta.
     * In questo caso lo utilizzo per creare ed inserire le voci che saranno contenute nel menù a tendina,
     * ossia l'oggetto di tipo ComboBox, ma anche per provare ad effettuare la connessione con il database.
     */
    @FXML
    void initialize() throws Exception {
        /**
         * Creo un ObservableList che conterrà solo oggetti di tipo String, i quali verranno poi caricati mediante
         * metodo apposito, setItems, all'interno del menù a tendina, ossia l'oggetto di tipo ComboBox.
         */
        ObservableList<String> items = FXCollections.observableArrayList("Categoria", "Fornitore","Ricambio",
                "TipologiaAuto","RicambioCategoria", "RicambioFornitore","RicambioTipologia");
        myComboBox.setItems(items);

        /**
         * Cambio il cursore da freccetta a manina quando si passa sulla ComboBox e sulle varie voci della stessa.
         */
        myComboBox.setOnMouseEntered(e -> {
            myComboBox.setCursor(Cursor.HAND);
        });

        myComboBox.setOnMouseExited(e -> {
            myComboBox.setCursor(Cursor.DEFAULT);
        });

        myComboBox.setCellFactory(listView -> new ListCell<String>() {
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    setOnMouseEntered(e -> setCursor(Cursor.HAND));
                    setOnMouseExited(e -> setCursor(Cursor.DEFAULT));
                } else {
                    setOnMouseEntered(null);
                    setOnMouseExited(null);
                }
            }
        });

        /**
         * Setto vari effetti relativi a diversi oggetti, per quanto riguarda gli eventi OnMouseEntered e OnMouseExited.
         */
        DropShadow shadow = new DropShadow();

        back.setOnMouseEntered(e -> {
            back.setEffect(shadow);
            back.setStyle("-fx-background-color: #8f6500;");
            back.setCursor(Cursor.HAND);
        });

        back.setOnMouseExited(e -> {
            back.setEffect(null);
            back.setStyle("-fx-background-color: #f4ad00;");
            back.setCursor(Cursor.DEFAULT);
        });

        insert.setOnMouseEntered(e -> {
            insert.setEffect(shadow);
            insert.setStyle("-fx-background-color: #3b4366;");
            insert.setCursor(Cursor.HAND);
        });

        insert.setOnMouseExited(e -> {
            insert.setEffect(null);
            insert.setStyle("-fx-background-color: #0b1541;");
            insert.setCursor(Cursor.DEFAULT);
        });

        /**
         * Clausola try-catch per provare ad effettuare la connessione al database.
         */
        try {
            db = new Database();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo che permette la gestione delle operazioni che scaturiscono dalla scelta della tabella nella quale
     * effettuare un inserimento all'interno del menù a tendina, ossia l'oggetto di tipo ComboBox.
     */
    @FXML
    void handleComboBox(ActionEvent event) {
        /**
         * Memorizzo il valore scelto nel menù a tendina, ossia la ComboBox, in un oggetto di tipo String.
         */
        String selectedValue = myComboBox.getValue();

        /**
         * Controllo che sia stato selezionato un valore e stampo nella console il valore scelto all'interno del menù.
         */
        if (selectedValue != null) {
            System.out.println("Tabella selezionata: " + selectedValue);
        }

        /**
         * Controllo quale sia il valore scelto nel menù a tendina, ossia nell'oggetto di tipo ComboBox, e, in base
         * alla scelta, permetto all'utente di visualizzare solo i campi relativi alla tabella nella quale vuole
         * effettuare un inserimento.
         */
        if (selectedValue.equals("Categoria")) {
            VisibilityInsertCat vis = new VisibilityInsertCat();
            vis.setVisibilityInsert(codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio,
                    descrizioneRicambio, quantita, costo, sconto,
                    tableViewRic, tableViewCat, tableViewForn, codiceRicambioCat, nomeRicambioCat, codiceCategoriaRic,
                    nomeCategoriaRic, codiceFornitoreRic, nomeFornitoreRic, nomeTipologia, descTipologia, tableViewTipo);
        }

        if (selectedValue.equals("Fornitore")) {
            VisibilityInsertForn vis = new VisibilityInsertForn();
            vis.setVisibilityInsert(codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio,
                    descrizioneRicambio, quantita, costo, sconto,
                    tableViewRic, tableViewCat, tableViewForn, codiceRicambioCat, nomeRicambioCat, codiceCategoriaRic,
                    nomeCategoriaRic, codiceFornitoreRic, nomeFornitoreRic, nomeTipologia, descTipologia, tableViewTipo);
        }

        if (selectedValue.equals("Ricambio")) {
            VisibilityInsertRic vis = new VisibilityInsertRic();
            vis.setVisibilityInsert(codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio,
                    descrizioneRicambio, quantita, costo, sconto,
                    tableViewRic, tableViewCat, tableViewForn, codiceRicambioCat, nomeRicambioCat, codiceCategoriaRic,
                    nomeCategoriaRic, codiceFornitoreRic, nomeFornitoreRic, nomeTipologia, descTipologia, tableViewTipo);
        }

        /**
         * Per le tabelle associazione, ossia quelle tra ricambio e categoria, fornitore o tipologia, visualizzo 2 tabelle,
         * una per il ricambio e una per, appunto, categoria, fornitore o tipologia, nei soli campi codice e nome.
         * In queste tabelle si può selezionare una tupla, in modo da creare una associazione tra le due, con conseguente
         * inserimento nella tabella associazione.
         */
        if (selectedValue.equals("RicambioCategoria")) {
            VisibilityInsertRicCat vis = new VisibilityInsertRicCat();
            vis.setVisibilityInsert(codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio,
                    descrizioneRicambio, quantita, costo, sconto,
                    tableViewRic, tableViewCat, tableViewForn, codiceRicambioCat, nomeRicambioCat, codiceCategoriaRic,
                    nomeCategoriaRic, codiceFornitoreRic, nomeFornitoreRic, nomeTipologia, descTipologia, tableViewTipo);

            codiceRicambioCat.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
            nomeRicambioCat.setCellValueFactory(new PropertyValueFactory<>("nome"));

            TipoTabella<Ricambio> tabRic = new TipoTabella<>(new Tabella2Ric());
            tableViewRic.setItems(tabRic.getElements());

            codiceCategoriaRic.setCellValueFactory(new PropertyValueFactory<>("codiceCategoria"));
            nomeCategoriaRic.setCellValueFactory(new PropertyValueFactory<>("nomeCategoria"));

            TipoTabella<Categoria> tabCat = new TipoTabella<>(new Tabella2Cat());
            tableViewCat.setItems(tabCat.getElements());

            tableViewRic.setRowFactory(tv -> {
                TableRow<Ricambio> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });

            tableViewCat.setRowFactory(tv -> {
                TableRow<Categoria> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }

        if (selectedValue.equals("RicambioFornitore")) {
            VisibilityInsertRicForn vis = new VisibilityInsertRicForn();
            vis.setVisibilityInsert(codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio,
                    descrizioneRicambio, quantita, costo, sconto,
                    tableViewRic, tableViewCat, tableViewForn, codiceRicambioCat, nomeRicambioCat, codiceCategoriaRic,
                    nomeCategoriaRic, codiceFornitoreRic, nomeFornitoreRic, nomeTipologia, descTipologia, tableViewTipo);

            codiceRicambioCat.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
            nomeRicambioCat.setCellValueFactory(new PropertyValueFactory<>("nome"));

            TipoTabella<Ricambio> tabRic = new TipoTabella<>(new Tabella2Ric());
            tableViewRic.setItems(tabRic.getElements());

            codiceFornitoreRic.setCellValueFactory(new PropertyValueFactory<>("codiceFornitore"));
            nomeFornitoreRic.setCellValueFactory(new PropertyValueFactory<>("nomeFornitore"));

            TipoTabella<Fornitore> tabForn = new TipoTabella<>(new Tabella2Forn());
            tableViewForn.setItems(tabForn.getElements());

            tableViewRic.setRowFactory(tv -> {
                TableRow<Ricambio> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });

            tableViewForn.setRowFactory(tv -> {
                TableRow<Fornitore> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }

        if (selectedValue.equals("TipologiaAuto")) {
            VisibilityInsertTipo vis = new VisibilityInsertTipo();
            vis.setVisibilityInsert(codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio,
                    descrizioneRicambio, quantita, costo, sconto,
                    tableViewRic, tableViewCat, tableViewForn, codiceRicambioCat, nomeRicambioCat, codiceCategoriaRic,
                    nomeCategoriaRic, codiceFornitoreRic, nomeFornitoreRic, nomeTipologia, descTipologia, tableViewTipo);
        }

        if (selectedValue.equals("RicambioTipologia")) {
            VisibilityInsertRicTipo vis = new VisibilityInsertRicTipo();
            vis.setVisibilityInsert(codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio,
                    descrizioneRicambio, quantita, costo, sconto,
                    tableViewRic, tableViewCat, tableViewForn, codiceRicambioCat, nomeRicambioCat, codiceCategoriaRic,
                    nomeCategoriaRic, codiceFornitoreRic, nomeFornitoreRic, nomeTipologia, descTipologia, tableViewTipo);

            codiceRicambioCat.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
            nomeRicambioCat.setCellValueFactory(new PropertyValueFactory<>("nome"));

            TipoTabella<Ricambio> tabRic = new TipoTabella<>(new Tabella2Ric());
            tableViewRic.setItems(tabRic.getElements());

            nomeTipoRic.setCellValueFactory(new PropertyValueFactory<>("nomeTipologia"));
            descTipoRic.setCellValueFactory(new PropertyValueFactory<>("descTipologia"));

            TipoTabella<TipologiaAuto> tabTipo = new TipoTabella<>(new TabellaTipologiaAuto());
            tableViewTipo.setItems(tabTipo.getElements());

            tableViewRic.setRowFactory(tv -> {
                TableRow<Ricambio> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });

            tableViewTipo.setRowFactory(tv -> {
                TableRow<TipologiaAuto> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }
    }

    /**
     * Metodo che si occupa della gestione dell'inserimento di una tupla nella tabella Categoria, in modo da rendere
     * più leggibile il codice, spostandolo dall'handleInsert.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    private void insertCat() throws Exception {
        /**
         * Istanzio un oggetto di tipo Categoria.
         */
        Categoria cat = new Categoria();

        /**
         * Inizializzo i campi ai valori immessi nell'interfaccia utente nel campo apposito.
         */
        cat.setCodiceCategoria(codiceCategoria.getText().toUpperCase());
        cat.setNomeCategoria(nomeCategoria.getText().toUpperCase());
        cat.setDescrizione(descrizioneCategoria.getText().toUpperCase());

        /**
         * Controllo che determinati campi non siano vuoti o abbiano valori errati, poichè in tal caso lancio
         * un'eccezione di tipo EccezionePersonalizzata da me implementata.
         */
        if (cat.getCodiceCategoria().isEmpty() || cat.getNomeCategoria().isEmpty())
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, compilare almeno i campi relativi" +
                    " al codice e al nome della categoria!");

        /**
         * Scrivo una stringa relativa alla query di inserimento, lasciando per ora i valori tramite "?",
         * ossia da immettere successivamente.
         */
        String q = "INSERT INTO venditaricambi.categoria (codiceCategoria,nomeCategoria,descrizioneCategoria)"
                + "VALUES (?,?,?)";

        /**
         * Preparo lo statement tramite il metodo insert della classe Database, che restituisce appunto un oggetto
         * di tipo PreparedStatement in cui inserire i valori prima di eseguire la query.
         */
        PreparedStatement preparedStmt = db.insert(q);

        /**
         * Inserisco i valori all'interno dell'oggetto di tipo PreparedStatement ed eseguo la query mediante
         * metodo apposito.
         */
        preparedStmt.setString (1, cat.getCodiceCategoria());
        preparedStmt.setString (2, cat.getNomeCategoria());
        preparedStmt.setString (3, cat.getDescrizione());

        /**
         * Controllo che non si verifichino violazioni dei vincoli di primary key e di foreign key.
         */
        try {
            preparedStmt.execute();
            /**
             * Visualizzo una finestra relativa al corretto avvenimento delle operazioni.
             */
            JOptionPane.showMessageDialog(null, "\nCategoria inserita correttamente!");
        }
        catch (SQLIntegrityConstraintViolationException e) {
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, esiste già una categoria con" +
                    " questo codice e/o con questo nome!");
        }
        finally {
            /**
             * Ripulisco i campi di testo a prescindere da se si è verificata un'eccezione o meno
             */
            codiceCategoria.clear();
            nomeCategoria.clear();
            descrizioneCategoria.clear();
        }
    }

    /**
     * Metodo che si occupa della gestione dell'inserimento di una tupla nella tabella Fornitore, in modo da rendere
     * più leggibile il codice, spostandolo dall'handleInsert.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    private void insertForn() throws Exception {
        Fornitore forn = new Fornitore();

        forn.setCodiceFornitore(codiceFornitore.getText().toUpperCase());
        forn.setNomeFornitore(nomeFornitore.getText().toUpperCase());
        forn.setPartitaIVA(partitaIva.getText().toUpperCase());
        forn.setIndirizzo(indirizzo.getText().toUpperCase());
        forn.setCAP(cap.getText().toUpperCase());
        forn.setLocalita(localita.getText().toUpperCase());
        forn.setNazione(nazione.getText().toUpperCase());

        if (forn.getCodiceFornitore().isEmpty() || forn.getNomeFornitore().isEmpty() ||
                forn.getPartitaIVA().isEmpty() || forn.getIndirizzo().isEmpty() || forn.getCAP().isEmpty() ||
                forn.getLocalita().isEmpty() || forn.getNazione().isEmpty())
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, compilare tutti i campi!");

        /**
         * Controllo che la partita iva e il cap inserito abbiano la giusta dimensione
         */
        if (forn.getPartitaIVA().length() != 11)
            throw new EccezionePersonalizzata("\nIl campo Partita Iva da te inserito non è formato da 11 cifre!");

        if (forn.getCAP().length() != 5)
            throw new EccezionePersonalizzata("\nIl campo Cap da te inserito non è formato da 5 cifre!");

        /**
         * Controllo, tramite regex, che le stringhe inserite possano effettivamente essere, rispettivamente, partite iva
         * o cap.
         */
        if (!forn.getPartitaIVA().matches("\\d{11}")) {
            partitaIva.clear();
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento della partita iva, la stringa inserita" +
                    " non rispetta lo standard, che richiede 11 cifre!");
        }

        if (!forn.getCAP().matches("\\d{5}")) {
            cap.clear();
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento del cap, la stringa inserita" +
                    " non rispetta lo standard, che richiede 5 cifre!");
        }


        String q = "INSERT INTO venditaricambi.fornitore (codiceFornitore,nomeFornitore,partitaIva,indirizzo," +
                "cap,localita,nazione) VALUES (?,?,?,?,?,?,?)";

        PreparedStatement preparedStmt = db.insert(q);

        preparedStmt.setString (1, forn.getCodiceFornitore());
        preparedStmt.setString (2, forn.getNomeFornitore());
        preparedStmt.setString (3, forn.getPartitaIVA());
        preparedStmt.setString (4, forn.getIndirizzo());
        preparedStmt.setString (5, forn.getCAP());
        preparedStmt.setString (6, forn.getLocalita());
        preparedStmt.setString (7, forn.getNazione());

        /**
         * Controllo che non si verifichino violazioni dei vincoli di primary key e di foreign key.
         */
        try {
            preparedStmt.execute();
            JOptionPane.showMessageDialog(null, "\nFornitore inserito correttamente!");
        }
        catch (SQLIntegrityConstraintViolationException e) {
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, esiste già un fornitore con" +
                    " questo codice e/o con questo nome!");
        }
        finally {
            codiceFornitore.clear();
            nomeFornitore.clear();
            partitaIva.clear();
            indirizzo.clear();
            cap.clear();
            localita.clear();
            nazione.clear();
        }
    }

    /**
     * Metodo che si occupa della gestione dell'inserimento di una tupla nella tabella Ricambio, in modo da rendere
     * più leggibile il codice, spostandolo dall'handleInsert.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    private void insertRic() throws Exception {
        Ricambio ric = new Ricambio();

        ric.setCodiceRicambio(codiceRicambio.getText().toUpperCase());
        ric.setNome(nomeRicambio.getText().toUpperCase());
        ric.setDescrizione(descrizioneRicambio.getText().toUpperCase());

        if (ric.getCodiceRicambio().isEmpty() || ric.getNome().isEmpty() || quantita.getText().isEmpty() ||
                costo.getText().isEmpty() || sconto.getText().isEmpty())
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, compilare tutti i campi," +
                    " ad eccezione di descrizione ricambio se non si vuole inserire!");

        /**
         * Visto che verrebbe generata un'eccezione se provassi a convertire una stringa vuota in un intero o in
         * un double, controllo prima se il textField associato è vuoto, in modo da non convertire il valore nel
         * caso in cui la stringa sia vuota. Se invece nel campo è stato inserito un valore, procedo alla
         * conversione ed al controllo dei valori interi e double.
         */
        try {
            ric.setQuantita(Integer.parseInt(quantita.getText()));
            ric.setCosto(Double.parseDouble(costo.getText()));
            ric.setSconto(Integer.parseInt(sconto.getText()));
        }
        catch (NumberFormatException e) {
            throw new EccezionePersonalizzata("\nNon è stato inserito un valore valido" +
                    " nei campi quantità e/o costo e/o sconto!");
        }

        if (ric.getQuantita() < 0 || ric.getCosto() < 0)
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, inserire valori non minori" +
                    " di 0 per quanto riguarda quantità e/o costo!");

        if (ric.getSconto() < 0 || ric.getSconto() > 100)
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, inserire un valore compreso tra 0" +
                    " e 100 per quanto riguarda lo sconto!");

        String q = "INSERT INTO venditaricambi.ricambio (codiceRicambio,nomeRicambio,descrizioneRicambio,quantita," +
                "costo,sconto)" + "VALUES (?,?,?,?,?,?)";

        PreparedStatement preparedStmt = db.insert(q);

        preparedStmt.setString (1, ric.getCodiceRicambio());
        preparedStmt.setString (2, ric.getNome());
        preparedStmt.setString (3, ric.getDescrizione());
        preparedStmt.setInt(4, ric.getQuantita());
        preparedStmt.setDouble(5, ric.getCosto());
        preparedStmt.setInt(6, ric.getSconto());

        /**
         * Controllo che non si verifichino violazioni dei vincoli di primary key e di foreign key.
         */
        try {
            preparedStmt.execute();
            JOptionPane.showMessageDialog(null, "\nRicambio inserito correttamente!");
        }
        catch (SQLIntegrityConstraintViolationException e) {
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, esiste già un ricambio con" +
                    " questo codice e/o con questo nome!");
        }
        finally {
            codiceRicambio.clear();
            nomeRicambio.clear();
            descrizioneRicambio.clear();
            quantita.clear();
            costo.clear();
            sconto.clear();
        }
    }

    /**
     * Metodo che si occupa della gestione dell'inserimento di una tupla nella tabella RicambioCategoria,
     * in modo da rendere più leggibile il codice, spostandolo dall'handleInsert.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    private void insertRicCat() throws Exception {
        /**
         * Recupero le selezioni effettuate nelle due tabelle,
         */
        Ricambio selectedRicambio = tableViewRic.getSelectionModel().getSelectedItem();
        Categoria selectedCategoria = tableViewCat.getSelectionModel().getSelectedItem();

        /**
         * Se non è stata effettuata una delle due selezioni, viene lanciata un'eccezione.
         */
        if (selectedRicambio == null || selectedCategoria == null) {
            /**
             * Pulisco la selezione, in modo da non avere determinate tuple selezionate anche dopo che si è verificato
             * un errore.
             */
            tableViewRic.getSelectionModel().clearSelection();
            tableViewCat.getSelectionModel().clearSelection();
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, selezionare un ricambio e una categoria" +
                    " da associare!");
        }

        /**
         * Creo un oggetto a partire dalle chiavi primarie delle tuple selezionate.
         */
        RicambioCategoria ricCat = new RicambioCategoria();

        ricCat.setCodiceRicambio(selectedRicambio.getCodiceRicambio());
        ricCat.setCodiceCategoria(selectedCategoria.getCodiceCategoria());

        String q = "INSERT INTO venditaricambi.ricambiocategoria (codiceRicambio, codiceCategoria)"
                + "VALUES (?,?)";

        PreparedStatement preparedStmt = db.insert(q);

        preparedStmt.setString(1, ricCat.getCodiceRicambio());
        preparedStmt.setString(2, ricCat.getCodiceCategoria());

        /**
         * Controllo che non si verifichino violazioni dei vincoli di primary key e di foreign key.
         */
        try {
            preparedStmt.execute();
            JOptionPane.showMessageDialog(null, "\nRicambioCategoria inserito" +
                    " correttamente!");
        }
        catch (SQLIntegrityConstraintViolationException e) {
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, esiste già un'associazione" +
                    " tra questo ricambio e questa categoria!");
        }
        finally {
            /**
             * Pulisco la selezione, in modo da non avere determinate tuple selezionate, a prescindere da se
             * l'operazione di inserimento è andata a buon fine o meno.
             */
            tableViewRic.getSelectionModel().clearSelection();
            tableViewCat.getSelectionModel().clearSelection();
        }
    }

    /**
     * Metodo che si occupa della gestione dell'inserimento di una tupla nella tabella RicambioFornitore,
     * in modo da rendere più leggibile il codice, spostandolo dall'handleInsert.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    private void insertRicForn() throws Exception {
        Ricambio selectedRicambio = tableViewRic.getSelectionModel().getSelectedItem();
        Fornitore selectedFornitore = tableViewForn.getSelectionModel().getSelectedItem();

        if (selectedRicambio == null || selectedFornitore == null) {
            /**
             * Pulisco la selezione, in modo da non avere determinate tuple selezionate anche dopo che si è verificato
             * un errore.
             */
            tableViewRic.getSelectionModel().clearSelection();
            tableViewForn.getSelectionModel().clearSelection();
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, selezionare un ricambio e un fornitore" +
                    " da associare!");
        }

        RicambioFornitore ricForn = new RicambioFornitore();

        ricForn.setCodiceRicambio(selectedRicambio.getCodiceRicambio());
        ricForn.setCodiceFornitore(selectedFornitore.getCodiceFornitore());

        String q = "INSERT INTO venditaricambi.ricambiofornitore (codiceRicambio, codiceFornitore)"
                + "VALUES (?,?)";

        PreparedStatement preparedStmt = db.insert(q);

        preparedStmt.setString(1, ricForn.getCodiceRicambio());
        preparedStmt.setString(2, ricForn.getCodiceFornitore());

        /**
         * Controllo che non si verifichino violazioni dei vincoli di primary key e di foreign key.
         */
        try {
            preparedStmt.execute();
            JOptionPane.showMessageDialog(null, "\nRicambioFornitore inserita" +
                    " correttamente!");
        }
        catch (SQLIntegrityConstraintViolationException e) {
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, esiste già un'associazione" +
                    " tra questo ricambio e questo fornitore!");
        }
        finally {
            /**
             * Pulisco la selezione, in modo da non avere determinate tuple selezionate, a prescindere da se
             * l'operazione di inserimento è andata a buon fine o meno.
             */
            tableViewRic.getSelectionModel().clearSelection();
            tableViewForn.getSelectionModel().clearSelection();
        }
    }

    /**
     * Metodo che si occupa della gestione dell'inserimento di una tupla nella tabella TipologiaAuto, in modo da rendere
     * più leggibile il codice, spostandolo dall'handleInsert.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    private void insertTipo() throws Exception {
        /**
         * Istanzio un oggetto di tipo TipologiaAuto.
         */
        TipologiaAuto tipo = new TipologiaAuto();

        /**
         * Inizializzo i campi ai valori immessi nell'interfaccia utente nel campo apposito.
         */
        tipo.setNomeTipologia(nomeTipologia.getText().toUpperCase());
        tipo.setDescTipologia(descTipologia.getText().toUpperCase());

        /**
         * Controllo che determinati campi non siano vuoti o abbiano valori errati, poichè in tal caso lancio
         * un'eccezione di tipo EccezionePersonalizzata da me implementata.
         */
        if (tipo.getNomeTipologia().isEmpty())
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, compilare almeno il campo relativo" +
                    " al nome della categoria!");

        /**
         * Scrivo una stringa relativa alla query di inserimento, lasciando per ora i valori tramite "?",
         * ossia da immettere successivamente.
         */
        String q = "INSERT INTO venditaricambi.tipologiaauto (nomeTipologia,descTipologia)"
                + "VALUES (?,?)";

        /**
         * Preparo lo statement tramite il metodo insert della classe Database, che restituisce appunto un oggetto
         * di tipo PreparedStatement in cui inserire i valori prima di eseguire la query.
         */
        PreparedStatement preparedStmt = db.insert(q);

        /**
         * Inserisco i valori all'interno dell'oggetto di tipo PreparedStatement ed eseguo la query mediante
         * metodo apposito.
         */
        preparedStmt.setString (1, tipo.getNomeTipologia());
        preparedStmt.setString (2, tipo.getDescTipologia());

        /**
         * Controllo che non si verifichino violazioni dei vincoli di primary key e di foreign key.
         */
        try {
            preparedStmt.execute();
            /**
             * Visualizzo una finestra relativa al corretto avvenimento delle operazioni.
             */
            JOptionPane.showMessageDialog(null, "\nTipologia auto inserita correttamente!");
        }
        catch (SQLIntegrityConstraintViolationException e) {
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, esiste già una tipologia auto con" +
                    " con questo nome!");
        }
        finally {
            /**
             * Ripulisco i campi di testo a prescindere da se si è verificata un'eccezione o meno
             */
            nomeTipologia.clear();
            descTipologia.clear();
        }
    }

    /**
     * Metodo che si occupa della gestione dell'inserimento di una tupla nella tabella RicambioTipologia,
     * in modo da rendere più leggibile il codice, spostandolo dall'handleInsert.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    private void insertRicTipo() throws Exception {
        Ricambio selectedRicambio = tableViewRic.getSelectionModel().getSelectedItem();
        TipologiaAuto selectedTipologia = tableViewTipo.getSelectionModel().getSelectedItem();

        if (selectedRicambio == null || selectedTipologia == null) {
            /**
             * Pulisco la selezione, in modo da non avere determinate tuple selezionate anche dopo che si è verificato
             * un errore.
             */
            tableViewRic.getSelectionModel().clearSelection();
            tableViewTipo.getSelectionModel().clearSelection();
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, selezionare un ricambio e una tipologia" +
                    " da associare!");
        }

        RicambioTipologia ricTipo = new RicambioTipologia();

        ricTipo.setCodiceRicambio(selectedRicambio.getCodiceRicambio());
        ricTipo.setNomeTipologia(selectedTipologia.getNomeTipologia());

        String q = "INSERT INTO venditaricambi.ricambiotipologia(codiceRicambio, nomeTipologia)"
                + "VALUES (?,?)";

        PreparedStatement preparedStmt = db.insert(q);

        preparedStmt.setString(1, ricTipo.getCodiceRicambio());
        preparedStmt.setString(2, ricTipo.getNomeTipologia());

        /**
         * Controllo che non si verifichino violazioni dei vincoli di primary key e di foreign key.
         */
        try {
            preparedStmt.execute();
            JOptionPane.showMessageDialog(null, "\nRicambioTipologia inserito" +
                    " correttamente!");
        }
        catch (SQLIntegrityConstraintViolationException e) {
            throw new EccezionePersonalizzata("\nErrore durante l'inserimento, esiste già un'associazione" +
                    " tra questo ricambio e questa tipologia!");
        }
        finally {
            /**
             * Pulisco la selezione, in modo da non avere determinate tuple selezionate, a prescindere da se
             * l'operazione di inserimento è andata a buon fine o meno.
             */
            tableViewRic.getSelectionModel().clearSelection();
            tableViewTipo.getSelectionModel().clearSelection();
        }
    }
}

