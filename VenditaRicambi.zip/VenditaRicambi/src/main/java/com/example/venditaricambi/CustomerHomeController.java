package com.example.venditaricambi;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Classe che permette di gestire la scena relativa alla pagina iniziale della dashboard relativa ai clienti.
 * @author Luca Amoroso
 */
public class CustomerHomeController {
    @FXML // fx:id="estimate"
    private Button estimate;

    @FXML // fx:id="purchase"
    private Button purchase;

    @FXML // fx:id="logout"
    private Button logout;

    private String email;

    /**
     * Metodo invocato al termine della fase di inizializzazione della scena da parte del FXMLLoader.
     */
    @FXML
    void initialize() {
        DropShadow shadow = new DropShadow();

        /**
         * Setto vari effetti per quanto riguarda l'hover sugli oggetti di tipo Button.
         */
        purchase.setOnMouseEntered(e -> {
            purchase.setEffect(shadow);
            purchase.setStyle("-fx-background-color: #8f6500;");
            purchase.setCursor(Cursor.HAND);
        });

        purchase.setOnMouseExited(e -> {
            purchase.setEffect(null);
            purchase.setStyle("-fx-background-color: #f4ad00;");
            purchase.setCursor(Cursor.DEFAULT);
        });

        estimate.setOnMouseEntered(e -> {
            estimate.setEffect(shadow);
            estimate.setStyle("-fx-background-color: #3b4366;");
            estimate.setCursor(Cursor.HAND);
        });

        estimate.setOnMouseExited(e -> {
            estimate.setEffect(null);
            estimate.setStyle("-fx-background-color: #0b1541;");
            estimate.setCursor(Cursor.DEFAULT);
        });

        logout.setOnMouseEntered(e -> {
            logout.setEffect(shadow);
            logout.setStyle("-fx-background-color: #a9a9a7;");
            logout.setCursor(Cursor.HAND);
        });

        logout.setOnMouseExited(e -> {
            logout.setEffect(null);
            logout.setStyle("-fx-background-color: white;");
            logout.setCursor(Cursor.DEFAULT);
        });
    }

    /**
     * Metodo che permette di caricare come nuova scena quella relativa al layout dell'interfaccia utente "purchase.fxml"
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handlePurchase(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("purchase.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**
     * Metodo che permette di caricare come nuova scena quella relativa al layout dell'interfaccia utente "estimate.fxml"
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleEstimate(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("estimate.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**
     * Metodo che permette di uscire dalla dashboard del cliente, reindirizzandolo alla home.
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleLogout(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("home.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }
}
