package com.example.venditaricambi;

import application.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import singleton.pattern.Database;
import strategy.pattern.Tabella1Cat;
import strategy.pattern.TipoTabella;

import javax.swing.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Classe che permette la gestione dei preventivi in base alla tipologia auto e ai ricambi che il cliente sceglie di
 * richiedere.
 * @author Luca Amoroso
 */
public class EstimateController {

    @FXML
    private TableColumn<RicambiPrev, String> nomeRicambio;

    @FXML
    private TableColumn<Object, Double> prezzoPrev;

    @FXML
    private TableColumn<RicambiPrev, String> ricambio;

    @FXML
    private Button prev;

    @FXML
    private Button back;

    @FXML
    private Button home;

    @FXML
    private TableColumn<RicambiPrev, String> descrizioneRicambio;

    @FXML
    private TableView<Ricambio> tableViewPrev;

    @FXML
    private Button returnPrev;

    @FXML
    private TableColumn<RicambiPrev, String> fornitore;

    @FXML
    private SplitPane split;

    @FXML
    private TableColumn<RicambiPrev, String> codiceRicambio;

    @FXML
    private TableColumn<RicambiPrev, Double> prezzo;

    @FXML
    private TableColumn<RicambiPrev, Integer> quantita;

    @FXML
    private TableColumn<Ricambio, Button> viewDetails;

    @FXML
    private TableColumn<Categoria, String> nomeCategoria;

    @FXML
    private TableColumn<Categoria, Button> addPrev;

    @FXML
    private ComboBox<String> myComboBoxTipo;

    @FXML
    private TableView<RicambiPrev> tableViewRic;

    @FXML
    private TableView<Categoria> tableViewCat;

    @FXML
    private Text tot;

    private Database db;

    private static ArrayList<String> listCat;

    private List<List<RicambioFornitore>> tutteCombinazioni;

    /**
     * Metodo che viene chiamata nella fase di inizializzazione della scena da parte del FXMLLoader.
     * @throws SQLException eccezioni legate a operazioni SQL, quindi relative al database
     */
    @FXML
    void initialize() throws SQLException {
        /**
         * Creo un arrayList che conterrà la lista della categorie di ricambi selezionati dal cliente.
         */
        listCat = new ArrayList<>();

        /**
         * Setto effetti e stile dei vari oggetti della scena.
         */
        DropShadow shadow = new DropShadow();

        back.setOnMouseEntered(e -> {
            back.setEffect(shadow);
            back.setStyle("-fx-background-color: #a9a9a7;");
            back.setCursor(Cursor.HAND);
        });

        back.setOnMouseExited(e -> {
            back.setEffect(null);
            back.setStyle("-fx-background-color: white;");
            back.setCursor(Cursor.DEFAULT);
        });

        home.setOnMouseEntered(e -> {
            home.setEffect(shadow);
            home.setStyle("-fx-background-color: #8f6500;");
            home.setCursor(Cursor.HAND);
        });

        home.setOnMouseExited(e -> {
            home.setEffect(null);
            home.setStyle("-fx-background-color: #f4ad00;");
            home.setCursor(Cursor.DEFAULT);
        });

        prev.setOnMouseEntered(e -> {
            prev.setEffect(shadow);
            prev.setStyle("-fx-background-color: #3b4366;");
            prev.setCursor(Cursor.HAND);
        });

        prev.setOnMouseExited(e -> {
            prev.setEffect(null);
            prev.setStyle("-fx-background-color: #0b1541;");
            prev.setCursor(Cursor.DEFAULT);
        });

        returnPrev.setOnMouseEntered(e -> {
            returnPrev.setEffect(shadow);
            returnPrev.setStyle("-fx-background-color: #a9a9a7;");
            returnPrev.setCursor(Cursor.HAND);
        });

        returnPrev.setOnMouseExited(e -> {
            returnPrev.setEffect(null);
            returnPrev.setStyle("-fx-background-color: white;");
            returnPrev.setCursor(Cursor.DEFAULT);
        });

        /**
         * Clausola try-catch per provare ad effettuare la connessione al database.
         */
        try {
            db = new Database();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        /**
         * Creo un ObservableList che conterrà solo oggetti di tipo String, i quali verranno caricati mediante
         * metodo apposito, setItems, all'interno di un oggetto di tipo ComboBox, ossia un menù a tendina,
         * per permettere di effettuare la scelta della tipologia auto.
         */
        ResultSet rsTipo = db.query("select nomeTipologia from venditaricambi.tipologiaauto");
        ObservableList<String> itemsTipo = FXCollections.observableArrayList();
        while (rsTipo.next())
            itemsTipo.add(rsTipo.getString(1));
        myComboBoxTipo.setItems(itemsTipo);

        myComboBoxTipo.setOnMouseEntered(e -> {
            myComboBoxTipo.setCursor(Cursor.HAND);
        });

        myComboBoxTipo.setOnMouseExited(e -> {
            myComboBoxTipo.setCursor(Cursor.DEFAULT);
        });

        myComboBoxTipo.setCellFactory(listView -> new ListCell<String>() {
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    setOnMouseEntered(e -> setCursor(Cursor.HAND));
                    setOnMouseExited(e -> setCursor(Cursor.DEFAULT));
                } else {
                    setOnMouseEntered(null);
                    setOnMouseExited(null);
                }
            }
        });

        /**
         * Mostro una tabella con le varie categorie dei ricambi che il cliente può scegliere ed inoltre nella seconda
         * colonna creo un Button per ogni riga per permettere di aggiungere quel pezzo al preventivo.
         */
        nomeCategoria.setCellValueFactory(new PropertyValueFactory<>("nomeCategoria"));
        addPrev.setCellFactory(param -> new ButtonCell());
        TipoTabella<Categoria> tab = new TipoTabella<>(new Tabella1Cat());
        tableViewCat.setItems(tab.getElements());
    }

    /**
     * Metodo che permette di tornare alla scena precedente rispetto a quella in cui ci troviamo,
     * ossia il layout dell'interfaccia utente relativo a "customerHome.fxml".
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleHome (ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("customerHome.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di tornare al layout di questa interfaccia relativo alla scelta della tipologia auto e dei
     * pezzi da inserire nel preventivo.
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleBack (ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("estimate.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di tornare al layout di questa intefaccia relativo a tutti i preventivi in base alle scelte
     * effettuate precedentemente.
     */
    @FXML
    void handleReturnPrev(ActionEvent event) {
        tableViewRic.setVisible(false);
        returnPrev.setVisible(false);
        tableViewPrev.setVisible(true);
        back.setVisible(true);
        tot.setVisible(false);
    }

    /**
     * Metodo che permette di effettuare la richiesta del preventivo in base alle scelte effettuate dal cliente.
     * @throws Exception eccezioni di tutti i tipi
     */
    @FXML
    void handlePrev(ActionEvent event) throws Exception {
        /**
         * Controllo che siano stati selezionati sia una tipologia auto che almeno un pezzo.
         */
        if (listCat.isEmpty()|| myComboBoxTipo.getValue() == null) {
            throw new EccezionePersonalizzata("\nErrore, selezionare almeno un pezzo e una tipologia auto!");
        }

        split.setVisible(true);
        tableViewPrev.setVisible(true);
        tableViewRic.setVisible(false);
        tableViewCat.setVisible(false);
        myComboBoxTipo.setVisible(false);
        prev.setVisible(false);
        returnPrev.setVisible(false);
        home.setVisible(false);
        back.setVisible(true);

        /**
         * Creo una mappa che avrà come chiave i nomi della categorie dei ricambi delle query, mentre come valori
         * delle liste di ricambi sempre relativi a quella query.
         */
        Map<String, List<RicambioFornitore>> risultatiPerCategoria = new HashMap<>();

        /**
         * Variabile booleana inizializzata a false che permette di verificare se ci sono categorie non vuote tra quelle
         * scelte dal cliente per il preventivo.
         */
        boolean oneCatNotEmpty = false;

        /**
         * Ciclo for per recuperare tutti i ricambi di ogni fornitore, con tipologia auto quella selezionata nella
         * ComboBox, e categorie dei ricambi, quelli selezionati tramite il Button "Aggiungi al preventivo"
         */
        for (String categoria : listCat) {
            List<RicambioFornitore> ricambioFornitore = new ArrayList<>();

            ResultSet rs = db.query("select r.codiceRicambio, f.codiceFornitore" +
                    " from (((((venditaricambi.ricambio r join venditaricambi.ricambiotipologia rt on r.codiceRicambio = rt.codiceRicambio)" +
                    " join venditaricambi.tipologiaauto t on rt.nomeTipologia = t.nomeTipologia)" +
                    " join venditaricambi.ricambiocategoria rc on r.codiceRicambio = rc.codiceRicambio)" +
                    " join venditaricambi.categoria c on rc.codiceCategoria = c.codiceCategoria)" +
                    " join venditaricambi.ricambiofornitore rf on r.codiceRicambio = rf.codiceRicambio)" +
                    " join venditaricambi.fornitore f on rf.codiceFornitore = f.codiceFornitore" +
                    " where rt.nomeTipologia='" + myComboBoxTipo.getValue() + "' and c.nomeCategoria = '" + categoria + "'");

            /**
             * Controllo che la query abbia effettivamente delle tuple che la soddisfano, invocando il metodo isBeforeFirst,
             * il quale restituisce true nel caso in cui si trovi prima della prima riga e ci siano delle tuple, mentre
             * false se invece non ci sono righe.
             */
            if (!rs.isBeforeFirst()) {
                JOptionPane.showMessageDialog(null, "Non esistono ricambi nella categoria " +
                        categoria);
            }
            /**
             * Scorro i ricambi risultanti dalle query, creando nuovi oggetti di tipo RicambioFornitore, i quali vengono aggiunti
             * alla lista di associazioni ricambio-fornitore che rappresenta il valore della map che avrà come chiave la categoria di cui fanno
             * parte quei ricambi. Inoltre setto a true una variabile booleana che mi permetterà di controllare se almeno
             * una delle categoria dei ricambi selezionate per il preventivo è non vuota.
             */
            else {
                oneCatNotEmpty = true;
                while(rs.next()) {
                    ricambioFornitore.add(new RicambioFornitore(rs.getString(1), rs.getString(2)));
                    risultatiPerCategoria.put(categoria, ricambioFornitore);
                }
            }
        }

        /**
         * Se non esistono pezzi in nessuna delle categorie di ricambi segnalo al cliente la situazione lanciano
         * un'eccezione.
         */
        if (!oneCatNotEmpty) {
            throw new EccezionePersonalizzata("\nErrore nella generazione dei preventivi, non esistono ricambi delle" +
                    " categorie selezionate!");
        }

        /**
         * Invoco il metodo che permette di generare tutte le combinazioni possibili.
         * Avvolgo la map in un ArrayList, in modo da avere come parametro un List<List<Ricambio>>, come richiesto dal
         * metodo generateCombinations.
         */
        tutteCombinazioni = generateCombinations(new ArrayList<>(risultatiPerCategoria.values()), 0);
        /**
         * Creo una tabella che permetta di visualizzare il prezzo del preventivo e un Button che rimandi ai dettagli
         * relativi a quel preventivo.
         */
        prezzoPrev.setCellValueFactory(new PropertyValueFactory<>("costo"));
        viewDetails.setCellFactory(param -> new DetailsCell());
        ObservableList<Ricambio> ricList = FXCollections.observableArrayList();

        /**
         * Scorro sulle liste di combinazioni esternamente e sulle associazioni ricambio-fornitore interne alla singola
         * combinazione.
         */
        for (List<RicambioFornitore> combinazione : tutteCombinazioni) {
            double cost = 0;
            for (RicambioFornitore ricambioForn : combinazione) {
                /**
                 * Recupero il costo e lo sconto del ricambio su cui ci troviamo
                 */
                ResultSet rsRicForn = db.query("select costo, sconto from venditaricambi.ricambio" +
                        " where codiceRicambio='" + ricambioForn.getCodiceRicambio() + "'");
                rsRicForn.next();
                /**
                 * Calcolo il prezzo del ricambio già scontato.
                 */
                cost += (rsRicForn.getDouble(1) - ((rsRicForn.getDouble(1)* rsRicForn.getInt(2) / 100)));
            }
            /**
             * Creo un nuovo ricambio per memorizzare il costo dello stesso, settando a 2 il numero di cifre dopo la virgola,
             * e arrotondando per eccesso se il costo è ".5".
             */
            Ricambio ric = new Ricambio();
            ric.setCosto(new BigDecimal(cost).setScale(2, RoundingMode.HALF_UP).doubleValue());
            /**
             * Aggiungo il costo all'ObservableList che permetterà di inserire i valori nella tabella.
             */
            ricList.add(ric);
        }

        /**
         * Visualizzo i prezzi dei preventivi e gli oggetti Button associati che permettono di visualizzare i dettagli
         * legati a quei preventivi.
         */
        tableViewPrev.setItems(ricList);
    }

    /**
     * Metodo che prermette di generare tutte le possibili combinazioni di ricambi dalle liste di ricambi fornite,
     * nelle quali ogni oggetto è un ricambio relativo ad una determinata categoria, ad una determinata tipologia auto
     * e ad un determinato fornitore.
     * @param inputLists liste di ricambi per ciascuna categoria.
     * @param index lndice corrente durante la ricorsione, quando raggiunge il size di inputLists significa che abbiamo
     * esaminato tutte le possibili combinazioni.
     * @return lista di tutte le possibili combinazioni di ricambi.
     */
    private static List<List<RicambioFornitore>> generateCombinations(List<List<RicambioFornitore>> inputLists, int index) {
        /**
         * Creo una lista di liste di oggetti di classe RicambioFornitore, che sarebbero le varie combinazioni tra ricambio
         * e fornitore appunto.
         */
        List<List<RicambioFornitore>> combinations = new ArrayList<>();

        /**
         * Caso base: quando index raggiunge la dimensione di inputLists, aggiunge una lista vuota alle combinazioni.
         */
        if (index == inputLists.size()) {
            combinations.add(new ArrayList<>());
        } else {
            /**
             * Itera su tutti i ricambi della lista corrente (inputLists.get(index)).
             */
            for (RicambioFornitore ricForn : inputLists.get(index)) {
                /**
                 * Richiamo ricorsivamente il metodo per le combinazioni successive (index + 1).
                 */
                for (List<RicambioFornitore> combination : generateCombinations(inputLists, index + 1)) {
                    /**
                     * Aggiungo il ricambio corrente alla combinazione corrente e aggiungo quest'ultima alla lista
                     * delle combinazioni.
                     */
                    combination.add(ricForn);
                    combinations.add(new ArrayList<>(combination));
                }
            }
        }
        return combinations;
    }

    /**
     * Classe innestata che permette di gestire la creazione e gli eventi OnAction degli oggetti Button relativi
     * all'aggiunta di una categoria di ricambi al preventivo.
     */
    private static class ButtonCell extends TableCell<Categoria, Button> {
        private Button addButton = new Button("Aggiungi al preventivo");

        public ButtonCell() {
            addButton.setOnMouseEntered(e -> {
                addButton.setCursor(Cursor.HAND);
            });

            addButton.setOnMouseExited(e -> {
                addButton.setCursor(Cursor.DEFAULT);
            });

            /**
             * Se clicco su aggiungi al preventivo aggiungo quella categoria al preventivo e modifico il Text del Button
             * a "rimuovi dal preventivo", in modo da poterlo anche rimuovere dal preventivo.
             */
            addButton.setOnAction(event -> {
                Categoria cat = getTableView().getItems().get(getIndex());

                if (addButton.getText().equals("Aggiungi al preventivo")) {
                    listCat.add(cat.getNomeCategoria());
                    addButton.setText("Rimuovi dal preventivo");
                } else if(addButton.getText().equals("Rimuovi dal preventivo")) {
                    listCat.remove(cat.getNomeCategoria());
                    addButton.setText("Aggiungi al preventivo");
                }
            });
        }

        /**
         * Effettuo l'override del metodo updateItem dalla superclasse Cell, in modo da inserire il button addButton
         * solo nelle righe della tabella non vuote, ossia quelle che contengono ricambi.
         */
        @Override
        protected void updateItem(Button item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
            } else {
                setGraphic(addButton);
            }
        }
    }

    /**
     * Classe innestata per la creazione e la gestione degli eventi OnAction sugli oggetti di tipo Button relativi
     * alla visualizzazione dei dettagli.
     */
    private class DetailsCell extends TableCell<Ricambio, Button> {
        private Button view = new Button("Visualizza dettagli");

        public DetailsCell() {
            view.setOnMouseEntered(e -> {
                view.setCursor(Cursor.HAND);
            });

            view.setOnMouseExited(e -> {
                view.setCursor(Cursor.DEFAULT);
            });

            view.setOnAction(event -> {
                /**
                 * Recupero il valore relativo alla riga su cui è stato premuto il Button view, in modo da sapere qual è
                 * il preventivo di cui si vogliono conoscere i dettagli.
                 */
                int row = getIndex();

                /**
                 * Creo una stringa per effettuare una query che restituisca i ricambi associati alla tipologia auto
                 * inserita dal cliente, alle categorie dei ricambi inserite dal cliente e ai diversi fornitori che
                 * forniscono quel/i ricambio/i.
                 */
                String q = "select distinct r.codiceRicambio, r.nomeRicambio, r.descrizioneRicambio," +
                        " (r.costo - ((r.costo*r.sconto)/100)) as prezzoUnitario, r.quantita, f.nomeFornitore, c.nomeCategoria" +
                        " from (((((venditaricambi.ricambio r join venditaricambi.ricambiotipologia rt on r.codiceRicambio = rt.codiceRicambio)" +
                        " join venditaricambi.tipologiaauto t on rt.nomeTipologia = t.nomeTipologia)" +
                        " join venditaricambi.ricambiocategoria rc on r.codiceRicambio = rc.codiceRicambio)" +
                        " join venditaricambi.categoria c on rc.codiceCategoria = c.codiceCategoria)" +
                        " join venditaricambi.ricambiofornitore rf on r.codiceRicambio = rf.codiceRicambio)" +
                        " join venditaricambi.fornitore f on rf.codiceFornitore = f.codiceFornitore" +
                        " where rt.nomeTipologia='" + myComboBoxTipo.getValue() + "' and c.nomeCategoria in (";

                for (int i=0; i<listCat.size(); i++) {
                    if (i == listCat.size() - 1)
                        q += ("'" + listCat.get(i) + "'");
                    else
                        q += ("'" + listCat.get(i) + "',");
                }

                q += ") and (";

                for (int i=0; i<tutteCombinazioni.get(row).size(); i++) {
                    if (i == tutteCombinazioni.get(row).size()-1)
                        q += ("(rf.codiceRicambio = '" + tutteCombinazioni.get(row).get(i).getCodiceRicambio() +"' and" +
                                " rf.codiceFornitore = '" + tutteCombinazioni.get(row).get(i).getCodiceFornitore()+ "'))");
                    else
                        q += ("(rf.codiceRicambio = '" + tutteCombinazioni.get(row).get(i).getCodiceRicambio() +"' and" +
                                " rf.codiceFornitore = '" + tutteCombinazioni.get(row).get(i).getCodiceFornitore()+ "') or ");
                }

                try {
                    /**
                     * Recupero i ricambi associati alla tipologia auto inserita dal cliente, alle categorie dei ricambi
                     * inserite dal cliente e ai diversi fornitori che forniscono quel/i ricambio/i.
                     */
                    ResultSet rs = db.query(q);

                    /**
                     * Creo un nuovo carrello per questo cliente, a prescindere da se esista o meno, che andrò a cancellare
                     * al termine di questo metodo e che mi serve solo per recuperare le informazioni relative ai ricambi
                     * facenti parte del preventivo.
                     */
                    String q2 = "insert into venditaricambi.carrello (emailCliente) values (?)";

                    PreparedStatement preparedStmt = db.insert(q2);
                    preparedStmt.setString(1, Email.getIstanza().getEmail());
                    preparedStmt.execute();

                    /**
                     * Dopo aver creato il carrello recupero l'id.
                     */
                    ResultSet rs2 = db.query("select MAX(idCarrello) from venditaricambi.carrello where emailCliente='" +
                            Email.getIstanza().getEmail() + "'");

                    rs2.next();

                    /**
                     * Inserisco i ricambi del preventivo nel carrello.
                     */
                    while (rs.next()) {
                        String q3 = "insert into venditaricambi.ricambiocarrello (idCarrello,codiceRicambio,quantitaRic)" +
                                " values (?,?,?)";

                        PreparedStatement preparedStmt2 = db.insert(q3);
                        preparedStmt2.setInt(1, rs2.getInt(1));
                        preparedStmt2.setString(2, rs.getString(1));
                        preparedStmt2.setInt(3, 1);
                        preparedStmt2.execute();
                    }
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }

                tableViewPrev.setVisible(false);
                tableViewRic.setVisible(true);
                back.setVisible(false);
                returnPrev.setVisible(true);
                tot.setVisible(true);

                /**
                 * Creo un ObservableList che avrà all'interno dei ricambi relativi a questo preventivo, quindi con
                 * fornitore e categoria associati.
                 */
                ObservableList<RicambiPrev> data = FXCollections.observableArrayList();
                RicambiPrev prevent;

                try {
                    /**
                     * Eseguo una query per ricavare il prezzo totale del carrello e lo formatto in modo da visualizzare la ","
                     * invece del "." e il simbolo dell'euro.
                     */
                    ResultSet rsTot = db.query("select ROUND(SUM(rc.quantitaRic*(r.costo-((r.costo*r.sconto)/100))),2)" +
                            " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on" +
                            " r.codiceRicambio = rc.codiceRicambio) join carrello c on rc.idCarrello = c.idCarrello" +
                            " where c.emailCliente='" + Email.getIstanza().getEmail() + "' and c.idCarrello = (select MAX(idCarrello)" +
                            " from venditaricambi.carrello where emailCliente = '" + Email.getIstanza().getEmail() + "')");
                    rsTot.next();
                    DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
                    String formattedTotal = decimalFormat.format(rsTot.getDouble(1));
                    tot.setText("Totale preventivo: " + formattedTotal + "€");

                    /**
                     * Eseguo una query per recuperare prezzo scontato e quantità richiesta dei ricambi del preventivo
                     * (che sarà 1).
                     */
                    ResultSet rsDetails = db.query("select (r.costo-((r.costo*r.sconto)/100)), rc.quantitaric" +
                            " from (venditaricambi.carrello c join venditaricambi.ricambiocarrello rc" +
                            " on c.idCarrello = rc.idCarrello)" +
                            " join ricambio r on rc.codiceRicambio = r.codiceRicambio" +
                            " where c.idCarrello = (select MAX(idCarrello)" +
                            " from venditaricambi.carrello where emailCliente = '" + Email.getIstanza().getEmail() + "')");

                    /**
                     * Creo un nuovo oggetto per ogni ricambio presente nel preventivo, in modo da inserirli poi
                     * nell'ObservableList che permetterà di visualizzarli.
                     */
                    ResultSet rsCart = db.query(q);
                    for (int i=0; i<tutteCombinazioni.get(row).size(); i++) {
                        rsCart.next();
                        rsDetails.next();

                        prevent = new RicambiPrev(rsCart.getString(1),rsCart.getString(2),
                                rsCart.getString(3),rsDetails.getDouble(1),rsDetails.getInt(2),
                                rsCart.getString(6),rsCart.getString(7));
                        data.add(prevent);
                    }
                } catch (SQLException e) {
                    System.out.println("\nEccezione");
                    throw new RuntimeException(e);
                }

                /**
                 * Setto i valori che dovranno essere visualizzati nella tabella relativa al carrello.
                 */
                codiceRicambio.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
                nomeRicambio.setCellValueFactory(new PropertyValueFactory<>("nome"));
                descrizioneRicambio.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
                prezzo.setCellValueFactory(new PropertyValueFactory<>("costo"));
                quantita.setCellValueFactory(new PropertyValueFactory<>("quantita"));
                ricambio.setCellValueFactory(new PropertyValueFactory<>("categoria"));
                fornitore.setCellValueFactory(new PropertyValueFactory<>("fornitore"));

                tableViewRic.setItems(data);

                /**
                 * Elimino il carrello creato appositamente per questo preventivo.
                 */
                try {
                    db.update("DELETE FROM venditaricambi.carrello WHERE idCarrello = (SELECT max_idCarrello FROM" +
                            " (SELECT MAX(idCarrello) as max_idCarrello FROM venditaricambi.carrello WHERE emailCliente ='" +
                            Email.getIstanza().getEmail() + "') AS tempTable)");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            });
        }

        /**
         * Effettuo l'override del metodo updateItem dalla superclasse Cell, in modo da inserire il button addButton
         * solo nelle righe della tabella non vuote, ossia quelle che contengono ricambi.
         */
        @Override
        protected void updateItem(Button item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
            } else {
                setGraphic(view);
            }
        }
    }
}
