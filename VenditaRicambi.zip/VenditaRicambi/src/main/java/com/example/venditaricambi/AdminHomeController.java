package com.example.venditaricambi;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Classe che permette di gestire la scena relativa alla pagina iniziale della dashboard relativa agli amministratori.
 * @author Luca Amoroso
 */
public class AdminHomeController {
    @FXML // fx:id="insert"
    private Button insert;

    @FXML // fx:id="delete"
    private Button delete;

    @FXML // fx:id="view"
    private Button view;

    @FXML // fx:id="apply"
    private Button apply;

    @FXML // fx:id="logout"
    private Button logout;

    /**
     * Metodo invocato al termine della fase di inizializzazione della scena da parte del FXMLLoader.
     */
    @FXML
    void initialize() {
        /**
         * Setto vari effetti relativi a diversi oggetti, per quanto riguarda gli eventi OnMouseEntered e OnMouseExited.
         */
        ammMouseEntered(insert);
        ammMouseExited(insert);

        ammMouseEntered(view);
        ammMouseExited(view);

        cliMouseEntered(delete);
        cliMouseExited(delete);

        cliMouseEntered(apply);
        cliMouseExited(apply);

        DropShadow shadow = new DropShadow();

        logout.setOnMouseEntered(e -> {
            logout.setEffect(shadow);
            logout.setStyle("-fx-background-color: #a9a9a7;");
            logout.setCursor(Cursor.HAND);
        });

        logout.setOnMouseExited(e -> {
            logout.setEffect(null);
            logout.setStyle("-fx-background-color: white;");
            logout.setCursor(Cursor.DEFAULT);
        });
    }

    /**
     * Metodo che permette di caricare come nuova scena quella relativa al layout dell'interfaccia utente "insert.fxml"
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleInsert(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("insert.fxml"));
        /**
         * Creo una nuova scena, a partire dal layout dell'interfaccia utente appena memorizzato nell'oggetto
         * di tipo Parent.
         */
        Scene tableViewScene = new Scene(tableViewParent);
        /**
         * Si crea un nuovo oggetto di tipo Stage, il quale è inizializzato alla finestra corrente associata all'evento.
         * In particolare, a partire dall'oggetto event di tipo ActionEvent si ottiene il nodo sorgente, tramite metodo
         * getSource, dopodichè si risale alla scena, tramite metodo getScene, e alla finestra associata a tale nodo,
         * tramite metodo getWindow.
         */
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        /**
         * Sostituisco la scena attuale con la scena appena creata, che avrà il layout dell'interfaccia utente caricato
         * da "insert.fxml".
         */
        window.setScene(tableViewScene);
        window.show();
    }

    /**
     * Metodo che permette di caricare come nuova scena quella relativa al layout dell'interfaccia utente "delete.fxml"
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleDelete(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("delete.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**
     * Metodo che permette di caricare come nuova scena quella relativa al layout dell'interfaccia utente "view.fxml"
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleView(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("view.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**
     * Metodo che permette di caricare come nuova scena quella relativa al layout dell'interfaccia utente "apply.fxml"
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleApply(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("apply.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node)event.getSource()).getScene().getWindow();
        window.setResizable(false);
        window.setScene(tableViewScene);
        window.show();
    }

    /**
     * /**
     * Metodo che permette di uscire dalla dashboard dell'amministratore, reindirizzandolo alla home.
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleLogout(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("home.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo per settare vari effetti quando si effettua un hover su un bottone.
     */
    private void ammMouseEntered(Button button) {
        DropShadow shadow = new DropShadow();

        button.setOnMouseEntered(e -> {
            button.setEffect(shadow);
            button.setStyle("-fx-background-color: #8f6500;");
            button.setCursor(Cursor.HAND);
        });
    }

    /**
     * Metodo per settare vari effetti quando con il cursore ci spostiamo fuori dall'area relativa ad un bottone.
     */
    private void ammMouseExited(Button button) {
        button.setOnMouseExited(e -> {
            button.setEffect(null);
            button.setStyle("-fx-background-color: #f4ad00;");
            button.setCursor(Cursor.DEFAULT);
        });
    }

    private void cliMouseEntered(Button button) {
        DropShadow shadow = new DropShadow();

        button.setOnMouseEntered(e -> {
            button.setEffect(shadow);
            button.setStyle("-fx-background-color: #3b4366;");
            button.setCursor(Cursor.HAND);
        });
    }

    private void cliMouseExited(Button button) {
        button.setOnMouseExited(e -> {
            button.setEffect(null);
            button.setStyle("-fx-background-color: #0b1541;");
            button.setCursor(Cursor.DEFAULT);
        });
    }
}
