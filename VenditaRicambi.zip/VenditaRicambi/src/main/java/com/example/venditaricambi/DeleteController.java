package com.example.venditaricambi;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Optional;
import java.util.ResourceBundle;

import application.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.stage.Stage;
import singleton.pattern.Database;
import strategy.pattern.*;
import visibilityDelView.*;

import javax.swing.*;

/**
 * Classe che permette la gestione dell'eliminazione di un oggetto dal database, in base alla tabella scelta.
 * @author Luca Amoroso
 */
public class DeleteController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<Categoria, String> codiceCategoria;

    @FXML
    private TableColumn<Categoria, String> nomeCategoria;

    @FXML
    private TableColumn<Categoria, String> descrizioneCategoria;

    @FXML
    private TableColumn<RicambioCategoria, String> codiceRicambioCatFK;

    @FXML
    private TableColumn<RicambioCategoria, String> codiceCategoriaFK;

    @FXML
    private TableColumn<RicambioFornitore, String> codiceRicambioFornFK;

    @FXML
    private TableColumn<RicambioFornitore, String> codiceFornitoreFK;

    @FXML
    private TableColumn<Fornitore, String> codiceFornitore;

    @FXML
    private TableColumn<Fornitore, String> nomeFornitore;

    @FXML
    private TableColumn<Fornitore, String> partitaIva;

    @FXML
    private TableColumn<Fornitore, String> indirizzo;

    @FXML
    private TableColumn<Fornitore, String> cap;

    @FXML
    private TableColumn<Fornitore, String> localita;

    @FXML
    private TableColumn<Fornitore, String> nazione;

    @FXML
    private TableColumn<Ricambio, String> codiceRicambio;

    @FXML
    private TableColumn<Ricambio, String> nomeRicambio;

    @FXML
    private TableColumn<Ricambio, String> descrizioneRicambio;

    @FXML
    private TableColumn<Ricambio, Integer> quantita;

    @FXML
    private TableColumn<Ricambio, Double> costo;

    @FXML
    private TableColumn<Ricambio, Integer> sconto;

    @FXML
    private Button back;

    @FXML
    private Button delete;

    @FXML
    private ComboBox<String> myComboBox;

    @FXML
    private TableView<Categoria> tableViewCat;

    @FXML
    private TableView<Fornitore> tableViewForn;

    @FXML
    private TableView<Ricambio> tableViewRic;

    @FXML
    private TableView<RicambioCategoria> tableViewRicCat;

    @FXML
    private TableView<RicambioFornitore> tableViewRicForn;

    @FXML
    private TableView<TipologiaAuto> tableViewTipo;

    @FXML
    private TableColumn<TipologiaAuto, String> nomeTipo;

    @FXML
    private TableColumn<TipologiaAuto, String> descTipo;

    @FXML
    private TableView<RicambioTipologia> tableViewRicTipo;

    @FXML
    private TableColumn<RicambioTipologia, String> codiceRicambioTipo;

    @FXML
    private TableColumn<RicambioTipologia, String> nomeTipoRic;

    private Database db;

    /**
     * Metodo che permette di tornare alla scena precedente rispetto a quella in cui ci troviamo,
     * ossia il layout dell'interfaccia utente relativo a "adminHome.fxml".
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleBack (ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("adminHome.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di gestire le operazioni derivanti dal click del bottone "Elimina".
     * @throws Exception eccezioni di qualsiasi tipo
     */
    @FXML
    void handleDelete(ActionEvent event) throws Exception {
        /**
         * Memorizzo in un oggetto di tipo String la scelta effettuata dal menù a tendina, rappresentato dalla ComboBox.
         */
        String selectedValue = myComboBox.getValue();

        /**
         * Se non è stata effettuata nessuna scelta e si preme il tasto "Elimina", viene lanciata un'eccezione con
         * un messaggio di errore.
         */
        if (selectedValue == null) {
            throw new EccezionePersonalizzata("\nScegliere una tabella dalla quale eliminare!");
        }

        /**
         * Una volta effettuata la scelta della tabella da cui eliminare dal menù a tendina, ossia nella ComboBox,
         * si procede alla scelta dell'oggetto da eliminare all'interno della tabella scelta.
         * Se non si è scelto nessun oggetto da eliminare, viene lanciata un'eccezione con un messaggio di errore.
         * Se invece si è scelto un oggetto, viene visualizzato un alert che chiede se si è sicuri di voler eliminare
         * quell'oggetto e, nel caso in cui si prema "ok", si procede all'eliminazione vera e propria dal database.
         * Una volta avvenuta l'eliminazione, viene visualizzato un messaggio che ne certifica appunto l'eliminazione
         * e viene eliminata anche la tupla relativa all'oggetto eliminato dalla tabella visualizzata.
         * Per questioni di leggibilità, vengono invocati metodi privati che gestiscono le eliminazioni in modo apposito
         * per quella determinata tabella.
         */
        if (selectedValue.equals("Categoria")) {
            deleteCat();
        }

        if (selectedValue.equals("Fornitore")) {
            deleteForn();
        }

        if (selectedValue.equals("Ricambio")) {
            deleteRic();
        }

        if (selectedValue.equals("RicambioCategoria")) {
            deleteRicCat();
        }

        if (selectedValue.equals("RicambioFornitore")) {
            deleteRicForn();
        }

        if (selectedValue.equals("TipologiaAuto")) {
            deleteTipo();
        }

        if (selectedValue.equals("RicambioTipologia")) {
            deleteRicTipo();
        }
    }

    /**
     * Metodo che permette la gestione delle operazioni che scaturiscono dalla scelta della tabella dalla quale
     * effettuare un'eliminazione all'interno del menù a tendina, ossia l'oggetto di tipo ComboBox.
     * Vengono resi visibili alcuni oggetti e altri no, in base alla scelta effettuata nel menù a tendina, e, sempre in
     * base alla scelta effettuata, vengono eseguite delle query che permettono di mostrare le tuple contenute nella
     * tabella selezionata.
     */
    @FXML
    void handleComboBox(ActionEvent event) {
        String selectedValue = myComboBox.getValue();

        if (selectedValue.equals("Categoria")) {
            /**
             * Creo un oggetto di tipo VisibilityDelViewCat per settare la visibilità degli oggetti relativi alla tabella
             * scelta tramite il menù a tendina, ossia la ComboBox. In base alla classe dell'oggetto che chiama il
             * metodo setVisibilityDelete, verrà invocato il metodo apposito per quell'oggetto.
             */
            VisibilityDelViewCat vis = new VisibilityDelViewCat();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            /**
             * Setto i valori da visualizzare nelle varie celle, servendomi del metodo setCellValueFactory, ed in
             * particolare setto il valore della cella tramite il costruttore di PropertyValueFactory, che prende
             * la variabile istanza privata, relativa alla classe apposita.
             */
            cellCat();

            /**
             * Utilizzo l'equivalente dei ConcreteStrategy da me definiti nel package strategy.pattern per creare
             * le tabelle i cui dati sono risultanti da una query che prende tutte le tuple relative alla tabella
             * scelta. Infine setto gli elementi della tabella a partire dal metodo getElements della classe TipoTabella,
             * ossia l'equivalente del Context nel pattern Strategy.
             */
            TipoTabella<Categoria> tab = new TipoTabella<>(new TabellaCategoria());
            tableViewCat.setItems(tab.getElements());

            tableViewCat.setRowFactory(tv -> {
                TableRow<Categoria> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }

        if (selectedValue.equals("Fornitore")) {
            VisibilityDelViewForn vis = new VisibilityDelViewForn();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            cellForn();

            TipoTabella<Fornitore> tab = new TipoTabella<>(new TabellaFornitore());
            tableViewForn.setItems(tab.getElements());

            tableViewForn.setRowFactory(tv -> {
                TableRow<Fornitore> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }

        if (selectedValue.equals("Ricambio")) {
            VisibilityDelViewRic vis = new VisibilityDelViewRic();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            cellRic();

            TipoTabella<Ricambio> tab = new TipoTabella<>(new TabellaRicambio());
            tableViewRic.setItems(tab.getElements());

            tableViewRic.setRowFactory(tv -> {
                TableRow<Ricambio> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }

        if (selectedValue.equals("RicambioCategoria")) {
            VisibilityDelViewRicCat vis = new VisibilityDelViewRicCat();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            cellRicCat();

            TipoTabella<RicambioCategoria> tab = new TipoTabella<>(new TabellaRicambioCategoria());
            tableViewRicCat.setItems(tab.getElements());

            tableViewRicCat.setRowFactory(tv -> {
                TableRow<RicambioCategoria> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }

        if (selectedValue.equals("RicambioFornitore")) {
            VisibilityDelViewRicForn vis = new VisibilityDelViewRicForn();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            cellRicForn();

            TipoTabella<RicambioFornitore> tab = new TipoTabella<>(new TabellaRicambioFornitore());
            tableViewRicForn.setItems(tab.getElements());

            tableViewRicForn.setRowFactory(tv -> {
                TableRow<RicambioFornitore> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }

        if (selectedValue.equals("TipologiaAuto")) {
            VisibilityDelViewTipo vis = new VisibilityDelViewTipo();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
                    tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
                    costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
                    codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            cellTipo();

            TipoTabella<TipologiaAuto> tab = new TipoTabella<>(new TabellaTipologiaAuto());
            tableViewTipo.setItems(tab.getElements());

            tableViewTipo.setRowFactory(tv -> {
                TableRow<TipologiaAuto> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }

        if (selectedValue.equals("RicambioTipologia")) {
            VisibilityDelViewRicTipo vis = new VisibilityDelViewRicTipo();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
                    tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
                    costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
                    codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            cellRicTipo();

            TipoTabella<RicambioTipologia> tab = new TipoTabella<>(new TabellaRicambioTipologia());
            tableViewRicTipo.setItems(tab.getElements());

            tableViewRicTipo.setRowFactory(tv -> {
                TableRow<RicambioTipologia> row = new TableRow<>();

                row.setOnMouseEntered(eventEnt ->  {
                    if (!row.isEmpty())
                        row.setCursor(Cursor.HAND);
                });

                row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

                return row;
            });
        }
    }

    /**
     * Metodo che viene chiamato dal FXMLLoader una volta che l'inizializzazione è avvenuta.
     * In questo caso lo utilizzo per creare ed inserire le voci che saranno contenute nel menù a tendina,
     * ossia l'oggetto di tipo ComboBox.
     */
    @FXML
    void initialize() {
        /**
         * Creo un ObservableList che conterrà solo oggetti di tipo String, i quali verranno poi caricati mediante
         * metodo apposito, setItems, all'interno del menù a tendina, ossia l'oggetto di tipo ComboBox.
         */
        ObservableList<String> items = FXCollections.observableArrayList("Categoria", "Fornitore","Ricambio",
                "RicambioCategoria", "RicambioFornitore","TipologiaAuto","RicambioTipologia");
        myComboBox.setItems(items);

        /**
         * Setto vari effetti relativi a diversi oggetti, per quanto riguarda gli eventi OnMouseEntered e OnMouseExited.
         */
        myComboBox.setOnMouseEntered(e -> {
            myComboBox.setCursor(Cursor.HAND);
        });

        myComboBox.setOnMouseExited(e -> {
            myComboBox.setCursor(Cursor.DEFAULT);
        });

        myComboBox.setCellFactory(listView -> new ListCell<String>() {
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    setOnMouseEntered(e -> setCursor(Cursor.HAND));
                    setOnMouseExited(e -> setCursor(Cursor.DEFAULT));
                } else {
                    setOnMouseEntered(null);
                    setOnMouseExited(null);
                }
            }
        });

        DropShadow shadow = new DropShadow();

        back.setOnMouseEntered(e -> {
            back.setEffect(shadow);
            back.setStyle("-fx-background-color: #8f6500;");
            back.setCursor(Cursor.HAND);
        });

        back.setOnMouseExited(e -> {
            back.setEffect(null);
            back.setStyle("-fx-background-color: #f4ad00;");
            back.setCursor(Cursor.DEFAULT);
        });

        delete.setOnMouseEntered(e -> {
            delete.setEffect(shadow);
            delete.setStyle("-fx-background-color: #3b4366;");
            delete.setCursor(Cursor.HAND);
        });

        delete.setOnMouseExited(e -> {
            delete.setEffect(null);
            delete.setStyle("-fx-background-color: #0b1541;");
            delete.setCursor(Cursor.DEFAULT);
        });

        /**
         * Clausola try-catch per provare ad effettuare la connessione al database.
         */
        try {
            db = new Database();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Metodo privato che restituisce un valore booleano true se è stato premuto "ok" o un valore booleano false se
     * è stato premuto "annulla". Viene creato un oggetto di classe Alert, di tipo CONFIRMATION, il cui messaggio è
     * quello passato in input. Se viene premuto "ok" allora il metodo restituisce true, altrimenti restituisce false.
     * @param message stringa passata in input che viene visualizzata come messaggio dell'alert
     * @return valore booleano in base alla scelta effettuata
     */
    private boolean showConfirmationDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Conferma eliminazione");
        alert.setHeaderText(null);
        alert.setContentText(message);

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    /**
     * Metodi privati che permettono la gestione apposita dell'eliminazione di tuple dalla tabella relativa.
     * @throws Exception eccezioni di tutti i tipi
     */

    private void deleteCat() throws Exception {
        Categoria selectedCategoria = tableViewCat.getSelectionModel().getSelectedItem();

        if (selectedCategoria == null) {
            throw new EccezionePersonalizzata("\nSelezionare un oggetto da eliminare!");
        }

        String selectedPK = selectedCategoria.getCodiceCategoria();
        boolean confirmed = showConfirmationDialog("Eliminare l'oggetto selezionato?");

        if (confirmed) {
            db.update("delete from venditaricambi.categoria where codiceCategoria='" + selectedPK + "'");

            JOptionPane.showMessageDialog(null, "\nEliminazione da Categoria avvenuta " +
                    "correttamente!");

            tableViewCat.getItems().remove(selectedCategoria);
        }

        tableViewCat.getSelectionModel().clearSelection();
    }

    private void deleteForn() throws Exception {
        Fornitore selectedFornitore = tableViewForn.getSelectionModel().getSelectedItem();

        if (selectedFornitore == null) {
            throw new EccezionePersonalizzata("\nSelezionare un oggetto da eliminare!");
        }

        String selectedPK = selectedFornitore.getCodiceFornitore();
        boolean confirmed = showConfirmationDialog("Eliminare l'oggetto selezionato?");

        if (confirmed) {
            db.update("delete from venditaricambi.fornitore where codiceFornitore='" + selectedPK + "'");

            JOptionPane.showMessageDialog(null, "\nEliminazione da Fornitore avvenuta " +
                    "correttamente!");

            tableViewForn.getItems().remove(selectedFornitore);
        }

        tableViewForn.getSelectionModel().clearSelection();
    }

    private void deleteRic() throws Exception {
        Ricambio selectedRicambio = tableViewRic.getSelectionModel().getSelectedItem();

        if (selectedRicambio == null) {
            throw new EccezionePersonalizzata("\nSelezionare un oggetto da eliminare!");
        }

        String selectedPK = selectedRicambio.getCodiceRicambio();
        boolean confirmed = showConfirmationDialog("Eliminare l'oggetto selezionato?");

        if (confirmed) {
            try {
                db.update("delete from venditaricambi.ricambio where codiceRicambio='" + selectedPK + "'");
            }
            catch (SQLIntegrityConstraintViolationException e) {
                throw new EccezionePersonalizzata("\nNon puoi eliminare un ricambio il cui codice si trova" +
                        " nella tabella VenditaDettaglio. \nSe vuoi eliminare questo ricambio devi prima procedere" +
                        " all'eliminazione della tupla relativa a quel ricambio nella tabella Ricambio.");
            }

            JOptionPane.showMessageDialog(null, "\nEliminazione da Ricambio avvenuta " +
                    "correttamente!");

            tableViewRic.getItems().remove(selectedRicambio);
        }

        tableViewRic.getSelectionModel().clearSelection();
    }

    private void deleteRicCat() throws Exception {
        RicambioCategoria selectedRicambioCategoria = tableViewRicCat.getSelectionModel().getSelectedItem();

        if (selectedRicambioCategoria == null) {
            throw new EccezionePersonalizzata("\nSelezionare un oggetto da eliminare!");
        }

        String selectedRic = selectedRicambioCategoria.getCodiceRicambio();
        String selectedCat = selectedRicambioCategoria.getCodiceCategoria();
        boolean confirmed = showConfirmationDialog("Eliminare l'oggetto selezionato?");

        if (confirmed) {
            db.update("delete from venditaricambi.ricambiocategoria where codiceRicambio='" + selectedRic +
                    "' and codiceCategoria='" + selectedCat + "'");

            JOptionPane.showMessageDialog(null, "\nEliminazione da RicambioCategoria " +
                    "avvenuta correttamente!");

            tableViewRicCat.getItems().remove(selectedRicambioCategoria);
        }
        tableViewRicCat.getSelectionModel().clearSelection();
    }

    private void deleteRicForn() throws Exception {
        RicambioFornitore selectedRicambioFornitore = tableViewRicForn.getSelectionModel().getSelectedItem();

        if (selectedRicambioFornitore == null) {
            throw new EccezionePersonalizzata("\nSelezionare un oggetto da eliminare!");
        }

        String selectedRic = selectedRicambioFornitore.getCodiceRicambio();
        String selectedForn = selectedRicambioFornitore.getCodiceFornitore();
        boolean confirmed = showConfirmationDialog("Eliminare l'oggetto selezionato?");

        if (confirmed) {
            db.update("delete from venditaricambi.ricambiofornitore where codiceRicambio='" + selectedRic +
                    "' and codiceFornitore='" + selectedForn + "'");

            JOptionPane.showMessageDialog(null, "\nEliminazione da RicambioFornitore " +
                    "avvenuta correttamente!");

            tableViewRicForn.getItems().remove(selectedRicambioFornitore);
        }

        tableViewRicForn.getSelectionModel().clearSelection();
    }

    private void deleteTipo() throws Exception {
        TipologiaAuto selectedTipologia = tableViewTipo.getSelectionModel().getSelectedItem();

        if (selectedTipologia == null) {
            throw new EccezionePersonalizzata("\nSelezionare un oggetto da eliminare!");
        }

        String selectedPK = selectedTipologia.getNomeTipologia();
        boolean confirmed = showConfirmationDialog("Eliminare l'oggetto selezionato?");

        if (confirmed) {
            db.update("delete from venditaricambi.tipologiaauto where nomeTipologia='" + selectedPK + "'");

            JOptionPane.showMessageDialog(null, "\nEliminazione da TipologiaAuto avvenuta " +
                    "correttamente!");

            tableViewTipo.getItems().remove(selectedTipologia);
        }

        tableViewTipo.getSelectionModel().clearSelection();
    }

    private void deleteRicTipo() throws Exception {
        RicambioTipologia selectedRicambioTipologia = tableViewRicTipo.getSelectionModel().getSelectedItem();

        if (selectedRicambioTipologia == null) {
            throw new EccezionePersonalizzata("\nSelezionare un oggetto da eliminare!");
        }

        String selectedRic = selectedRicambioTipologia.getCodiceRicambio();
        String selectedTipo = selectedRicambioTipologia.getNomeTipologia();
        boolean confirmed = showConfirmationDialog("Eliminare l'oggetto selezionato?");

        if (confirmed) {
            db.update("delete from venditaricambi.ricambiotipologia where codiceRicambio='" + selectedRic +
                    "' and nomeTipologia='" + selectedTipo + "'");

            JOptionPane.showMessageDialog(null, "\nEliminazione da RicambioTipologia " +
                    "avvenuta correttamente!");

            tableViewRicTipo.getItems().remove(selectedRicambioTipologia);
        }

        tableViewRicTipo.getSelectionModel().clearSelection();
    }

    /**
     * Metodi privati che permettono la gestione apposita dell'associazione tra cella della tabella e valore
     * di quella variabile istanza privata.
     */

    private void cellCat() {
        codiceCategoria.setCellValueFactory(new PropertyValueFactory<>("codiceCategoria"));
        nomeCategoria.setCellValueFactory(new PropertyValueFactory<>("nomeCategoria"));
        descrizioneCategoria.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
    }

    private void cellForn() {
        codiceFornitore.setCellValueFactory(new PropertyValueFactory<>("codiceFornitore"));
        nomeFornitore.setCellValueFactory(new PropertyValueFactory<>("nomeFornitore"));
        partitaIva.setCellValueFactory(new PropertyValueFactory<>("partitaIVA"));
        indirizzo.setCellValueFactory(new PropertyValueFactory<>("indirizzo"));
        cap.setCellValueFactory(new PropertyValueFactory<>("CAP"));
        localita.setCellValueFactory(new PropertyValueFactory<>("localita"));
        nazione.setCellValueFactory(new PropertyValueFactory<>("nazione"));
    }

    private void cellRic() {
        codiceRicambio.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        nomeRicambio.setCellValueFactory(new PropertyValueFactory<>("nome"));
        descrizioneRicambio.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
        quantita.setCellValueFactory(new PropertyValueFactory<>("quantita"));
        costo.setCellValueFactory(new PropertyValueFactory<>("costo"));
        sconto.setCellValueFactory(new PropertyValueFactory<>("sconto"));
    }

    private void cellRicCat() {
        codiceRicambioCatFK.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        codiceCategoriaFK.setCellValueFactory(new PropertyValueFactory<>("codiceCategoria"));
    }

    private void cellRicForn() {
        codiceRicambioFornFK.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        codiceFornitoreFK.setCellValueFactory(new PropertyValueFactory<>("codiceFornitore"));
    }

    private void cellTipo() {
        nomeTipo.setCellValueFactory(new PropertyValueFactory<>("nomeTipologia"));
        descTipo.setCellValueFactory(new PropertyValueFactory<>("descTipologia"));
    }

    private void cellRicTipo() {
        codiceRicambioTipo.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        nomeTipoRic.setCellValueFactory(new PropertyValueFactory<>("nomeTipologia"));
    }
}
