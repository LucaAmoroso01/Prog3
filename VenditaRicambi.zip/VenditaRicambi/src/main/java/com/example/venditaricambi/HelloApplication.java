package com.example.venditaricambi;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Classe atta a caricare la pagina home della mia JavaFX application.
 * @author Luca Amoroso
 */
public class HelloApplication extends Application {
    /**
     * Metodo obbligatorio quando si estende la classe Application, che permette l'inizializzazione dell'interfaccia
     * utente da un file "home.fxml".
     * @param stage rappresenta la finestra principale dell'applicazione
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @Override
    public void start(Stage stage) throws IOException {
        /**
         * Istanzio un oggetto di tipo Parent, che funge da nodo radice per l'interfaccia utente JavaFX, e gli assegno
         * l'interfaccia utente relativa al file "home.fxml".
         */
        Parent root = FXMLLoader.load(getClass().getResource("home.fxml"));
        /**
         * Imposto il titolo della finestra principale mediante metodo apposito.
         */
        stage.setTitle("Vendita ricambi");
        /**
         * Impedisco il ridimensionamento della finestra principale, in modo che l'utente non possa modificare
         * le dimensioni della finestra.
         */
        stage.setResizable(false);
        /**
         * Creo una scena e la imposto come scena principale della finestra, a partire dal nodo radice precedentemente
         * inizializzato, che rappresenta il layout dell'interfaccia utente caricato da "home.fxml".
         */
        stage.setScene(new Scene(root));
        /**
         * Visualizzo la finestra principale tramite metodo apposito.
         */
        stage.show();
    }

    /**
     * Metodo che lancia l'applicazione JavaFX, invocando il metodo start e gestendo l'ambiente dell'applicazione.
     */
    public static void main(String[] args) {
        launch();
    }
}