package com.example.venditaricambi;

import application.EccezionePersonalizzata;
import application.Email;
import application.VenditaDettaglio;
import application.VenditaTestata;
import factoryMethod.pattern.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import singleton.pattern.Database;

import java.io.IOException;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Optional;

/**
 * Classe che permetta le gestione del pagamento da parte dei clienti.
 * @author Luca Amoroso
 */
public class PaymentController {

    @FXML
    private TextField carta;

    @FXML
    private TextField cvv;

    @FXML
    private TextField codFiscale;

    @FXML
    private RadioButton radioBancomat;

    @FXML
    private TextField cognome;

    @FXML
    private RadioButton radioCarta;

    @FXML
    private Button pay;

    @FXML
    private Button back;

    @FXML
    private TextField nome;

    @FXML
    private TextField cifra;

    @FXML
    private TextField bancomat;

    @FXML
    private TextField dataScadenza;

    @FXML
    private RadioButton radioContanti;

    @FXML
    private SplitPane pane;

    @FXML
    private Button dash;

    @FXML
    private Text text;

    @FXML
    private Text pag;

    private Factory factory;

    private MetodoPagamento met;

    private Database db;

    /**
     * Metodo invocato al termine della fase di inizializzazione della scena da parte del FXMLLoader.
     */
    @FXML
    void initialize() throws SQLException {
        /**
         * Clausola try-catch per provare ad effettuare la connessione al database.
         */
        try {
            db = new Database();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        /**
         * Eseguo una query per ricavare il prezzo totale del carrello e lo formatto in modo da visualizzare la ","
         * invece del "." e il simbolo dell'euro.
         */
        ResultSet rs = db.query("select ROUND(SUM(rc.quantitaRic*(r.costo-((r.costo*r.sconto)/100))),2)" +
                " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on" +
                " r.codiceRicambio = rc.codiceRicambio) join carrello c on rc.idCarrello = c.idCarrello" +
                " where c.emailCliente='" + Email.getIstanza().getEmail() + "'");
        rs.next();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
        String formattedTotal = decimalFormat.format(rs.getDouble(1));
        pag.setText("Totale carrello: " + formattedTotal + "€");

        /**
         * Creo un oggetto ToggleGroup e vi aggiungio i tre radioButton relativi ai metodi di pagamento, in modo che non
         * ci possano essere due radioButton selezionati.
         */
        ToggleGroup toggleGroup = new ToggleGroup();
        radioContanti.setToggleGroup(toggleGroup);
        radioCarta.setToggleGroup(toggleGroup);
        radioBancomat.setToggleGroup(toggleGroup);

        /**
         * Setto vari effetti relativi a diversi oggetti, per quanto riguarda gli eventi OnMouseEntered e OnMouseExited.
         */
        DropShadow shadow = new DropShadow();

        back.setOnMouseEntered(e -> {
            back.setEffect(shadow);
            back.setStyle("-fx-background-color: #8f6500;");
            back.setCursor(Cursor.HAND);
        });

        back.setOnMouseExited(e -> {
            back.setEffect(null);
            back.setStyle("-fx-background-color: #f4ad00;");
            back.setCursor(Cursor.DEFAULT);
        });

        pay.setOnMouseEntered(e -> {
            pay.setEffect(shadow);
            pay.setStyle("-fx-background-color: #3b4366;");
            pay.setCursor(Cursor.HAND);
        });

        pay.setOnMouseExited(e -> {
            pay.setEffect(null);
            pay.setStyle("-fx-background-color: #0b1541;");
            pay.setCursor(Cursor.DEFAULT);
        });

        dash.setOnMouseEntered(e -> {
            dash.setEffect(shadow);
            dash.setStyle("-fx-background-color: #a9a9a7;");
            dash.setCursor(Cursor.HAND);
        });

        dash.setOnMouseExited(e -> {
            dash.setEffect(null);
            dash.setStyle("-fx-background-color: white;");
            dash.setCursor(Cursor.DEFAULT);
        });
    }

    /**
     * Metodo che permette la gestione della visibilità e della pulizia di diversi oggetti della scena, in base al
     * radioButton selezionato.
     */
    @FXML
    void handleRadio(ActionEvent event) {
        if (radioContanti.isSelected()) {
            nome.clear();
            cognome.clear();
            codFiscale.clear();
            cifra.clear();
            carta.clear();
            dataScadenza.clear();
            cvv.clear();
            bancomat.clear();
            nome.setVisible(true);
            cognome.setVisible(true);
            codFiscale.setVisible(true);
            cifra.setVisible(true);
            carta.setVisible(false);
            dataScadenza.setVisible(false);
            cvv.setVisible(false);
            bancomat.setVisible(false);
        }

        if (radioCarta.isSelected()) {
            nome.clear();
            cognome.clear();
            codFiscale.clear();
            cifra.clear();
            carta.clear();
            dataScadenza.clear();
            cvv.clear();
            bancomat.clear();
            nome.setVisible(true);
            cognome.setVisible(true);
            codFiscale.setVisible(true);
            cifra.setVisible(false);
            carta.setVisible(true);
            dataScadenza.setVisible(true);
            cvv.setVisible(true);
            bancomat.setVisible(false);
        }

        if (radioBancomat.isSelected()) {
            nome.clear();
            cognome.clear();
            codFiscale.clear();
            cifra.clear();
            carta.clear();
            dataScadenza.clear();
            cvv.clear();
            bancomat.clear();
            nome.setVisible(true);
            cognome.setVisible(true);
            codFiscale.setVisible(true);
            cifra.setVisible(false);
            carta.setVisible(false);
            dataScadenza.setVisible(true);
            cvv.setVisible(true);
            bancomat.setVisible(true);
        }
    }

    /**
     * Metodo che permette di gestire il pagamento tramite il metodo selezionato dal cliente con i radioButton.
     */
    @FXML
    void handlePay(ActionEvent event) throws Exception {
        /**
         * Controllo se sia stato selezionato uno dei radioButton.
         */
        if (!radioContanti.isSelected() && !radioCarta.isSelected() && !radioBancomat.isSelected())
            throw new EccezionePersonalizzata("\nSelezionare un metodo di pagamento!");

        /**
         * In base al radioButton selezionato effettuo operazioni leggermente diverse, ma in generale la logica è simile.
         */
        if (radioContanti.isSelected()) {
            /**
             * Controllo se vengano compilati tutti i campi di testo, altrimenti viene lanciata un'eccezione.
             */
            if (nome.getText().isEmpty() || cognome.getText().isEmpty() || codFiscale.getText().isEmpty() || cifra.getText().isEmpty()) {
                nome.clear();
                cognome.clear();
                codFiscale.clear();
                cifra.clear();

                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, compilare tutti i campi!");
            }

            /**
             * Controllo, tramite regex apposita, se la stringa inserita nel campo di testo relativo al codice fiscale
             * corrisponda alla stringa specificata nella regex.
             */
            if (!codFiscale.getText().matches("^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$")) {
                codFiscale.clear();
                throw new EccezionePersonalizzata("\nErrore durante l'inserimento del codice fiscale, la stringa inserita" +
                        " non rispetta lo standard dei codici fiscali!");
            }

            /**
             * Creo il metodo di pagamento sfruttando il pattern FactoryMethod, controllando anche, tramite clausola
             * try-catch, che nel campo di testo relativo alla cifra sia stato effettivamente inserito un numero.
             */
            try {
                 factory = new ContantiFactory(nome.getText().toUpperCase(),cognome.getText().toUpperCase(),
                         codFiscale.getText(), Double.parseDouble(cifra.getText()));

            }
            catch (NumberFormatException e) {
                cifra.clear();
                throw new EccezionePersonalizzata("\nNon è stato inserito un valore valido nel campo 'Inserisci cifra'!");
            }

            /**
             * Recupero il metodo di pagamento tramite il metodo "FactoryMethod" del pattern omonimo.
             */
            met = factory.getMetodo();

            boolean confirmed = showConfirmationDialog("Sei sicuro di voler procedere al pagamento?");

            /**
             * Richiedo al cliente se voglia effettivamente passare al pagamento e in caso affermativo procedo.
             */
            if (confirmed) {
                Contanti cont = (Contanti) met;
                /**
                 * Eseguo una query per ricavare il prezzo totale del carrello.
                 */
                ResultSet rs = db.query("select ROUND(SUM(rc.quantitaRic*(r.costo-((r.costo*r.sconto)/100))),2)" +
                        " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on" +
                        " r.codiceRicambio = rc.codiceRicambio) join carrello c on rc.idCarrello = c.idCarrello" +
                        " where c.emailCliente='" + Email.getIstanza().getEmail() + "'");
                rs.next();

                /**
                 * Controllo che la cifra inserita, nel campo apposito, sia maggiore della cifra da pagare, in quanto
                 * altrimenti, ovviamente, il pagamento non può andare a buon fine. In caso negativo lancio un'eccezione.
                 */
                if (Double.parseDouble(cifra.getText()) < rs.getDouble(1)) {
                    cifra.clear();
                    throw new EccezionePersonalizzata("\nErrore, hai inserito una cifra minore del totale!");
                }
                else {
                    /**
                     * Se invece la cifra inserita è maggiore o uguale a quella da pagare, invoco il metodo che gestisce
                     * l'inserimento di tuple sia in VenditaTestata che in VenditaDettaglio, oltre ad eliminare il carrello.
                     */
                    contPag(cont);

                    /**
                     * Modifico la visibilità di diversi oggetti della scena.
                     */
                    text.setVisible(true);
                    dash.setVisible(true);
                    back.setVisible(false);
                    pay.setVisible(false);
                    pane.setVisible(false);
                    nome.setVisible(false);
                    cognome.setVisible(false);
                    codFiscale.setVisible(false);
                    cifra.setVisible(false);

                    /**
                     * Visualizzo un messaggio, sulla scena, che sarà diverso in base al metodo di pagamento.
                     */
                    text.setText(met.paga() + " e ha ricevuto di resto " + (Double.parseDouble(cifra.getText()) - rs.getDouble(1)));
                }
            }
        }

        if (radioCarta.isSelected()) {
            if (nome.getText().isEmpty() || cognome.getText().isEmpty() || codFiscale.getText().isEmpty() ||
                    carta.getText().isEmpty() || dataScadenza.getText().isEmpty() || cvv.getText().isEmpty()) {
                nome.clear();
                cognome.clear();
                codFiscale.clear();
                carta.clear();
                dataScadenza.clear();
                cvv.clear();

                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, compilare tutti i campi!");
            }

            if (!codFiscale.getText().matches("^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$")) {
                codFiscale.clear();
                throw new EccezionePersonalizzata("\nErrore durante l'inserimento del codice fiscale, la stringa inserita" +
                        " non rispetta lo standard dei codici fiscali!");
            }

            /**
             * Controllo, tramite regex, che sia stata inserita una data, nel campo apposito, del tipo MM/YY.
             */
            if (!dataScadenza.getText().matches("(0[1-9]|1[0-2])/(\\d{2})$")) {
                dataScadenza.clear();
                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, formato data di scadenza non valido," +
                        " immettere una data del tipo 'MM/YY'!");
            }

            /**
             * Controllo che la data di scadenza sia successiva alla attuale data, in quanto altrimenti sarà scaduta.
             */
            if (!isValidFutureDate(dataScadenza.getText())) {
                dataScadenza.clear();
                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, controllare che la data di scadenza" +
                        " sia giusta, in quanto la data immessa è già passata!");
            }

            /**
             * Controllo, tramite regex, che sia stato inserita un numero di carta formato da 16 cifre.
             */
            if (!carta.getText().matches("\\d{16}")) {
                carta.clear();
                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, inserire correttamente le 16" +
                        " cifre del numero della carta!");
            }

            /**
             * Controllo, tramite regex, che sia stato inserita un cvv formato da 3 cifre.
             */
            if (!cvv.getText().matches("\\d{3}")) {
                cvv.clear();
                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, inserire correttamente le 3" +
                        " cifre del cvv, ossia le 3 cifre che si trovano sul retro della carta!");
            }

            factory = new CartaCreditoFactory(nome.getText().toUpperCase(), cognome.getText().toUpperCase(),
                    codFiscale.getText(), carta.getText(), dataScadenza.getText(), cvv.getText());
            met = factory.getMetodo();

            boolean confirmed = showConfirmationDialog("Sei sicuro di voler procedere al pagamento?");

            if (confirmed) {
                text.setVisible(true);
                dash.setVisible(true);
                back.setVisible(false);
                pay.setVisible(false);
                pane.setVisible(false);
                nome.setVisible(false);
                cognome.setVisible(false);
                codFiscale.setVisible(false);
                carta.setVisible(false);
                dataScadenza.setVisible(false);
                cvv.setVisible(false);

                CartaCredito card = (CartaCredito) met;
                cartaPag(card);
                text.setText(met.paga());
            }
        }

        if (radioBancomat.isSelected()) {
            if (nome.getText().isEmpty() || cognome.getText().isEmpty() || codFiscale.getText().isEmpty() ||
                    bancomat.getText().isEmpty() || dataScadenza.getText().isEmpty() || cvv.getText().isEmpty()) {
                nome.clear();
                cognome.clear();
                codFiscale.clear();
                bancomat.clear();
                dataScadenza.clear();
                cvv.clear();

                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, compilare tutti i campi!");
            }

            if (!codFiscale.getText().matches("^[A-Z]{6}[0-9]{2}[A-Z][0-9]{2}[A-Z][0-9]{3}[A-Z]$")) {
                codFiscale.clear();
                throw new EccezionePersonalizzata("\nErrore durante l'inserimento del codice fiscale, la stringa inserita" +
                        " non rispetta lo standard dei codici fiscali!");
            }

            if (!dataScadenza.getText().matches("(0[1-9]|1[0-2])/(\\d{2})$")) {
                dataScadenza.clear();
                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, formato data di scadenza non valido," +
                        " immettere una data del tipo 'MM/YY'!");
            }

            if (!isValidFutureDate(dataScadenza.getText())) {
                dataScadenza.clear();
                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, controllare che la data di scadenza" +
                        " sia giusta, in quanto la data immessa è già passata!");
            }

            if (!bancomat.getText().matches("\\d{16}")) {
                bancomat.clear();
                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, inserire correttamente le 16" +
                        " cifre del numero del bancomat!");
            }

            if (!cvv.getText().matches("\\d{3}")) {
                cvv.clear();
                throw new EccezionePersonalizzata("\nErrore nell'inserimento dei dati, inserire correttamente le 3" +
                        " cifre del cvv, ossia le 3 cifre che si trovano sul retro del bancomat!");
            }

            factory = new BancomatFactory(nome.getText().toUpperCase(), cognome.getText().toUpperCase(),
                    codFiscale.getText(), bancomat.getText(), dataScadenza.getText(), cvv.getText());
            met = factory.getMetodo();

            boolean confirmed = showConfirmationDialog("Sei sicuro di voler procedere al pagamento?");

            if (confirmed) {
                text.setVisible(true);
                dash.setVisible(true);
                back.setVisible(false);
                pay.setVisible(false);
                pane.setVisible(false);
                nome.setVisible(false);
                cognome.setVisible(false);
                codFiscale.setVisible(false);
                bancomat.setVisible(false);
                dataScadenza.setVisible(false);
                cvv.setVisible(false);

                Bancomat banc = (Bancomat) met;
                bancPag(banc);
                text.setText(met.paga());
            }
        }

    }

    /**
     * Metodo che permette di controllare se una data è successiva a quella odierna.
     * @param input stringa che equivale ad una data
     * @return valore booleano che, se true, indica che la data passata in input come stringa è successiva alla data
     * odierna
     */
    private boolean isValidFutureDate(String input) {
        /**
         * Creo il pattern con cui si presenta la data nella stringa passata in input.
         */
        SimpleDateFormat sdf = new SimpleDateFormat("MM/yy");
        try {
            /**
             * Creo un oggetto di tipo Date a partire dal formato della data appena creato, castando la stringa passata
             * in input e utilizzando il metodo getTime() che restituisce il numero di millisecondi a partire dal
             * 1/1/1970 alle 00:00:00.
             */
            Date parsedDate = new Date(sdf.parse(input).getTime());

            /** Ottengo l'anno ed il mese corrente, prendendo solo gli ultimi 2 numeri del primo e aggiungendo 1
             * al secondo in quanto partono da 0.
             */
            Calendar now = Calendar.getInstance();
            int currentYear = now.get(Calendar.YEAR) % 100; // Ottieni solo gli ultimi due numeri dell'anno
            int currentMonth = now.get(Calendar.MONTH) + 1; // Mese è 0-indexed, aggiungi 1

            /** Ottengo l'anno ed il mese della data inserita, prendendo solo gli ultimi 2 numeri del primo e aggiungendo 1
             * al secondo in quanto partono da 0.
             */
            Calendar inputCalendar = Calendar.getInstance();
            inputCalendar.setTime(parsedDate);
            int inputYear = inputCalendar.get(Calendar.YEAR) % 100;
            int inputMonth = inputCalendar.get(Calendar.MONTH) + 1;

            /**
             * Verifico se la data inserita è oltre l'attuale data, ed in caso affermativo restituisco true, altrimenti
             * false.
             */
            return (inputYear > currentYear) || (inputYear == currentYear && inputMonth >= currentMonth);
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * Metodo privato che restituisce un valore booleano true se è stato premuto "ok" o un valore booleano false se
     * è stato premuto "annulla". Viene creato un oggetto di classe Alert, di tipo CONFIRMATION, il cui messaggio è
     * quello passato in input. Se viene premuto "ok" allora il metodo restituisce true, altrimenti restituisce false.
     * @param message stringa passata in input che viene visualizzata come messaggio dell'alert
     * @return valore booleano in base alla scelta effettuata
     */
    private boolean showConfirmationDialog(String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Conferma eliminazione");
        alert.setHeaderText(null);
        alert.setContentText(message);

        Optional<ButtonType> result = alert.showAndWait();
        return result.isPresent() && result.get() == ButtonType.OK;
    }

    /**
     * Metodo che permette di tornare alla scena precedente, ossia quella relativa al carrello del cliente.
     */
    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("cart.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette, una volta effettuato un pagamento, di tornare alla propria dashboard.
     */
    @FXML
    void handleDash(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("customerHome.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di gestire le varie operazioni relative al database quando si effettua un pagamento in contanti.
     * @param cont oggetto relativo al metodo di pagamento
     * @throws SQLException eccezioni relative alle operazioni con il database
     */
    private void contPag(Contanti cont) throws SQLException {
        /**
         * Eseguo una query per ricavare il prezzo totale del carrello, che inserirò nel campo prezzoTotale dell'oggetto
         * VenditaTestata che creerò.
         */
        ResultSet rs = db.query("select ROUND(SUM(rc.quantitaRic*(r.costo-((r.costo*r.sconto)/100))),2)" +
                " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on" +
                " r.codiceRicambio = rc.codiceRicambio) join carrello c on rc.idCarrello = c.idCarrello" +
                " where c.emailCliente='" + Email.getIstanza().getEmail() + "'");
        rs.next();

        /**
         * Carico un oggetto di tipo VenditaTestata, che poi inserirò all'interno del database.
         */
        VenditaTestata vendTest = new VenditaTestata();
        vendTest.setCodiceVendita();
        vendTest.setNomeAcquirente(cont.getNome());
        vendTest.setCognomeAcquirente(cont.getCognome());
        vendTest.setCodiceFiscale(cont.getCodFiscale());
        vendTest.setDataVendita(Date.valueOf(LocalDate.now()));
        vendTest.setPrezzoTotale(rs.getDouble(1));
        vendTest.setEmailCliente(Email.getIstanza().getEmail());

        PreparedStatement preparedStmt = db.insert("insert into venditaricambi.venditatestata" +
                " (codiceVendita,nomeAcquirente,cognomeAcquirente,codiceFiscale,dataVendita,prezzoTotale,emailCliente)" +
                " values (?,?,?,?,?,?,?)");
        preparedStmt.setInt(1, vendTest.getCodiceVendita());
        preparedStmt.setString(2, vendTest.getNomeAcquirente());
        preparedStmt.setString(3, vendTest.getCognomeAcquirente());
        preparedStmt.setString(4, vendTest.getCodiceFiscale());
        preparedStmt.setDate(5, vendTest.getDataVendita());
        preparedStmt.setDouble(6, vendTest.getPrezzoTotale());
        preparedStmt.setString(7, vendTest.getEmailCliente());
        preparedStmt.execute();

        /**
         * Recupero tutti i ricambi relativi al carrello del cliente.
         */
        ResultSet rsRic = db.query("select rc.codiceRicambio, r.costo-((r.costo*r.sconto)/100) as prezzoUnitario, rc.quantitaRic," +
                " (r.costo-((r.costo*r.sconto)/100)) * rc.quantitaRic as prezzoRiga" +
                " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on r.codiceRicambio = rc.codiceRicambio)" +
                " join venditaricambi.carrello c on c.idCarrello = rc.idCarrello" +
                " where c.emailCliente = '" + Email.getIstanza().getEmail() + "' and c.idCarrello in (select idCarrello from" +
                " venditaricambi.carrello where emailCliente='" + Email.getIstanza().getEmail() + "')");

        /**
         * Effettuo un inserimento in VenditaDettaglio per ogni ricambio venduto all'interno della vendita appena
         * avvenuta.
         */
        while (rsRic.next()) {
            VenditaDettaglio vendDett = new VenditaDettaglio();
            vendDett.setCodiceVendita(vendTest.getCodiceVendita());
            vendDett.setCodiceRicambio(rsRic.getString(1));
            vendDett.setPrezzoUnitario(rsRic.getDouble(2));
            vendDett.setQuantitaVendita(rsRic.getInt(3));
            vendDett.setPrezzoRiga(rsRic.getDouble(4));

            PreparedStatement prepVendDett = db.insert("insert into venditaricambi.venditadettaglio" +
                    " (codiceVendita,codiceRicambio,prezzoUnitario,quantitaVendita,prezzoRiga)" +
                    " values (?,?,?,?,?)");
            prepVendDett.setInt(1, vendDett.getCodiceVendita());
            prepVendDett.setString(2, vendDett.getCodiceRicambio());
            prepVendDett.setDouble(3, vendDett.getPrezzoUnitario());
            prepVendDett.setInt(4, vendDett.getQuantitaVendita());
            prepVendDett.setDouble(5, vendDett.getPrezzoRiga());
            prepVendDett.execute();

            /**
             * Aggiorno la quantità, decrementandola del numero di unità vendute, del ricambio appena aggiunto
             * in VenditaDettaglio.
             */
            ResultSet rsQuant = db.query("select quantita from venditaricambi.ricambio where codiceRicambio='" +
                    vendDett.getCodiceRicambio() +"'");
            rsQuant.next();

            db.update("update venditaricambi.ricambio set quantita = " + (rsQuant.getInt(1) - vendDett.getQuantitaVendita())
                    + " where codiceRicambio ='" + vendDett.getCodiceRicambio() + "'");
        }

        /**
         * Elimino il carrello associato al cliente dopo il pagamento.
         */
        db.update("delete from venditaricambi.carrello where emailCliente='" +
                Email.getIstanza().getEmail() + "'");
    }

    /**
     * Metodo che permette di gestire le varie operazioni relative al database quando si effettua un pagamento con carta.
     * @param card oggetto relativo al metodo di pagamento
     * @throws SQLException eccezioni relative alle operazioni con il database
     */
    private void cartaPag(CartaCredito card) throws SQLException {
        /**
         * Eseguo una query per ricavare il prezzo totale del carrello.
         */
        ResultSet rs = db.query("select ROUND(SUM(rc.quantitaRic*(r.costo-((r.costo*r.sconto)/100))),2)" +
                " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on" +
                " r.codiceRicambio = rc.codiceRicambio) join carrello c on rc.idCarrello = c.idCarrello" +
                " where c.emailCliente='" + Email.getIstanza().getEmail() + "'");
        rs.next();

        VenditaTestata vendTest = new VenditaTestata();
        vendTest.setCodiceVendita();
        vendTest.setNomeAcquirente(card.getNome());
        vendTest.setCognomeAcquirente(card.getCognome());
        vendTest.setCodiceFiscale(card.getCodFiscale());
        vendTest.setDataVendita(Date.valueOf(LocalDate.now()));
        vendTest.setPrezzoTotale(rs.getDouble(1));
        vendTest.setEmailCliente(Email.getIstanza().getEmail());

        PreparedStatement preparedStmt = db.insert("insert into venditaricambi.venditatestata" +
                " (codiceVendita,nomeAcquirente,cognomeAcquirente,codiceFiscale,dataVendita,prezzoTotale,emailCliente)" +
                " values (?,?,?,?,?,?,?)");
        preparedStmt.setInt(1, vendTest.getCodiceVendita());
        preparedStmt.setString(2, vendTest.getNomeAcquirente());
        preparedStmt.setString(3, vendTest.getCognomeAcquirente());
        preparedStmt.setString(4, vendTest.getCodiceFiscale());
        preparedStmt.setDate(5, vendTest.getDataVendita());
        preparedStmt.setDouble(6, vendTest.getPrezzoTotale());
        preparedStmt.setString(7, vendTest.getEmailCliente());
        preparedStmt.execute();

        /**
         * Recupero tutti i ricambi relativi al carrello del cliente.
         */
        ResultSet rsRic = db.query("select rc.codiceRicambio, r.costo-((r.costo*r.sconto)/100) as prezzoUnitario, rc.quantitaRic," +
                " (r.costo-((r.costo*r.sconto)/100)) * rc.quantitaRic as prezzoRiga" +
                " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on r.codiceRicambio = rc.codiceRicambio)" +
                " join venditaricambi.carrello c on c.idCarrello = rc.idCarrello" +
                " where c.emailCliente = '" + Email.getIstanza().getEmail() + "' and c.idCarrello in (select idCarrello from" +
                " venditaricambi.carrello where emailCliente='" + Email.getIstanza().getEmail() + "')");


        while (rsRic.next()) {
            VenditaDettaglio vendDett = new VenditaDettaglio();
            vendDett.setCodiceVendita(vendTest.getCodiceVendita());
            vendDett.setCodiceRicambio(rsRic.getString(1));
            vendDett.setPrezzoUnitario(rsRic.getDouble(2));
            vendDett.setQuantitaVendita(rsRic.getInt(3));
            vendDett.setPrezzoRiga(rsRic.getDouble(4));

            PreparedStatement prepVendDett = db.insert("insert into venditaricambi.venditadettaglio" +
                    " (codiceVendita,codiceRicambio,prezzoUnitario,quantitaVendita,prezzoRiga)" +
                    " values (?,?,?,?,?)");
            prepVendDett.setInt(1, vendDett.getCodiceVendita());
            prepVendDett.setString(2, vendDett.getCodiceRicambio());
            prepVendDett.setDouble(3, vendDett.getPrezzoUnitario());
            prepVendDett.setInt(4, vendDett.getQuantitaVendita());
            prepVendDett.setDouble(5, vendDett.getPrezzoRiga());
            prepVendDett.execute();

            ResultSet rsQuant = db.query("select quantita from venditaricambi.ricambio where codiceRicambio='" +
                    vendDett.getCodiceRicambio() +"'");
            rsQuant.next();

            db.update("update venditaricambi.ricambio set quantita = " + (rsQuant.getInt(1) - vendDett.getQuantitaVendita())
                    + " where codiceRicambio ='" + vendDett.getCodiceRicambio() + "'");
        }

        /**
         * Elimino il carrello associato al cliente dopo il pagamento.
         */
        db.update("delete from venditaricambi.carrello where emailCliente='" +
                Email.getIstanza().getEmail() + "'");
    }

    /**
     * Metodo che permette di gestire le varie operazioni relative al database quando si effettua un pagamento con bancomat.
     * @param banc oggetto relativo al metodo di pagamento
     * @throws SQLException eccezioni relative alle operazioni con il database
     */
    private void bancPag(Bancomat banc) throws SQLException {
        /**
         * Eseguo una query per ricavare il prezzo totale del carrello.
         */
        ResultSet rs = db.query("select ROUND(SUM(rc.quantitaRic*(r.costo-((r.costo*r.sconto)/100))),2)" +
                " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on" +
                " r.codiceRicambio = rc.codiceRicambio) join carrello c on rc.idCarrello = c.idCarrello" +
                " where c.emailCliente='" + Email.getIstanza().getEmail() + "'");
        rs.next();

        VenditaTestata vendTest = new VenditaTestata();
        vendTest.setCodiceVendita();
        vendTest.setNomeAcquirente(banc.getNome());
        vendTest.setCognomeAcquirente(banc.getCognome());
        vendTest.setCodiceFiscale(banc.getCodFiscale());
        vendTest.setDataVendita(Date.valueOf(LocalDate.now()));
        vendTest.setPrezzoTotale(rs.getDouble(1));
        vendTest.setEmailCliente(Email.getIstanza().getEmail());

        PreparedStatement preparedStmt = db.insert("insert into venditaricambi.venditatestata" +
                " (codiceVendita,nomeAcquirente,cognomeAcquirente,codiceFiscale,dataVendita,prezzoTotale,emailCliente)" +
                " values (?,?,?,?,?,?,?)");
        preparedStmt.setInt(1, vendTest.getCodiceVendita());
        preparedStmt.setString(2, vendTest.getNomeAcquirente());
        preparedStmt.setString(3, vendTest.getCognomeAcquirente());
        preparedStmt.setString(4, vendTest.getCodiceFiscale());
        preparedStmt.setDate(5, vendTest.getDataVendita());
        preparedStmt.setDouble(6, vendTest.getPrezzoTotale());
        preparedStmt.setString(7, vendTest.getEmailCliente());
        preparedStmt.execute();

        /**
         * Recupero tutti i ricambi relativi al carrello del cliente.
         */
        ResultSet rsRic = db.query("select rc.codiceRicambio, r.costo-((r.costo*r.sconto)/100) as prezzoUnitario, rc.quantitaRic," +
                " (r.costo-((r.costo*r.sconto)/100)) * rc.quantitaRic as prezzoRiga" +
                " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on r.codiceRicambio = rc.codiceRicambio)" +
                " join venditaricambi.carrello c on c.idCarrello = rc.idCarrello" +
                " where c.emailCliente = '" + Email.getIstanza().getEmail() + "' and c.idCarrello in (select idCarrello from" +
                " venditaricambi.carrello where emailCliente='" + Email.getIstanza().getEmail() + "')");


        while (rsRic.next()) {
            VenditaDettaglio vendDett = new VenditaDettaglio();
            vendDett.setCodiceVendita(vendTest.getCodiceVendita());
            vendDett.setCodiceRicambio(rsRic.getString(1));
            vendDett.setPrezzoUnitario(rsRic.getDouble(2));
            vendDett.setQuantitaVendita(rsRic.getInt(3));
            vendDett.setPrezzoRiga(rsRic.getDouble(4));

            PreparedStatement prepVendDett = db.insert("insert into venditaricambi.venditadettaglio" +
                    " (codiceVendita,codiceRicambio,prezzoUnitario,quantitaVendita,prezzoRiga)" +
                    " values (?,?,?,?,?)");
            prepVendDett.setInt(1, vendDett.getCodiceVendita());
            prepVendDett.setString(2, vendDett.getCodiceRicambio());
            prepVendDett.setDouble(3, vendDett.getPrezzoUnitario());
            prepVendDett.setInt(4, vendDett.getQuantitaVendita());
            prepVendDett.setDouble(5, vendDett.getPrezzoRiga());
            prepVendDett.execute();

            ResultSet rsQuant = db.query("select quantita from venditaricambi.ricambio where codiceRicambio='" +
                    vendDett.getCodiceRicambio() +"'");
            rsQuant.next();

            db.update("update venditaricambi.ricambio set quantita = " + (rsQuant.getInt(1) - vendDett.getQuantitaVendita())
                    + " where codiceRicambio ='" + vendDett.getCodiceRicambio() + "'");
        }

        /**
         * Elimino il carrello associato al cliente dopo il pagamento.
         */
        db.update("delete from venditaricambi.carrello where emailCliente='" +
                Email.getIstanza().getEmail() + "'");
    }
}
