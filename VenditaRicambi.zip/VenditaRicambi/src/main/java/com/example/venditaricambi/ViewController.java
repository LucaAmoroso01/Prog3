package com.example.venditaricambi;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import application.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.stage.Stage;
import singleton.pattern.Database;
import strategy.pattern.*;
import visibilityDelView.*;

/**
 * Classe che permette la gestione della visualizzazione di tutti gli oggetti contenuti nel database,
 * in base alla tabella scelta.
 * @author Luca Amoroso
 */
public class ViewController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<Categoria, String> codiceCategoria;

    @FXML
    private TableColumn<Categoria, String> nomeCategoria;

    @FXML
    private TableColumn<Categoria, String> descrizioneCategoria;

    @FXML
    private TableColumn<RicambioCategoria, String> codiceRicambioCatFK;

    @FXML
    private TableColumn<RicambioCategoria, String> codiceCategoriaFK;

    @FXML
    private TableColumn<RicambioFornitore, String> codiceRicambioFornFK;

    @FXML
    private TableColumn<RicambioFornitore, String> codiceFornitoreFK;

    @FXML
    private TableColumn<Fornitore, String> codiceFornitore;

    @FXML
    private TableColumn<Fornitore, String> nomeFornitore;

    @FXML
    private TableColumn<Fornitore, String> partitaIva;

    @FXML
    private TableColumn<Fornitore, String> indirizzo;

    @FXML
    private TableColumn<Fornitore, String> cap;

    @FXML
    private TableColumn<Fornitore, String> localita;

    @FXML
    private TableColumn<Fornitore, String> nazione;

    @FXML
    private TableColumn<Ricambio, String> codiceRicambio;

    @FXML
    private TableColumn<Ricambio, String> nomeRicambio;

    @FXML
    private TableColumn<Ricambio, String> descrizioneRicambio;

    @FXML
    private TableColumn<Ricambio, Integer> quantita;

    @FXML
    private TableColumn<Ricambio, Double> costo;

    @FXML
    private TableColumn<Ricambio, Integer> sconto;

    @FXML
    private TableColumn<VenditaDettaglio, String> codiceVendDett;

    @FXML
    private TableColumn<VenditaDettaglio, String> codiceRicambioVendFK;

    @FXML
    private TableColumn<VenditaDettaglio, Double> prezzoUnitario;

    @FXML
    private TableColumn<VenditaDettaglio, Integer> quantitaVendita;

    @FXML
    private TableColumn<VenditaDettaglio, Double> prezzoRiga;

    @FXML
    private TableColumn<VenditaTestata, String> codiceVendTest;

    @FXML
    private TableColumn<VenditaTestata, String> nomeAcquirente;

    @FXML
    private TableColumn<VenditaTestata, String> cognomeAcquirente;

    @FXML
    private TableColumn<VenditaTestata, String> codiceFiscale;

    @FXML
    private TableColumn<VenditaTestata, String> dataVendita;

    @FXML
    private TableColumn<VenditaTestata, Double> prezzoTotale;

    @FXML
    private TableColumn<VenditaTestata, String> emailCliente;

    @FXML
    private TableColumn<VenditaTestata, Button> details;

    @FXML
    private Button back;

    @FXML
    private Button backVend;

    @FXML
    private ComboBox<String> myComboBox;

    @FXML
    private TableView<Categoria> tableViewCat;

    @FXML
    private TableView<Fornitore> tableViewForn;

    @FXML
    private TableView<Ricambio> tableViewRic;

    @FXML
    private TableView<RicambioCategoria> tableViewRicCat;

    @FXML
    private TableView<RicambioFornitore> tableViewRicForn;

    @FXML
    private TableView<VenditaTestata> tableViewVendTest;

    @FXML
    private TableView<VenditaDettaglio> tableViewVendDett;

    @FXML
    private TableView<TipologiaAuto> tableViewTipo;

    @FXML
    private TableColumn<TipologiaAuto, String> nomeTipo;

    @FXML
    private TableColumn<TipologiaAuto, String> descTipo;

    @FXML
    private TableView<RicambioTipologia> tableViewRicTipo;

    @FXML
    private TableColumn<RicambioTipologia, String> codiceRicambioTipo;

    @FXML
    private TableColumn<RicambioTipologia, String> nomeTipoRic;

    /**
     * Metodo che permette di tornare alla scena precedente rispetto a quella in cui ci troviamo,
     * ossia il layout dell'interfaccia utente relativo a "adminHome.fxml".
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleBack (ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("adminHome.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di tornare alla scena precedente rispetto a quella in cui ci viene visualizzata una determinata
     * vendita in dettaglio, ossia il layout dell'interfaccia utente relativo alla tabella VenditaTestata.
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleBackVend (ActionEvent event) throws IOException {
        VisibilityViewVendTest vis = new VisibilityViewVendTest();
        vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
                tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
                costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
                codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

        tableViewVendTest.setVisible(true);
        tableViewVendDett.setVisible(false);
        codiceVendDett.setVisible(false);
        codiceRicambioVendFK.setVisible(false);
        prezzoUnitario.setVisible(false);
        quantitaVendita.setVisible(false);
        prezzoRiga.setVisible(false);
        codiceVendTest.setVisible(true);
        nomeAcquirente.setVisible(true);
        cognomeAcquirente.setVisible(true);
        codiceFiscale.setVisible(true);
        dataVendita.setVisible(true);
        prezzoTotale.setVisible(true);
        emailCliente.setVisible(true);
        details.setVisible(true);
        back.setVisible(true);
        backVend.setVisible(false);
        myComboBox.setVisible(true);

        cellVendTest();

        TipoTabella<VenditaTestata> tab = new TipoTabella<>(new TabellaVenditaTestata());
        tableViewVendTest.setItems(tab.getElements());
    }

    /**
     * Metodo che permette la gestione delle operazioni che scaturiscono dalla scelta della tabella dalla quale
     * effettuare un'eliminazione all'interno del menù a tendina, ossia l'oggetto di tipo ComboBox.
     * Vengono resi visibili alcuni oggetti e altri no, in base alla scelta effettuata nel menù a tendina, e, sempre in
     * base alla scelta effettuata, vengono eseguite delle query che permettono di mostrare le tuple contenute nella
     * tabella selezionata.
     */
    @FXML
    void handleComboBox(ActionEvent event) {
        String selectedValue = myComboBox.getValue();

        if (selectedValue.equals("Categoria")) {
            /**
             * Creo un oggetto di tipo VisibilityDelViewCat per settare la visibilità degli oggetti relativi alla tabella
             * scelta tramite il menù a tendina, ossia la ComboBox. In base alla classe dell'oggetto che chiama il
             * metodo setVisibilityDelete, verrà invocato il metodo apposito per quell'oggetto.
             */
            VisibilityDelViewCat vis = new VisibilityDelViewCat();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            /**
             * Aggiungo gli altri oggetti, non comuni al setting degli oggetti dell'interfaccia utente relativa
             * all'eliminazione di tuple.
             */
            tableViewVendTest.setVisible(false);
            tableViewVendDett.setVisible(false);
            codiceVendDett.setVisible(false);
            codiceRicambioVendFK.setVisible(false);
            prezzoUnitario.setVisible(false);
            quantitaVendita.setVisible(false);
            prezzoRiga.setVisible(false);
            codiceVendTest.setVisible(false);
            nomeAcquirente.setVisible(false);
            cognomeAcquirente.setVisible(false);
            codiceFiscale.setVisible(false);
            dataVendita.setVisible(false);
            prezzoTotale.setVisible(false);
            emailCliente.setVisible(false);
            details.setVisible(false);

            /**
             * Setto i valori da visualizzare nelle varie celle, servendomi del metodo setCellValueFactory, ed in
             * particolare setto il valore della cella tramite il costruttore di PropertyValueFactory, che prende
             * la variabile istanza privata, relativa alla classe apposita.
             */
            cellCat();

            /**
             * Utilizzo l'equivalente dei ConcreteStrategy da me definiti nel package strategy.pattern per creare
             * le tabelle i cui dati sono risultanti da una query che prende tutte le tuple relative alla tabella
             * scelta. Infine setto gli elementi della tabella a partire dal metodo getElements della classe TipoTabella,
             * ossia l'equivalente del Context nel pattern Strategy.
             */
            TipoTabella<Categoria> tab = new TipoTabella<>(new TabellaCategoria());
            tableViewCat.setItems(tab.getElements());
        }

        if (selectedValue.equals("Fornitore")) {
            VisibilityDelViewForn vis = new VisibilityDelViewForn();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            tableViewVendTest.setVisible(false);
            tableViewVendDett.setVisible(false);
            codiceVendDett.setVisible(false);
            codiceRicambioVendFK.setVisible(false);
            prezzoUnitario.setVisible(false);
            quantitaVendita.setVisible(false);
            prezzoRiga.setVisible(false);
            codiceVendTest.setVisible(false);
            nomeAcquirente.setVisible(false);
            cognomeAcquirente.setVisible(false);
            codiceFiscale.setVisible(false);
            dataVendita.setVisible(false);
            prezzoTotale.setVisible(false);
            emailCliente.setVisible(false);
            details.setVisible(false);

            cellForn();

            TipoTabella<Fornitore> tab = new TipoTabella<>(new TabellaFornitore());
            tableViewForn.setItems(tab.getElements());
        }

        if (selectedValue.equals("Ricambio")) {
            VisibilityDelViewRic vis = new VisibilityDelViewRic();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            tableViewVendTest.setVisible(false);
            tableViewVendDett.setVisible(false);
            codiceVendDett.setVisible(false);
            codiceRicambioVendFK.setVisible(false);
            prezzoUnitario.setVisible(false);
            quantitaVendita.setVisible(false);
            prezzoRiga.setVisible(false);
            codiceVendTest.setVisible(false);
            nomeAcquirente.setVisible(false);
            cognomeAcquirente.setVisible(false);
            codiceFiscale.setVisible(false);
            dataVendita.setVisible(false);
            prezzoTotale.setVisible(false);
            emailCliente.setVisible(false);
            details.setVisible(false);

            cellRic();

            TipoTabella<Ricambio> tab = new TipoTabella<>(new TabellaRicambio());
            tableViewRic.setItems(tab.getElements());
        }

        if (selectedValue.equals("RicambioCategoria")) {
            VisibilityDelViewRicCat vis = new VisibilityDelViewRicCat();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            tableViewVendTest.setVisible(false);
            tableViewVendDett.setVisible(false);
            codiceVendDett.setVisible(false);
            codiceRicambioVendFK.setVisible(false);
            prezzoUnitario.setVisible(false);
            quantitaVendita.setVisible(false);
            prezzoRiga.setVisible(false);
            codiceVendTest.setVisible(false);
            nomeAcquirente.setVisible(false);
            cognomeAcquirente.setVisible(false);
            codiceFiscale.setVisible(false);
            dataVendita.setVisible(false);
            prezzoTotale.setVisible(false);
            emailCliente.setVisible(false);
            details.setVisible(false);

            cellRicCat();

            TipoTabella<RicambioCategoria> tab = new TipoTabella<>(new TabellaRicambioCategoria());
            tableViewRicCat.setItems(tab.getElements());
        }

        if (selectedValue.equals("RicambioFornitore")) {
            VisibilityDelViewRicForn vis = new VisibilityDelViewRicForn();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            tableViewVendTest.setVisible(false);
            tableViewVendDett.setVisible(false);
            codiceVendDett.setVisible(false);
            codiceRicambioVendFK.setVisible(false);
            prezzoUnitario.setVisible(false);
            quantitaVendita.setVisible(false);
            prezzoRiga.setVisible(false);
            codiceVendTest.setVisible(false);
            nomeAcquirente.setVisible(false);
            cognomeAcquirente.setVisible(false);
            codiceFiscale.setVisible(false);
            dataVendita.setVisible(false);
            prezzoTotale.setVisible(false);
            emailCliente.setVisible(false);
            details.setVisible(false);

            cellRicForn();

            TipoTabella<RicambioFornitore> tab = new TipoTabella<>(new TabellaRicambioFornitore());
            tableViewRicForn.setItems(tab.getElements());
        }

        if (selectedValue.equals("VenditaTestata")) {
            VisibilityViewVendTest vis = new VisibilityViewVendTest();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            tableViewVendTest.setVisible(true);
            tableViewVendDett.setVisible(false);
            codiceVendDett.setVisible(false);
            codiceRicambioVendFK.setVisible(false);
            prezzoUnitario.setVisible(false);
            quantitaVendita.setVisible(false);
            prezzoRiga.setVisible(false);
            codiceVendTest.setVisible(true);
            nomeAcquirente.setVisible(true);
            cognomeAcquirente.setVisible(true);
            codiceFiscale.setVisible(true);
            dataVendita.setVisible(true);
            prezzoTotale.setVisible(true);
            emailCliente.setVisible(true);
            details.setVisible(true);
            back.setVisible(true);
            backVend.setVisible(false);

            cellVendTest();

            TipoTabella<VenditaTestata> tab = new TipoTabella<>(new TabellaVenditaTestata());
            tableViewVendTest.setItems(tab.getElements());
        }

        if (selectedValue.equals("VenditaDettaglio")) {
            VisibilityViewVendDett vis = new VisibilityViewVendDett();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
            tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
            partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
            costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
            codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            tableViewVendTest.setVisible(false);
            tableViewVendDett.setVisible(true);
            codiceVendDett.setVisible(true);
            codiceRicambioVendFK.setVisible(true);
            prezzoUnitario.setVisible(true);
            quantitaVendita.setVisible(true);
            prezzoRiga.setVisible(true);
            codiceVendTest.setVisible(false);
            nomeAcquirente.setVisible(false);
            cognomeAcquirente.setVisible(false);
            codiceFiscale.setVisible(false);
            dataVendita.setVisible(false);
            prezzoTotale.setVisible(false);
            emailCliente.setVisible(false);
            details.setVisible(false);

            cellVendDett();

            TipoTabella<VenditaDettaglio> tab = new TipoTabella<>(new TabellaVenditaDettaglio());
            tableViewVendDett.setItems(tab.getElements());
        }

        if (selectedValue.equals("TipologiaAuto")) {
            VisibilityDelViewTipo vis = new VisibilityDelViewTipo();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
                    tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
                    costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
                    codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            tableViewVendTest.setVisible(false);
            tableViewVendDett.setVisible(true);
            codiceVendDett.setVisible(true);
            codiceRicambioVendFK.setVisible(true);
            prezzoUnitario.setVisible(true);
            quantitaVendita.setVisible(true);
            prezzoRiga.setVisible(true);
            codiceVendTest.setVisible(false);
            nomeAcquirente.setVisible(false);
            cognomeAcquirente.setVisible(false);
            codiceFiscale.setVisible(false);
            dataVendita.setVisible(false);
            prezzoTotale.setVisible(false);
            emailCliente.setVisible(false);
            details.setVisible(false);

            cellTipo();

            TipoTabella<TipologiaAuto> tab = new TipoTabella<>(new TabellaTipologiaAuto());
            tableViewTipo.setItems(tab.getElements());
        }

        if (selectedValue.equals("RicambioTipologia")) {
            VisibilityDelViewRicTipo vis = new VisibilityDelViewRicTipo();
            vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
                    tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                    partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
                    costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
                    codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

            tableViewVendTest.setVisible(false);
            tableViewVendDett.setVisible(true);
            codiceVendDett.setVisible(true);
            codiceRicambioVendFK.setVisible(true);
            prezzoUnitario.setVisible(true);
            quantitaVendita.setVisible(true);
            prezzoRiga.setVisible(true);
            codiceVendTest.setVisible(false);
            nomeAcquirente.setVisible(false);
            cognomeAcquirente.setVisible(false);
            codiceFiscale.setVisible(false);
            dataVendita.setVisible(false);
            prezzoTotale.setVisible(false);
            emailCliente.setVisible(false);
            details.setVisible(false);

            cellRicTipo();

            TipoTabella<RicambioTipologia> tab = new TipoTabella<>(new TabellaRicambioTipologia());
            tableViewRicTipo.setItems(tab.getElements());
        }
    }

    /**
     * Metodo che viene chiamato dal FXMLLoader una volta che l'inizializzazione è avvenuta.
     * In questo caso lo utilizzo per creare ed inserire le voci che saranno contenute nel menù a tendina,
     * ossia l'oggetto di tipo ComboBox.
     */
    @FXML
    void initialize() {
        /**
         * Creo un ObservableList che conterrà solo oggetti di tipo String, i quali verranno poi caricati mediante
         * metodo apposito, setItems, all'interno del menù a tendina, ossia l'oggetto di tipo ComboBox.
         */
        ObservableList<String> items = FXCollections.observableArrayList("Categoria", "Fornitore","Ricambio",
                "RicambioCategoria", "RicambioFornitore", "VenditaTestata", "VenditaDettaglio","TipologiaAuto",
                "RicambioTipologia");
        myComboBox.setItems(items);

        /**
         * Setto effetti e stile dei vari oggetti della scena.
         */
        myComboBox.setOnMouseEntered(e -> {
            myComboBox.setCursor(Cursor.HAND);
        });

        myComboBox.setOnMouseExited(e -> {
            myComboBox.setCursor(Cursor.DEFAULT);
        });

        myComboBox.setCellFactory(listView -> new ListCell<String>() {
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    setOnMouseEntered(e -> setCursor(Cursor.HAND));
                    setOnMouseExited(e -> setCursor(Cursor.DEFAULT));
                } else {
                    setOnMouseEntered(null);
                    setOnMouseExited(null);
                }
            }
        });

        DropShadow shadow = new DropShadow();

        back.setOnMouseEntered(e -> {
            back.setEffect(shadow);
            back.setStyle("-fx-background-color: #a9a9a7;");
            back.setCursor(Cursor.HAND);
        });

        back.setOnMouseExited(e -> {
            back.setEffect(null);
            back.setStyle("-fx-background-color: white;");
            back.setCursor(Cursor.DEFAULT);
        });

        backVend.setOnMouseEntered(e -> {
            backVend.setEffect(shadow);
            backVend.setStyle("-fx-background-color: #a9a9a7;");
            backVend.setCursor(Cursor.HAND);
        });

        backVend.setOnMouseExited(e -> {
            backVend.setEffect(null);
            backVend.setStyle("-fx-background-color: white;");
            backVend.setCursor(Cursor.DEFAULT);
        });
    }

    /**
     * Metodi privati che permettono la gestione apposita dell'associazione tra cella della tabella e valore
     * di quella variabile istanza privata.
     */

    private void cellCat() {
        codiceCategoria.setCellValueFactory(new PropertyValueFactory<>("codiceCategoria"));
        nomeCategoria.setCellValueFactory(new PropertyValueFactory<>("nomeCategoria"));
        descrizioneCategoria.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
    }

    private void cellForn() {
        codiceFornitore.setCellValueFactory(new PropertyValueFactory<>("codiceFornitore"));
        nomeFornitore.setCellValueFactory(new PropertyValueFactory<>("nomeFornitore"));
        partitaIva.setCellValueFactory(new PropertyValueFactory<>("partitaIVA"));
        indirizzo.setCellValueFactory(new PropertyValueFactory<>("indirizzo"));
        cap.setCellValueFactory(new PropertyValueFactory<>("CAP"));
        localita.setCellValueFactory(new PropertyValueFactory<>("localita"));
        nazione.setCellValueFactory(new PropertyValueFactory<>("nazione"));
    }

    private void cellRic() {
        codiceRicambio.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        nomeRicambio.setCellValueFactory(new PropertyValueFactory<>("nome"));
        descrizioneRicambio.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
        quantita.setCellValueFactory(new PropertyValueFactory<>("quantita"));
        costo.setCellValueFactory(new PropertyValueFactory<>("costo"));
        sconto.setCellValueFactory(new PropertyValueFactory<>("sconto"));
    }

    private void cellRicCat() {
        codiceRicambioCatFK.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        codiceCategoriaFK.setCellValueFactory(new PropertyValueFactory<>("codiceCategoria"));
    }

    private void cellRicForn() {
        codiceRicambioFornFK.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        codiceFornitoreFK.setCellValueFactory(new PropertyValueFactory<>("codiceFornitore"));
    }

    private void cellVendTest() {
        codiceVendTest.setCellValueFactory(new PropertyValueFactory<>("codiceVendita"));
        nomeAcquirente.setCellValueFactory(new PropertyValueFactory<>("nomeAcquirente"));
        cognomeAcquirente.setCellValueFactory(new PropertyValueFactory<>("cognomeAcquirente"));
        codiceFiscale.setCellValueFactory(new PropertyValueFactory<>("codiceFiscale"));
        dataVendita.setCellValueFactory(new PropertyValueFactory<>("dataVendita"));
        prezzoTotale.setCellValueFactory(new PropertyValueFactory<>("prezzoTotale"));
        emailCliente.setCellValueFactory(new PropertyValueFactory<>("emailCliente"));
        details.setCellFactory(param -> new ButtonCell());
    }

    private void cellVendDett() {
        codiceVendDett.setCellValueFactory(new PropertyValueFactory<>("codiceVendita"));
        codiceRicambioVendFK.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        prezzoUnitario.setCellValueFactory(new PropertyValueFactory<>("prezzoUnitario"));
        quantitaVendita.setCellValueFactory(new PropertyValueFactory<>("quantitaVendita"));
        prezzoRiga.setCellValueFactory(new PropertyValueFactory<>("prezzoRiga"));
    }

    private void cellTipo() {
        nomeTipo.setCellValueFactory(new PropertyValueFactory<>("nomeTipologia"));
        descTipo.setCellValueFactory(new PropertyValueFactory<>("descTipologia"));
    }

    private void cellRicTipo() {
        codiceRicambioTipo.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        nomeTipoRic.setCellValueFactory(new PropertyValueFactory<>("nomeTipologia"));
    }

    /**
     * Classe innestata che permette di gestire la creazione e gli eventidegli oggetti Button relativi
     * alla visualizzazione dei dettagli delle vendite.
     */
    private class ButtonCell extends TableCell<VenditaTestata, Button> {
        private Button viewDetails = new Button("Dettagli");
        private Database db;

        public ButtonCell() {
            /**
             * Quando si passa con il cursore sopra uno degli oggetti di tipo Button compare in sovrimpressione
             * un oggetto Tooltip con un testo che specifica che cliccando quel tasto si visualizzano le vendite
             * in dettaglio per quella VenditaTestata.
             */
            Tooltip tooltip = new Tooltip("Per visualizzare la vendita in dettaglio");
            tooltip.setStyle("-fx-font-size: 14;");
            Tooltip.install(viewDetails, tooltip);

            viewDetails.setOnMouseEntered(e -> {
                viewDetails.setCursor(Cursor.HAND);
            });

            viewDetails.setOnMouseExited(e -> {
                viewDetails.setCursor(Cursor.DEFAULT);
            });

            /**
             * Se clicco uno dei Button vado a creare una tabella di VenditaDettaglio relativa a quella singola
             * VenditaTestata
             */
            viewDetails.setOnAction(event -> {
                int vend = getTableView().getItems().get(getIndex()).getCodiceVendita();
                ObservableList<VenditaDettaglio> data = FXCollections.observableArrayList();

                /**
                 * Clausola try-catch per provare ad effettuare la connessione al database.
                 */
                try {
                    db = new Database();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }

                /**
                 * Recupero tutte le tuple relative ai ricambi venduti nella VenditaTestata di cui si vogliono
                 * visualizzare i dettagli.
                 */
                try {
                    ResultSet rs = db.query("select * from venditaricambi.venditadettaglio where codiceVendita=" + vend);

                    /**
                     * Aggiungo le tuple risultanti all'ObservableList con cui caricherò la tabella di VenditaDettaglio.
                     */
                    while (rs.next()) {
                        data.add(new VenditaDettaglio(rs.getInt(1),rs.getString(2),rs.getDouble(3),
                                rs.getInt(4),rs.getDouble(5)));
                    }
                }
                catch (Exception e) {
                    new RuntimeException(e);
                }

                cellVendDett();

                VisibilityViewVendDett vis = new VisibilityViewVendDett();
                vis.setVisibilityDelView(myComboBox, tableViewCat, tableViewForn, tableViewRic, tableViewRicCat,
                        tableViewRicForn, codiceCategoria, nomeCategoria, descrizioneCategoria, codiceFornitore, nomeFornitore,
                        partitaIva, indirizzo, cap, localita, nazione, codiceRicambio, nomeRicambio, descrizioneRicambio, quantita,
                        costo, sconto, codiceRicambioCatFK, codiceCategoriaFK, codiceRicambioFornFK,
                        codiceFornitoreFK, tableViewTipo, tableViewRicTipo);

                tableViewVendTest.setVisible(false);
                tableViewVendDett.setVisible(true);
                codiceVendDett.setVisible(true);
                codiceRicambioVendFK.setVisible(true);
                prezzoUnitario.setVisible(true);
                quantitaVendita.setVisible(true);
                prezzoRiga.setVisible(true);
                codiceVendTest.setVisible(false);
                nomeAcquirente.setVisible(false);
                cognomeAcquirente.setVisible(false);
                codiceFiscale.setVisible(false);
                dataVendita.setVisible(false);
                prezzoTotale.setVisible(false);
                emailCliente.setVisible(false);
                details.setVisible(false);
                back.setVisible(false);
                backVend.setVisible(true);
                myComboBox.setVisible(false);

                tableViewVendDett.setItems(data);
            });
        }

        /**
         * Effettuo l'override del metodo updateItem dalla superclasse Cell, in modo da inserire il button details
         * solo nelle righe della tabella non vuote, ossia quelle che contengono ricambi.
         */
        @Override
        protected void updateItem(Button item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
            } else {
                setGraphic(viewDetails);
            }
        }
    }
}
