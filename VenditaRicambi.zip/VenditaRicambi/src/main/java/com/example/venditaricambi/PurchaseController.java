package com.example.venditaricambi;

import application.EccezionePersonalizzata;
import application.Email;
import application.Ricambio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.stage.Stage;
import singleton.pattern.Database;
import strategy.pattern.Tabella4Ric;
import strategy.pattern.TipoTabella;

import javax.swing.*;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe che permette al cliente di visualizzare tutti i ricambi da poter comprare, con la possibilità di filtrarli
 * per categoria e/o per fornitore e con la possibilità di aggiungerli al carrello.
 * @author Luca Amoroso
 */
public class PurchaseController {

    @FXML
    private TableColumn<Ricambio, String> descrizioneRicambio;

    @FXML
    private TableColumn<Ricambio, String> nomeRicambio;

    @FXML
    private TableColumn<Ricambio, String> codiceRicambio;

    @FXML
    private TableColumn<Ricambio, Double> prezzo;

    @FXML
    private TableColumn<Ricambio, Button> aggiungiCarrello;

    @FXML
    private Button back;

    @FXML
    private Button cart;

    @FXML
    private TableView<Ricambio> tableViewRic;

    @FXML
    private ComboBox<String> myComboBoxCat;

    @FXML
    private ComboBox<String> myComboBoxForn;

    private static Database db;

    private String selectedValueCat;

    private String selectedValueForn;

    /**
     * Metodo che permette di tornare alla scena precedente rispetto a quella in cui ci troviamo,
     * ossia il layout dell'interfaccia utente relativo a "customerHome.fxml".
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleBack (ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("customerHome.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di gestire l'evento associato all'aver premuto il bottone "Vai al carrello", che permette
     * appunto di caricare la scena relativa al carrello dell'utente.
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleCart(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("cart.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di gestire le azioni scaturite da una scelta nel menù a tendina riguardante la categoria
     * delle categorie.
     */
    @FXML
    void handleComboBoxCat(ActionEvent event) {
        /**
         * Memorizzo il valore scelto nel menù a tendina, ossia la ComboBox, in un oggetto di tipo String.
         */
        selectedValueCat = myComboBoxCat.getValue();

        /**
         * Se la categoria viene ripristinata a qualsiasi e non è stato selezionato alcun fornitore, allora vengono
         * visualizzati tutti i ricambi
         */
        if (selectedValueCat.equals("QUALSIASI") && (selectedValueForn == null || selectedValueForn.equals("QUALSIASI"))) {
            TipoTabella<Ricambio> tab = new TipoTabella<>(new Tabella4Ric());
            tableViewRic.setItems(tab.getElements());
            tableViewRic.refresh();
        }
        /**
         * Se non è stato selezionato alcun fornitore, i ricambi vengono semplicementi filtrati in base alla categoria.
         */
        else if (selectedValueForn == null || selectedValueForn.equals("QUALSIASI")) {
            ObservableList<Ricambio> data = FXCollections.observableArrayList();

            /**
             * Effettuo una query per caricare i ricambi, filtrati per categoria, con il prezzo degli stessi già scontato.
             */
            try
            {
                String sql = "select r.codiceRicambio,r.nomeRicambio,r.descrizioneRicambio,(r.costo - ((r.costo*r.sconto)/100))" +
                        " as prezzoUnitario from (venditaricambi.ricambio" +
                        " r join venditaricambi.ricambiocategoria rc on r.codiceRicambio = rc.codiceRicambio)" +
                        " join venditaricambi.categoria c on rc.codiceCategoria = c.codiceCategoria where" +
                        " c.nomeCategoria='" + selectedValueCat + "'";
                ResultSet rs = db.query(sql);
                /**
                 * Scorro le tuple risultanti dalla query, aggiungendole ad un oggetto di tipo ObservableList.
                 */
                while(rs.next())
                {
                    data.add(new Ricambio(rs.getString(1), rs.getString(2),
                            rs.getString(3),0,rs.getDouble(4),0));
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            tableViewRic.setItems(data);
            tableViewRic.refresh();
        }
        /**
         * Se viene ripristinata la categoria a qualsiasi, ma il filtro legato ai fornitori è attivo, i ricambi devono
         * essere filtrati solo in base al fornitore.
         */
        else if (selectedValueCat.equals("QUALSIASI") && (selectedValueForn != null
        && !selectedValueForn.equals("QUALSIASI"))) {
            ObservableList<Ricambio> data = FXCollections.observableArrayList();

            /**
             *
             * Effettuo una query per caricare i ricambi, filtrati per categoria, con il prezzo degli stessi già scontato.
             */
            try
            {
                String sql = "select r.codiceRicambio,r.nomeRicambio,r.descrizioneRicambio,(r.costo - ((r.costo*r.sconto)/100))" +
                        " as prezzoUnitario from (venditaricambi.ricambio" +
                        " r join venditaricambi.ricambiofornitore rf on r.codiceRicambio = rf.codiceRicambio)" +
                        " join venditaricambi.fornitore f on rf.codiceFornitore = f.codiceFornitore where" +
                        " f.nomeFornitore='" + selectedValueForn + "'";
                ResultSet rs = db.query(sql);
                /**
                 * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
                 */
                while(rs.next())
                {
                    data.add(new Ricambio(rs.getString(1), rs.getString(2),
                            rs.getString(3),0,rs.getDouble(4),0));
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            tableViewRic.setItems(data);
            tableViewRic.refresh();
        }
        /**
         * Se i ricambi vengono filtrati in base sia alla categoria che ai fornitori, allora bisogna effettuare
         * una query che permetta di far visualizzare ai clienti solo i ricambi relativi a quella determinata categoria
         * e forniti da quel determinato fornitore.
         */
        else {
            ObservableList<Ricambio> data = FXCollections.observableArrayList();

            /**
             * Effettuo una query per caricare i ricambi, filtrati sia per categoria che per fornitore,
             * con il prezzo degli stessi già scontato.
             */
            try
            {
                String sql = "select r.codiceRicambio,r.nomeRicambio,r.descrizioneRicambio,(r.costo - ((r.costo*r.sconto)/100))" +
                        " as prezzoUnitario from" +
                        " (((venditaricambi.ricambio r join venditaricambi.ricambiofornitore rf on" +
                        " r.codiceRicambio = rf.codiceRicambio) join venditaricambi.fornitore f on" +
                        " rf.codiceFornitore = f.codiceFornitore) join venditaricambi.ricambiocategoria rc on" +
                        " r.codiceRicambio = rc.codiceRicambio) join venditaricambi.categoria c on" +
                        " rc.codiceCategoria = c.codiceCategoria where c.nomeCategoria='" + selectedValueCat + "' and" +
                        " f.nomeFornitore='" + selectedValueForn + "'";

                ResultSet rs = db.query(sql);
                /**
                 * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
                 */
                while(rs.next())
                {
                    data.add(new Ricambio(rs.getString(1), rs.getString(2),
                            rs.getString(3),0,rs.getDouble(4),0));
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            /**
             * Setto i nuovi ricambi da visualizzare in tabella in base alla scelta effettuata nella ComboBox, ossia il
             * menù a tendina.
             */
            tableViewRic.setItems(data);
            tableViewRic.refresh();
        }
    }

    /**
     * Metodo per gestire la selezione delle varie voci della ComboBox legata ai fornitore, ossia il menù a tendina,
     * in modo simile a come fatto per le categorie.
     */
    @FXML
    void handleComboBoxForn(ActionEvent event) {
        /**
         * Memorizzo il valore scelto nel menù a tendina, ossia la ComboBox, in un oggetto di tipo String.
         */
        selectedValueForn = myComboBoxForn.getValue();

        /**
         * Se la categoria viene ripristinata a qualsiasi e non è stato selezionato alcun fornitore, allora vengono
         * visualizzati tutti i ricambi.
         */
        if (selectedValueForn.equals("QUALSIASI") && (selectedValueCat == null || selectedValueCat.equals("QUALSIASI"))) {
            TipoTabella<Ricambio> tab = new TipoTabella<>(new Tabella4Ric());
            tableViewRic.setItems(tab.getElements());
            tableViewRic.refresh();
        }
        /**
         * Se invece ad essere nulla o qualsiasi è solo la Categoria, allora i ricambi devono essere filtrati solo
         * in base al fornitore scelto.
         */
        else if (selectedValueCat == null || selectedValueCat.equals("QUALSIASI")) {
            ObservableList<Ricambio> data = FXCollections.observableArrayList();

            /**
             * Recupero tutti i ricambi relativi ad un determinato fornitore scelto dal cliente.
             */
            try
            {
                String sql = "select r.codiceRicambio,r.nomeRicambio,r.descrizioneRicambio,(r.costo - ((r.costo*r.sconto)/100))" +
                        " as prezzoUnitario from (venditaricambi.ricambio" +
                        " r join venditaricambi.ricambiofornitore rf on r.codiceRicambio = rf.codiceRicambio)" +
                        " join venditaricambi.fornitore f on rf.codiceFornitore = f.codiceFornitore where" +
                        " f.nomeFornitore='" + selectedValueForn + "'";
                ResultSet rs = db.query(sql);
                /**
                 * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
                 */
                while(rs.next())
                {
                    data.add(new Ricambio(rs.getString(1), rs.getString(2),
                            rs.getString(3),0,rs.getDouble(4),0));
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            tableViewRic.setItems(data);
            tableViewRic.refresh();
        }
        /**
         * Se reimposto a qualsiasi la selezione relativa al fornitore ma vi è un filtro per la categoria, visualizzo
         * solo i ricambi relativi a quella categoria.
         */
        else if (selectedValueForn.equals("QUALSIASI") && (selectedValueCat != null
        && !selectedValueCat.equals("QUALSIASI"))) {
            ObservableList<Ricambio> data = FXCollections.observableArrayList();

            try
            {
                String sql = "select r.codiceRicambio,r.nomeRicambio,r.descrizioneRicambio,(r.costo - ((r.costo*r.sconto)/100))" +
                        " as prezzoUnitario from (venditaricambi.ricambio" +
                        " r join venditaricambi.ricambiocategoria rc on r.codiceRicambio = rc.codiceRicambio)" +
                        " join venditaricambi.categoria c on rc.codiceCategoria = c.codiceCategoria where" +
                        " c.nomeCategoria='" + selectedValueCat + "'";
                ResultSet rs = db.query(sql);
                /**
                 * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
                 */
                while(rs.next())
                {
                    data.add(new Ricambio(rs.getString(1), rs.getString(2),
                            rs.getString(3),0,rs.getDouble(4),0));
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            tableViewRic.setItems(data);
            tableViewRic.refresh();
        }
        /**
         * Se invece si filtrano i ricambi in base sia ad una categoria che ad un fornitore.
         */
        else {
            ObservableList<Ricambio> data = FXCollections.observableArrayList();

            try
            {
                String sql = "select r.codiceRicambio,r.nomeRicambio,r.descrizioneRicambio,(r.costo - ((r.costo*r.sconto)/100))" +
                        " as prezzoUnitario from" +
                        " (((venditaricambi.ricambio r join venditaricambi.ricambiocategoria rc on" +
                        " r.codiceRicambio = rc.codiceRicambio) join venditaricambi.categoria c on" +
                        " rc.codiceCategoria = c.codiceCategoria) join venditaricambi.ricambiofornitore rf on" +
                        " r.codiceRicambio = rf.codiceRicambio) join venditaricambi.fornitore f on" +
                        " rf.codiceFornitore = f.codiceFornitore where c.nomeCategoria='" + selectedValueCat + "' and" +
                        " f.nomeFornitore='" + selectedValueForn + "'";

                ResultSet rs = db.query(sql);
                /**
                 * Scorro le tuple risultanti dalla query, aggiungendole alla variabile istanza privata.
                 */
                while(rs.next())
                {
                    data.add(new Ricambio(rs.getString(1), rs.getString(2),
                            rs.getString(3),0,rs.getDouble(4),0));
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            tableViewRic.setItems(data);
            tableViewRic.refresh();
        }
    }

    /**
     * Metodo che viene chiamata nella fase di inizializzazione della scena.
     * @throws SQLException eccezioni legate a operazioni SQL, quindi relative al database
     */
    @FXML
    void initialize() throws SQLException {
        /**
         * Clausola try-catch per provare ad effettuare la connessione al database.
         */
        try {
            db = new Database();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        /**
         * Creo delle ObservableList che conterranno solo oggetti di tipo String, i quali verranno  caricati mediante
         * metodo apposito, setItems, all'interno dei menù a tendina, ossia gli oggetti di tipo ComboBox,
         * per visualizzare i ricambi filtrati per categoria o fornitore.
         */
        ResultSet rsCat = db.query("select distinct nomeCategoria from venditaricambi.categoria");
        ObservableList<String> itemsCat = FXCollections.observableArrayList();
        while (rsCat.next())
            itemsCat.add(rsCat.getString(1));
        itemsCat.add("QUALSIASI");
        myComboBoxCat.setItems(itemsCat);

        ResultSet rsForn = db.query("select distinct nomeFornitore from venditaricambi.fornitore");
        ObservableList<String> itemsForn = FXCollections.observableArrayList();
        while (rsForn.next())
            itemsForn.add(rsForn.getString(1));
        itemsForn.add("QUALSIASI");
        myComboBoxForn.setItems(itemsForn);

        /**
         * Setto e carico i valori da inserire nelle varie colonne della tabella in cui visualizzo i ricambi.
         */
        codiceRicambio.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        nomeRicambio.setCellValueFactory(new PropertyValueFactory<>("nome"));
        descrizioneRicambio.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
        prezzo.setCellValueFactory(new PropertyValueFactory<>("costo"));
        aggiungiCarrello.setCellFactory(param -> new ButtonCell());

        TipoTabella<Ricambio> tab = new TipoTabella<>(new Tabella4Ric());
        tableViewRic.setItems(tab.getElements());

        /**
         * Setto effetti e stile dei vari oggetti della scena.
         */
        DropShadow shadow = new DropShadow();

        back.setOnMouseEntered(e -> {
            back.setEffect(shadow);
            back.setStyle("-fx-background-color: #8f6500;");
            back.setCursor(Cursor.HAND);
        });

        back.setOnMouseExited(e -> {
            back.setEffect(null);
            back.setStyle("-fx-background-color: #f4ad00;");
            back.setCursor(Cursor.DEFAULT);
        });

        cart.setOnMouseEntered(e -> {
            cart.setEffect(shadow);
            cart.setStyle("-fx-background-color: #3b4366;");
            cart.setCursor(Cursor.HAND);
        });

        cart.setOnMouseExited(e -> {
            cart.setEffect(null);
            cart.setStyle("-fx-background-color: #0b1541;");
            cart.setCursor(Cursor.DEFAULT);
        });

        myComboBoxCat.setOnMouseEntered(e -> {
            myComboBoxCat.setCursor(Cursor.HAND);
        });

        myComboBoxCat.setOnMouseExited(e -> {
            myComboBoxCat.setCursor(Cursor.DEFAULT);
        });

        myComboBoxCat.setCellFactory(listView -> new ListCell<String>() {
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    setOnMouseEntered(e -> setCursor(Cursor.HAND));
                    setOnMouseExited(e -> setCursor(Cursor.DEFAULT));
                } else {
                    setOnMouseEntered(null);
                    setOnMouseExited(null);
                }
            }
        });

        myComboBoxForn.setOnMouseEntered(e -> {
            myComboBoxForn.setCursor(Cursor.HAND);
        });

        myComboBoxForn.setOnMouseExited(e -> {
            myComboBoxForn.setCursor(Cursor.DEFAULT);
        });

        myComboBoxForn.setCellFactory(listView -> new ListCell<String>() {
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    setOnMouseEntered(e -> setCursor(Cursor.HAND));
                    setOnMouseExited(e -> setCursor(Cursor.DEFAULT));
                } else {
                    setOnMouseEntered(null);
                    setOnMouseExited(null);
                }
            }
        });

        /**
         * Controllo se sono avvenuti cambiamenti nelle quantità dei ricambi che si trovano nel carrello del cliente,
         * se sì, effettuo un update della quantità richiesta dal cliente al massimo soddisfabile, mentre se la nuova
         * quantità è 0, elimino il ricambio dal carrello.
         */
        ResultSet rs = db.query("select rc.codiceRicambio,rc.quantitaRic from venditaricambi.ricambiocarrello rc" +
                " join venditaricambi.carrello c on c.idCarrello = rc.idCarrello" +
                " where c.emailCliente = '" + Email.getIstanza().getEmail() + "'");

        ResultSet rs2 = db.query("select codiceRicambio,quantita from venditaricambi.ricambio");

        /**
         * Creo due arrayList per memorizzare i codiciRicambio e la quantità associata risultanti dalla query.
         */
        List<String> codRic = new ArrayList<>();
        List<Integer> quant = new ArrayList<>();

        /**
         * Riempio i due arrayList.
         */
        while(rs2.next()) {
            codRic.add(rs2.getString(1));
            quant.add(rs2.getInt(2));
        }

        /**
         * Controllo le corrispondenze tra i ricambi nel carrello e tutti i ricambi. Quando viene trovata una corrispondenza,
         * controllo se la quantità richiesta dal cliente è maggiore di quella a magazzino. Se poi la quantità a magazzino
         * è 0, viene eliminato il ricambio dal carrello, altrimenti viene solo aggiornata la quantità al massimo
         * soddisfabile. Se avvengono cambiamenti, comunque, quando il cliente logga, viene notificato da un messaggio
         * in sovraschermo.
         */
        while(rs.next()) {
            /**
             * Scorro i due arrayList in base al size di uno di loro, visto che hanno stesso size.
             */
            for (int i=0; i<codRic.size(); i++) {
                /**
                 * Cerco le corrispondenze tra i ricambi presenti nel carrello e i ricambi nella loro tabella di partenza.
                 */
                if (rs.getString(1).equals(codRic.get(i))) {
                    /**
                     * Quando viene trovata una corrispondenza, controllo se la quantità nel carrello è maggiore di quella
                     * segnata nella tabella Ricambio.
                     */
                    if (rs.getInt(2) > quant.get(i)) {
                        /**
                         * Controllo se la quantità generale del ricambio è maggiore di 0. In caso affermativo modifico
                         * la quantità nel carrello del cliente alla massima disponibile. In caso negativo, invece,
                         * elimino il ricambio dal carrello del cliente, in quanto la quantità nella tabella Ricambio è 0.
                         */
                        if (quant.get(i) > 0) {
                            db.update("update venditaricambi.ricambiocarrello set quantitaRic='" + quant.get(i) +
                                    "' where codiceRicambio='" + codRic.get(i) + "'");
                        } else {
                            db.update("delete from venditaricambi.ricambiocarrello where codiceRicambio='" +
                                    codRic.get(i) + "' and idCarrello = (select idCarrello from venditaricambi.carrello" +
                                    " where emailCliente='" + Email.getIstanza().getEmail() + "')");
                        }
                        JOptionPane.showMessageDialog(null, "\nIl carrello è stato aggiornato" +
                                " in virtù dei cambiamenti delle scorte dei ricambi!");
                    }
                }
            }
        }
    }

    /**
     * Classe innestata che permette la creazione e la gestione dei bottoni "Aggiungi al carrello" vicino
     * ad ogni ricambio.
     */
    private static class ButtonCell extends TableCell<Ricambio, Button> {
        private Button addButton = new Button("Aggiungi al carrello");

        public ButtonCell() {
            addButton.setOnMouseEntered(e -> {
                addButton.setCursor(Cursor.HAND);
            });

            addButton.setOnMouseExited(e -> {
                addButton.setCursor(Cursor.DEFAULT);
            });

            addButton.setOnAction(event -> {
                Ricambio ric = getTableView().getItems().get(getIndex());
                Email em = Email.getIstanza();

                /**
                 * Se il cliente preme i bottoni "Aggiungi al carrello" vengono effettuate diverse operazioni.
                 * In primis si controlla se esiste un carrello collegato a quel cliente, e se non esiste viene creato.
                 */
                try {
                    ResultSet rs = db.query("select * from venditaricambi.carrello where emailCliente='" +
                            em.getEmail() + "'");

                    if (!rs.next()) {
                        String q = "insert into venditaricambi.carrello (emailCliente) values (?)";

                        PreparedStatement preparedStmt = db.insert(q);
                        preparedStmt.setString(1, em.getEmail());

                        preparedStmt.execute();
                    }

                    /**
                     * Dopo aver creato il carrello, se non esisteva, recupero l'id del carrello associato al cliente.
                     */
                    ResultSet rs2 = db.query("select idCarrello from venditaricambi.carrello where emailCliente='" +
                            em.getEmail() + "'");

                    rs2.next();

                    /**
                     * Recupero il ricambio che si vuole aggiungere nel carrello tramite query.
                     */
                    ResultSet rs3 = db.query("select * from venditaricambi.ricambiocarrello" +
                                    " where idCarrello='" + rs2.getString(1) + "' and codiceRicambio='" +
                                    ric.getCodiceRicambio() + "'");

                    /**
                     * Recupero la quantità a magazzino del ricambio che si vuole aggiungere al carrello.
                     */
                    ResultSet rs4 = db.query("select quantita from ricambio where codiceRicambio='" +
                            ric.getCodiceRicambio() + "'");
                    rs4.next();

                    /**
                     * Se la query che cercava il ricambio da aggiungere non dà risultati, allora si inserisce il nuovo
                     * ricambio nel carrello, con quantità 1.
                     */
                    if (!rs3.next()) {
                        String q = "insert into venditaricambi.ricambiocarrello (idCarrello,codiceRicambio,quantitaRic)" +
                                " values (?,?,?)";

                        PreparedStatement preparedStmt = db.insert(q);
                        preparedStmt.setString(1, rs2.getString(1));
                        preparedStmt.setString(2, ric.getCodiceRicambio());
                        preparedStmt.setInt(3, 1);
                        preparedStmt.execute();

                        JOptionPane.showMessageDialog(null, "Nuovo ricambio inserito correttamente" +
                                " nel carrello!");
                    } else {
                        /**
                         * Se invece il ricambio esisteva già nel carrello associato a quell'utente, allora aggiungo
                         * una unità, se disponibile a magazzino, altrimenti viene visualizzato un messaggio di errore
                         * in sovraschermo.
                         */
                        if ((rs3.getInt(3) + 1) > rs4.getInt(1)) {
                            throw new EccezionePersonalizzata("\nErrore durante l'aggiunta al carrello, non sono" +
                                    " disponibili altre scorte di questo ricambio!");
                        } else {
                            String q = "update venditaricambi.ricambiocarrello set quantitaRic='" +
                                    (rs3.getInt(3) + 1) + "' where idCarrello='" + rs3.getString(1) +
                                    "' and codiceRicambio='" + rs3.getString(2) + "'";

                            db.update(q);

                            JOptionPane.showMessageDialog(null, "Quantità del ricambio aggiornata" +
                                    " correttamente nel carrello!");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            });
        }

        /**
         * Effettuo l'override del metodo updateItem dalla superclasse Cell, in modo da inserire il button addButton
         * solo nelle righe della tabella non vuote, ossia quelle che contengono ricambi.
         */
        @Override
        protected void updateItem(Button item, boolean empty) {
            super.updateItem(item, empty);
            if (empty) {
                setGraphic(null);
            } else {
                setGraphic(addButton);
            }
        }
    }
}
