package com.example.venditaricambi;

import application.EccezionePersonalizzata;
import application.Email;
import application.Ricambio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import singleton.pattern.Database;
import strategy.pattern.Tabella5Ric;
import strategy.pattern.TipoTabella;

import javax.swing.*;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;

/**
 * Classe che permette la gestione della scena relativa al carrello e alle azioni possibili.
 * @author Luca Amoroso
 */
public class CartController {

    @FXML
    private TableColumn<Ricambio, String> descrizioneRicambio;

    @FXML
    private ComboBox<String> myComboBox;

    @FXML
    private TableColumn<Ricambio, String> nomeRicambio;

    @FXML
    private TableColumn<Ricambio, String> codiceRicambio;

    @FXML
    private TableColumn<Ricambio, Double> prezzoUnitario;

    @FXML
    private Button back;

    @FXML
    private Button payment;

    @FXML
    private TextField newQuantita;

    @FXML
    private Button modify;

    @FXML
    private Button remove;

    @FXML
    private Text tot;

    @FXML
    private TableColumn<Ricambio, Integer> quantita;

    @FXML
    private TableView<Ricambio> tableView;

    private Database db;

    /**
     * Metodo che viene invocato al termine della fase di inizializzazione e che permette di visualizzare il carrello
     * legato al cliente, con i vari ricambi, il prezzo unitario, già scontato, e la quantità richiesta.
     * Oltre a questo viene anche visualizzato, nella parte superiore dello schermo, il totale del carrello, in euro.
     * @throws SQLException eccezioni relative alle operazioni SQL, quindi quelle legate al database
     */
    @FXML
    void initialize() throws SQLException {
        /**
         * Setto i valori della ComboBox, ossia il menù a tendina.
         */
        ObservableList<String> items = FXCollections.observableArrayList("Modifica quantità","Rimuovi articolo",
                "Nessuna azione");
        myComboBox.setItems(items);

        /**
         * Clausola try-catch per provare ad effettuare la connessione al database.
         */
        try {
            db = new Database();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        /**
         * Eseguo una query per ricavare il prezzo totale del carrello e lo formatto in modo da visualizzare la ","
         * invece del "." e il simbolo dell'euro.
         */
        ResultSet rs = db.query("select ROUND(SUM(rc.quantitaRic*(r.costo-((r.costo*r.sconto)/100))),2)" +
                        " from (venditaricambi.ricambio r join venditaricambi.ricambiocarrello rc on" +
                        " r.codiceRicambio = rc.codiceRicambio) join carrello c on rc.idCarrello = c.idCarrello" +
                        " where c.emailCliente='" + Email.getIstanza().getEmail() + "'");
        rs.next();
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
        String formattedTotal = decimalFormat.format(rs.getDouble(1));
        tot.setText("Totale carrello: " + formattedTotal+ "€");


        /**
         * Setto i valori che dovranno essere visualizzati nella tabella relativa al carrello.
         */
        codiceRicambio.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        nomeRicambio.setCellValueFactory(new PropertyValueFactory<>("nome"));
        descrizioneRicambio.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
        prezzoUnitario.setCellValueFactory(new PropertyValueFactory<>("costo"));
        quantita.setCellValueFactory(new PropertyValueFactory<>("quantita"));

        TipoTabella<Ricambio> tab = new TipoTabella<>(new Tabella5Ric());
        tableView.setItems(tab.getElements());

        /**
         * Setto gli effetti relativi ai vari oggetti della scena.
         */
        DropShadow shadow = new DropShadow();

        back.setOnMouseEntered(e -> {
            back.setEffect(shadow);
            back.setStyle("-fx-background-color: #8f6500;");
            back.setCursor(Cursor.HAND);
        });

        back.setOnMouseExited(e -> {
            back.setEffect(null);
            back.setStyle("-fx-background-color: #f4ad00;");
            back.setCursor(Cursor.DEFAULT);
        });

        payment.setOnMouseEntered(e -> {
            payment.setEffect(shadow);
            payment.setStyle("-fx-background-color: #3b4366;");
            payment.setCursor(Cursor.HAND);
        });

        payment.setOnMouseExited(e -> {
            payment.setEffect(null);
            payment.setStyle("-fx-background-color: #0b1541;");
            payment.setCursor(Cursor.DEFAULT);
        });

        myComboBox.setOnMouseEntered(e -> {
            myComboBox.setCursor(Cursor.HAND);
        });

        myComboBox.setOnMouseExited(e -> {
            myComboBox.setCursor(Cursor.DEFAULT);
        });

        modify.setOnMouseEntered(e -> {
            modify.setEffect(shadow);
            modify.setStyle("-fx-background-color: #a9a9a7;");
            modify.setCursor(Cursor.HAND);
        });

        modify.setOnMouseExited(e -> {
            modify.setEffect(null);
            modify.setStyle("-fx-background-color: white;");
            modify.setCursor(Cursor.DEFAULT);
        });

        remove.setOnMouseEntered(e -> {
            remove.setEffect(shadow);
            remove.setStyle("-fx-background-color: #a9a9a7;");
            remove.setCursor(Cursor.HAND);
        });

        remove.setOnMouseExited(e -> {
            remove.setEffect(null);
            remove.setStyle("-fx-background-color: white;");
            remove.setCursor(Cursor.DEFAULT);
        });

        myComboBox.setCellFactory(listView -> new ListCell<String>() {
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    setOnMouseEntered(e -> setCursor(Cursor.HAND));
                    setOnMouseExited(e -> setCursor(Cursor.DEFAULT));
                } else {
                    setOnMouseEntered(null);
                    setOnMouseExited(null);
                }
            }
        });

        tableView.setRowFactory(tv -> {
            TableRow<Ricambio> row = new TableRow<>();

            row.setOnMouseEntered(eventEnt ->  {
                if (!row.isEmpty())
                    row.setCursor(Cursor.HAND);
            });

            row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

            return row;
        });
    }

    /**
     * Metodo che permette di tornare alla pagina relativa agli acquisti, ossia "purchase.fxml".
     */
    @FXML
    void handleBack(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("purchase.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di andare alla pagina relativa al pagamento degli oggetti contenuti nel carrello.
     */
    @FXML
    void handlePayment(ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("payment.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di gestire le operazioni legate alla modifica della quantità richiesta di un ricambio.
     * @throws Exception eccezioni di qualsiasi tipo
     */
    @FXML
    void handleModify(ActionEvent event) throws Exception {
        Ricambio ric = tableView.getSelectionModel().getSelectedItem();

        /**
         * Controllo se sia stato inserito un valore nel campo di testo relativo alla nuova quantità e se sia stato
         * selezionato un ricambio da modificare.
         */
        if (newQuantita.getText().isEmpty() || ric == null) {
            tableView.getSelectionModel().clearSelection();
            newQuantita.clear();
            throw new EccezionePersonalizzata("\nErrore nella modifica, scegliere il ricambio di cui si vuole modificare" +
                    " la quantità ed inserire la nuova quantità richiesta!");
        }

        int newQuant;

        /**
         * Controllo se sia stato inserito un numero intero nel campo di testo relativo alla nuova quantità.
         */
        try {
            newQuant = Integer.parseInt(newQuantita.getText());
        }
        catch (NumberFormatException e) {
            tableView.getSelectionModel().clearSelection();
            newQuantita.clear();
            throw new EccezionePersonalizzata("\nNon è stato inserito un valore valido!");
        }

        /**
         * Controllo che la nuova quantità inserita sia maggiore di 0, in quanto altrimenti bisognerebbe effettuare
         * un'eliminazione del ricambio dal carrello.
         */
        if (newQuant <= 0) {
            tableView.getSelectionModel().clearSelection();
            newQuantita.clear();
            throw new EccezionePersonalizzata("\nErrore nella modifica della quantità, se si vuole procedere" +
                    " all'eliminazione del ricambio dal carrello, scegliere la voce 'Rimuovi articolo' dal menù" +
                    " a tendina");
        }

        /**
         * Recupero la quantità del ricambio selezionato.
         */
        ResultSet rs = db.query("select quantita from venditaricambi.ricambio where codiceRicambio = '" +
                ric.getCodiceRicambio() + "'");
        rs.next();

        /**
         * Se la nuova quantità che si vuole impostare è maggiore della quantità presente a magazzino, allora
         * viene effettuato un aggiornamento della quantità richiesta al massimo soddisfabile, notificando il cliente.
         */
        if (newQuant > rs.getInt(1)) {
            db.update("update venditaricambi.ricambiocarrello set quantitaRic=" + rs.getInt(1) + " where" +
                    " codiceRicambio='" + ric.getCodiceRicambio() + "' and idCarrello = (select idCarrello from" +
                    " venditaricambi.carrello where emailCliente='" + Email.getIstanza().getEmail() + "')");

            JOptionPane.showMessageDialog(null, "\nErrore durante l'inserimento, non ci sono abbastanza" +
                    " scorte per soddisfare la tua richiesta, inserisco automaticamente la massima quantità" +
                    " acquistabile per il ricambio selezionato!");
        }
        /**
         * Se la quantità è compresa tra 1 e la quantità a magazzino, allora viene effettuato un aggiornamento classico.
         */
        else {
            db.update("update venditaricambi.ricambiocarrello set quantitaRic=" + newQuant + " where" +
                    " codiceRicambio='" + ric.getCodiceRicambio() + "' and idCarrello = (select idCarrello from" +
                    " venditaricambi.carrello where emailCliente='" + Email.getIstanza().getEmail() + "')");

            JOptionPane.showMessageDialog(null, "\nQuantità aggiornata correttamente!");
        }

        /**
         * Ricarico la scena, in modo da aggiornare, oltre ai valori visualizzati nella tabella, che si potevano
         * aggiornare anche tramite metodo refresh(), l'oggetto di tipo Text relativo al totale del carrello.
         */
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("cart.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette la gestione della rimozione dell'articolo selezionato dal carrello.
     */
    @FXML
    void handleRemove(ActionEvent event) throws Exception {
        Ricambio ric = tableView.getSelectionModel().getSelectedItem();

        /**
         * Controllo che venga selezionato un ricambio da rimuove e procedo alla rimozione dal carrello.
         */
        if (ric != null) {
            db.update("delete from venditaricambi.ricambiocarrello where codiceRicambio = '"
                    + ric.getCodiceRicambio() + "' and idCarrello = (select idCarrello from venditaricambi.carrello" +
                    " where emailCliente = '" + Email.getIstanza().getEmail() + "')");

            JOptionPane.showMessageDialog(null, "\nEliminazione avvenuta correttamente!");
        }
        else {
            throw new EccezionePersonalizzata("\nSeleziona un articolo da rimuovere!");
        }

        /**
         * Ricarico la scena, in modo da aggiornare, oltre ai valori visualizzati nella tabella, che si potevano
         * aggiornare anche tramite metodo refresh(), l'oggetto di tipo Text relativo al totale del carrello.
         */
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("cart.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette la gestione delle scelte nel menù a tendina e la visibilità di alcuni oggetti.
     */
    @FXML
    void handleComboBox(ActionEvent event) throws Exception {
        String selectedValue = myComboBox.getValue();

        if (selectedValue.equals("Modifica quantità")) {
            modify.setVisible(true);
            newQuantita.setVisible(true);
            remove.setVisible(false);
        }

        if (selectedValue.equals("Rimuovi articolo")) {
            modify.setVisible(false);
            newQuantita.setVisible(false);
            remove.setVisible(true);
        }

        if (selectedValue.equals("Nessuna azione")) {
            modify.setVisible(false);
            newQuantita.setVisible(false);
            remove.setVisible(false);

            tableView.getSelectionModel().clearSelection();
            newQuantita.clear();
        }
    }

}
