package com.example.venditaricambi;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.EccezionePersonalizzata;
import application.Ricambio;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.stage.Stage;
import singleton.pattern.Database;
import strategy.pattern.TabellaRicambio;
import strategy.pattern.TipoTabella;

import javax.swing.*;

/**
 * Classe che permette la gestione delle modifiche per quanto riguarda i valori di quantità e sconto dei ricambi.
 * @author Luca Amoroso
 */
public class ApplyController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<Ricambio, String> descrizioneRicambio;

    @FXML
    private TableColumn<Ricambio, String> nomeRicambio;

    @FXML
    private TableColumn<Ricambio, Double> costo;

    @FXML
    private TableColumn<Ricambio, String> codiceRicambio;

    @FXML
    private TableColumn<Ricambio, Integer> quantita;

    @FXML
    private TableView<Ricambio> tableViewRic;

    @FXML
    private TableColumn<Ricambio, Integer> sconto;

    @FXML
    private Button apply;

    @FXML
    private Button back;

    @FXML
    private TextField modifySconto;

    @FXML
    private TextField addQuant;

    @FXML
    private ComboBox<String> myComboBox;

    private Database db;

    /**
     * Metodo che permette di tornare alla scena precedente rispetto a quella in cui ci troviamo,
     * ossia il layout dell'interfaccia utente relativo a "adminHome.fxml".
     * @param event evento associato all'interfaccia utente, che scaturisce la chiamata a questo metodo
     * @throws IOException eccezione relativa alle operazioni di I/O
     */
    @FXML
    void handleBack (ActionEvent event) throws IOException {
        Parent tableViewParent = FXMLLoader.load(getClass().getResource("adminHome.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setResizable(false);
        window.show();
    }

    /**
     * Metodo che permette di gestire le operazioni scaturite dal click sul tasto "Applica"
     * @throws Exception eccezioni di qualsiasi tipo
     */
    @FXML
    void handleApply(ActionEvent event) throws Exception {
        Ricambio selectedRicambio = tableViewRic.getSelectionModel().getSelectedItem();
        String selectedValue = myComboBox.getValue();

        /**
         * Controllo che venga effettivamente selezionato un ricambio da modificare, altrimenti lancio un'eccezione.
         */
        if (selectedValue == null) {
            tableViewRic.getSelectionModel().clearSelection();
            throw new EccezionePersonalizzata("\nErrore, scegliere l'azione da effettuare dal menù a tendina!");
        }

        /**
         * In base alla scelta effettuata nel menù a tendina, ossia nella ComboBox, viene visualizzato un campo
         * di testo apposito e viene effettuata una query di update apposita.
         */
        if (selectedValue.equals("Aggiungi quantità")) {
            /**
             * Se non è stato selezionato alcun ricambio o se non viene inserito nessun valore nel campo di testo,
             * viene lanciata un'eccezione personalizzata da me implementata.
             */
            if (selectedRicambio == null || addQuant.getText().isEmpty()) {
                addQuant.clear();
                tableViewRic.getSelectionModel().clearSelection();
                throw new EccezionePersonalizzata("\nSelezionare un ricambio a cui aggiungere quantità ed inserire" +
                        " il numero di unità da aggiungere!");
            }

            /**
             * Se i dati sono stati inseriti correttamente, si procede a recuperare i valori utili alla query
             * di update, inoltre, visto che verrebbe generata un'eccezione se provassi a convertire una stringa vuota
             * in un intero, controllo prima se il textField associato è vuoto, in modo da non convertire il valore nel
             * caso in cui la stringa sia vuota. Se invece nel campo è stato inserito un valore, procedo alla
             * conversione ed al controllo dei valori interi e double.
             */
            int insertQuantita;
            try {
                insertQuantita = Integer.parseInt(addQuant.getText());

            }
            catch (NumberFormatException e) {
                addQuant.clear();
                throw new EccezionePersonalizzata("\nNon è stato inserito un valore valido" +
                        " nel campo quantità!");
            }

            int currQuantita = selectedRicambio.getQuantita();
            String selectedPK = selectedRicambio.getCodiceRicambio();

            db.update("update venditaricambi.ricambio set quantita = " + (currQuantita + insertQuantita) +
                    " where codiceRicambio='" + selectedPK + "'");

            JOptionPane.showMessageDialog(null, "\nNuove unità aggiunte correttamente!");

            addQuant.clear();
        }

        if (selectedValue.equals("Modifica sconto")) {
            if (selectedRicambio == null || modifySconto.getText().isEmpty()) {
                tableViewRic.getSelectionModel().clearSelection();
                modifySconto.clear();
                throw new EccezionePersonalizzata("\nSelezionare un ricambio su cui applicare uno sconto ed inserire" +
                        " la nuova percentuale di sconto!");
            }

            int insertSconto;
            try {
                insertSconto = Integer.parseInt(modifySconto.getText());

            }
            catch (NumberFormatException e) {
                modifySconto.clear();
                throw new EccezionePersonalizzata("\nNon è stato inserito un valore valido" +
                        " nel campo sconto!");
            }

            String selectedPK = selectedRicambio.getCodiceRicambio();

            db.update("update venditaricambi.ricambio set sconto = " + insertSconto + " where codiceRicambio='" +
                    selectedPK + "'");

            JOptionPane.showMessageDialog(null, "\nSconto applicato correttamente!");
            modifySconto.clear();
        }

        /**
         * Ricarico la nuova tabella, che viene aggiornata dopo le operazioni di update.
         */
        TipoTabella<Ricambio> tab = new TipoTabella<>(new TabellaRicambio());
        tableViewRic.setItems(tab.getElements());
        tableViewRic.refresh();
    }

    /**
     * Metodo che permetta la gestione della ComboBox, ossia del menù a tendina, quando viene cliccata una delle sue voci.
     */
    @FXML
    void handleComboBox(ActionEvent event) {
        String selectedValue = myComboBox.getValue();

        /**
         * In base alla selezione vengono effettuate alcune operazioni relative alla visibilità e alla pulizia di alcuni
         * oggetti della scena.
         */
        if (selectedValue.equals("Aggiungi quantità")) {
            addQuant.clear();
            modifySconto.clear();
            addQuant.setVisible(true);
            modifySconto.setVisible(false);
        }

        if (selectedValue.equals("Modifica sconto")) {
            addQuant.clear();
            modifySconto.clear();
            addQuant.setVisible(false);
            modifySconto.setVisible(true);
        }
    }

    /**
     * Metodo invocato al termine della fase di inizializzazione della scena da parte del FXMLLoader.
     */
    @FXML
    void initialize() {
        /**
         * Creo un ObservableList che conterrà solo oggetti di tipo String, i quali verranno poi caricati mediante
         * metodo apposito, setItems, all'interno del menù a tendina, ossia l'oggetto di tipo ComboBox.
         */
        ObservableList<String> items = FXCollections.observableArrayList("Aggiungi quantità", "Modifica sconto");
        myComboBox.setItems(items);

        /**
         * Setto vari effetti relativi a diversi oggetti, per quanto riguarda gli eventi OnMouseEntered e OnMouseExited.
         */
        myComboBox.setOnMouseEntered(e -> {
            myComboBox.setCursor(Cursor.HAND);
        });

        myComboBox.setOnMouseExited(e -> {
            myComboBox.setCursor(Cursor.DEFAULT);
        });

        myComboBox.setCellFactory(listView -> new ListCell<String>() {
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(item);

                if (item != null) {
                    setOnMouseEntered(e -> setCursor(Cursor.HAND));
                    setOnMouseExited(e -> setCursor(Cursor.DEFAULT));
                } else {
                    setOnMouseEntered(null);
                    setOnMouseExited(null);
                }
            }
        });

        DropShadow shadow = new DropShadow();

        back.setOnMouseEntered(e -> {
            back.setEffect(shadow);
            back.setStyle("-fx-background-color: #8f6500;");
            back.setCursor(Cursor.HAND);
        });

        back.setOnMouseExited(e -> {
            back.setEffect(null);
            back.setStyle("-fx-background-color: #f4ad00;");
            back.setCursor(Cursor.DEFAULT);
        });

        apply.setOnMouseEntered(e -> {
            apply.setEffect(shadow);
            apply.setStyle("-fx-background-color: #3b4366;");
            apply.setCursor(Cursor.HAND);
        });

        apply.setOnMouseExited(e -> {
            apply.setEffect(null);
            apply.setStyle("-fx-background-color: #0b1541;");
            apply.setCursor(Cursor.DEFAULT);
        });

        /**
         * Creo una tabella relativa ai ricambi che permetterà di effettuare le operazioni di modifica, infatti setto
         * selezionabili le righe della tabella non vuote.
         */
        codiceRicambio.setCellValueFactory(new PropertyValueFactory<>("codiceRicambio"));
        nomeRicambio.setCellValueFactory(new PropertyValueFactory<>("nome"));
        descrizioneRicambio.setCellValueFactory(new PropertyValueFactory<>("descrizione"));
        quantita.setCellValueFactory(new PropertyValueFactory<>("quantita"));
        costo.setCellValueFactory(new PropertyValueFactory<>("costo"));
        sconto.setCellValueFactory(new PropertyValueFactory<>("sconto"));

        TipoTabella<Ricambio> tab = new TipoTabella<>(new TabellaRicambio());
        tableViewRic.setItems(tab.getElements());

        tableViewRic.setRowFactory(tv -> {
            TableRow<Ricambio> row = new TableRow<>();

            row.setOnMouseEntered(eventEnt ->  {
                if (!row.isEmpty())
                    row.setCursor(Cursor.HAND);
            });

            row.setOnMouseExited(eventExit -> row.setCursor(Cursor.DEFAULT));

            return row;
        });

        /**
         * Clausola try-catch per provare ad effettuare la connessione al database.
         */
        try {
            db = new Database();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
